# -*- coding: utf-8 -*-
"""A minimal, non-senaite demo of MaiZODB's relational projection.

Models a classic school course-management schema entirely with plain
``persistent.Persistent`` objects -- nothing senaite-specific -- and
stores them through ordinary ZODB/transaction calls:

* Student  (student_id, name, gender, birth_date) -- student_id is the
  natural key.
* Course   (course_id, name, credit) -- course_id is the natural key.
* Enrollment -- one row per (student, course) pair, carrying its own
  ``score`` attribute. A student can take many courses and a course
  can have many students, and the grade belongs to the *pairing*, not
  to either side alone, so it is modelled as its own object with two
  single-valued reference fields, exactly like a normalised SQL join
  table with two foreign keys.

Run against a real RelStorage + PostgreSQL backend, this produces
three real, queryable tables (``student``, ``course``, ``enrollment``)
with no schema migration written by hand -- MaiZODB's relational layer
derives them from the objects themselves, the same mechanism senaite
uses, just pointed at a different, unrelated domain to show it is not
senaite-specific.

Usage::

    POSTGRES_PASSWORD=... python school_relational_demo.py

Reads the following from the environment (with the shown defaults):

    POSTGRES_HOST       postgres
    POSTGRES_PORT       5432
    POSTGRES_DB         lims_db
    POSTGRES_USER       lims_user
    POSTGRES_PASSWORD   (required, no default -- see senaite.docker's
                         2.7.0-maitux1/.env)

The demo tables are dropped and rebuilt from scratch on every run, so
it is safe to run more than once.
"""
from __future__ import print_function

import datetime
import os
import sys

import transaction
import ZODB
from persistent import Persistent
from persistent.mapping import PersistentMapping


# ---------------------------------------------------------------------------
# Domain model. Each class only needs a ``portal_type`` to be recognised
# as content (see ZODB.relational.projection.Classifier) and, for a field
# that holds another object's identity rather than plain data, a class-level
# ``schema.fields()`` that FieldInspector can read (see
# ZODB.relational.fields). Everything else is exactly what a plain Python
# class for this domain would look like anyway.
# ---------------------------------------------------------------------------

class Student(Persistent):
    portal_type = u'Student'

    def __init__(self, student_id, name, gender, birth_date):
        self.student_id = student_id
        self.name = name
        self.gender = gender
        self.birth_date = birth_date


class Course(Persistent):
    portal_type = u'Course'

    def __init__(self, course_id, name, credit):
        self.course_id = course_id
        self.name = name
        self.credit = credit


class _Field(object):
    """Enough of an Archetypes-style field for FieldInspector to read."""

    multiValued = False

    def __init__(self, name):
        self._name = name

    def getName(self):
        return self._name


class UIDReferenceField(_Field):
    """FieldInspector matches reference fields by this exact class name
    (see ZODB.relational.fields.REFERENCE_FIELD_NAMES) -- not by
    inheriting from any real Archetypes base class, since none is
    installed here. Do not rename or prefix this class.
    """


class _EnrollmentSchema(object):
    @staticmethod
    def fields():
        return [UIDReferenceField('student_id'), UIDReferenceField('course_id')]


class Enrollment(Persistent):
    portal_type = u'Enrollment'
    schema = _EnrollmentSchema

    def __init__(self, student_id, course_id, score):
        self.student_id = student_id
        self.course_id = course_id
        self.score = score


# ---------------------------------------------------------------------------
# Wiring: a RelStorage-backed DB whose relational_mapper borrows RelStorage's
# own connection to write the projection atomically with the ZODB commit.
# This mirrors ZODB.relational.senaite.mapper_factory, just without any
# senaite-specific Derivations, since none apply to this domain.
# ---------------------------------------------------------------------------

def _dsn():
    host = os.environ.get('POSTGRES_HOST', 'postgres')
    port = os.environ.get('POSTGRES_PORT', '5432')
    dbname = os.environ.get('POSTGRES_DB', 'lims_db')
    user = os.environ.get('POSTGRES_USER', 'lims_user')
    password = os.environ.get('POSTGRES_PASSWORD')
    if not password:
        sys.exit(
            "POSTGRES_PASSWORD is not set. Read it from "
            "senaite.docker's 2.7.0-maitux1/.env and export it before "
            "running this script.")
    return ("dbname='%s' user='%s' host='%s' port='%s' password='%s'"
            % (dbname, user, host, port, password))


def _make_mapper(connection):
    from ZODB.relational.mapper import BufferingMapper
    from ZODB.relational.projection import Projector
    from ZODB.relational.schema import PostgreSQLWriter
    return BufferingMapper(connection, projector=Projector(),
                           writer=PostgreSQLWriter())


def _open_db(dsn):
    from relstorage.adapters.postgresql import PostgreSQLAdapter
    from relstorage.options import Options
    from relstorage.storage import RelStorage
    storage = RelStorage(adapter=PostgreSQLAdapter(dsn=dsn, options=Options()))
    return ZODB.DB(storage, relational_mapper=_make_mapper)


# ---------------------------------------------------------------------------
# Demo data and driver.
# ---------------------------------------------------------------------------

def _drop_demo_tables(dsn):
    import psycopg2
    conn = psycopg2.connect(dsn)
    conn.autocommit = True
    try:
        cur = conn.cursor()
        cur.execute("DROP TABLE IF EXISTS enrollment CASCADE")
        cur.execute("DROP TABLE IF EXISTS course CASCADE")
        cur.execute("DROP TABLE IF EXISTS student CASCADE")
    finally:
        conn.close()


def _populate(root):
    students = PersistentMapping()
    students['S001'] = Student('S001', 'Alice Zhang', 'F',
                               datetime.date(2003, 5, 12))
    students['S002'] = Student('S002', 'Bob Li', 'M',
                               datetime.date(2002, 11, 30))
    students['S003'] = Student('S003', 'Carol Wang', 'F',
                               datetime.date(2003, 2, 8))
    root['students'] = students

    courses = PersistentMapping()
    courses['C101'] = Course('C101', 'Database Systems', 4)
    courses['C102'] = Course('C102', 'Linear Algebra', 3)
    courses['C103'] = Course('C103', 'English Writing', 2)
    root['courses'] = courses

    enrollments = PersistentMapping()
    pairs = [
        ('S001', 'C101', 92),
        ('S001', 'C102', 85),
        ('S002', 'C101', 78),
        ('S002', 'C103', 88),
        ('S003', 'C102', 95),
        ('S003', 'C103', 91),
    ]
    for index, (student_id, course_id, score) in enumerate(pairs):
        enrollments['E%03d' % (index + 1)] = Enrollment(
            student_id, course_id, score)
    root['enrollments'] = enrollments


def _report(dsn):
    import psycopg2
    # A connection independent of RelStorage's own, so this reads back
    # what was actually committed to the database rather than replaying
    # what this process still holds open.
    conn = psycopg2.connect(dsn)
    try:
        cur = conn.cursor()

        print("\n-- student --")
        cur.execute("SELECT student_id, name, gender, birth_date "
                    "FROM student ORDER BY student_id")
        for row in cur.fetchall():
            print(row)

        print("\n-- course --")
        cur.execute("SELECT course_id, name, credit "
                    "FROM course ORDER BY course_id")
        for row in cur.fetchall():
            print(row)

        print("\n-- enrollment (raw) --")
        cur.execute("SELECT student_id, course_id, score "
                    "FROM enrollment ORDER BY student_id, course_id")
        for row in cur.fetchall():
            print(row)

        print("\n-- enrollment JOINed against student and course --")
        cur.execute("""
            SELECT s.name, c.name, e.score
            FROM enrollment e
            JOIN student s ON s.student_id = e.student_id
            JOIN course c ON c.course_id = e.course_id
            ORDER BY s.name, c.name
        """)
        for row in cur.fetchall():
            print(row)
    finally:
        conn.close()


def main():
    dsn = _dsn()
    _drop_demo_tables(dsn)

    db = _open_db(dsn)
    try:
        conn = db.open()
        try:
            root = conn.root()
            _populate(root)
            transaction.commit()
            print("Committed 3 students, 3 courses, 6 enrollments "
                 "through plain ZODB/transaction calls.")
        finally:
            conn.close()
    finally:
        db.close()

    _report(dsn)


if __name__ == '__main__':
    main()
