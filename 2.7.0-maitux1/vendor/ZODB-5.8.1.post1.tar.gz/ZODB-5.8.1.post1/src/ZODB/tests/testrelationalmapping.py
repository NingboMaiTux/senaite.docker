##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Tests for turning stored objects into rows."""
from __future__ import absolute_import

import unittest

from persistent import Persistent
from persistent.mapping import PersistentMapping

from ZODB.relational import derived
from ZODB.relational import fields
from ZODB.relational import naming
from ZODB.relational import projection
from ZODB.relational import references
from ZODB.relational import valuetypes
from ZODB.relational import workflow
from ZODB.utils import p64
from ZODB.utils import u64


#: UTF-8 for two CJK characters, spelled out so this file stays ASCII.
CJK_BYTES = b'\xe6\xa0\xb7\xe5\x93\x81'


class SnakeCaseTests(unittest.TestCase):

    def test_names_senaite_actually_uses(self):
        for source, expected in [
                ('Result', 'result'),
                ('DateReceived', 'date_received'),
                ('ClientSampleID', 'client_sample_id'),
                ('UID', 'uid'),
                ('id', 'id'),
                ('title', 'title'),
                ('AnalysisRequest', 'analysis_request'),
                ('ARTemplate', 'ar_template'),
                ('ResultCaptureDate', 'result_capture_date'),
        ]:
            self.assertEqual(naming.snake_case(source), expected)

    def test_punctuation_and_digits(self):
        self.assertEqual(naming.snake_case('foo.bar'), 'foo_bar')
        self.assertEqual(naming.snake_case('foo-bar'), 'foo_bar')
        self.assertEqual(naming.snake_case('2nd'), '_2nd')
        self.assertEqual(naming.snake_case('__private__'), 'private')

    def test_truncated_to_what_postgresql_keeps(self):
        self.assertEqual(
            len(naming.snake_case('A' + 'b' * 200)),
            naming.MAX_IDENTIFIER_LENGTH)


class NamerTests(unittest.TestCase):

    def test_table_derived_from_portal_type(self):
        self.assertEqual(naming.Namer().table_for('AnalysisRequest'),
                         'analysis_request')

    def test_table_override_gives_it_a_business_name(self):
        namer = naming.Namer(tables={'AnalysisRequest': 'sample'})
        self.assertEqual(namer.table_for('AnalysisRequest'), 'sample')

    def test_column_override(self):
        namer = naming.Namer(
            columns={('Analysis', 'Result'): 'result_text'})
        self.assertEqual(namer.column_for('Analysis', 'Result'),
                         'result_text')
        self.assertEqual(namer.column_for('Analysis', 'Other'), 'other')

    def test_colliding_fields_are_refused_not_silently_merged(self):
        namer = naming.Namer()
        self.assertRaises(naming.NameConflict,
                          namer.columns_for, 'Analysis', ['Result', 'result'])

    def test_collision_can_be_resolved_by_naming_one(self):
        namer = naming.Namer(
            columns={('Analysis', 'result'): 'result_lower'})
        self.assertEqual(
            namer.columns_for('Analysis', ['Result', 'result']),
            {'Result': 'result', 'result': 'result_lower'})

    def test_field_may_not_take_the_primary_key_column(self):
        namer = naming.Namer()
        self.assertRaises(naming.NameConflict,
                          namer.columns_for, 'Analysis', ['oid'])

    def test_unusable_name_is_refused(self):
        self.assertRaises(naming.NameConflict, naming.Namer().table_for, '...')


class ConverterTests(unittest.TestCase):

    def setUp(self):
        self.convert = valuetypes.Converter().convert

    def test_bool_wins_over_int(self):
        # bool subclasses int; true/false reads better than 1/0.
        self.assertEqual(self.convert(True), valuetypes.Value('boolean', True))

    def test_numbers_keep_a_numeric_type(self):
        self.assertEqual(self.convert(7), valuetypes.Value('bigint', 7))
        self.assertEqual(self.convert(1.5),
                         valuetypes.Value('double precision', 1.5))

    def test_text(self):
        self.assertEqual(self.convert(u'x'), valuetypes.Value('text', u'x'))
        self.assertEqual(self.convert(b'x'), valuetypes.Value('text', u'x'))

    def test_utf8_bytes_are_decoded(self):
        self.assertEqual(self.convert(CJK_BYTES),
                         valuetypes.Value('text', CJK_BYTES.decode('utf-8')))

    def test_bytes_that_are_not_text_get_no_column(self):
        self.assertIs(self.convert(b'\xff\xfe\x00'), valuetypes.UNMAPPED)

    def test_none_is_a_null_of_unknown_type(self):
        converted = self.convert(None)
        self.assertIsNone(converted.sql_type)
        self.assertIsNone(converted.value)

    def test_structures_get_no_column(self):
        for value in ([1, 2], {'a': 1}, (1,), set([1]), Persistent()):
            self.assertIs(self.convert(value), valuetypes.UNMAPPED)

    def test_a_deployment_can_add_its_own_rule(self):
        class Money(object):
            def __init__(self, amount):
                self.amount = amount

        def convert_money(value):
            if isinstance(value, Money):
                return valuetypes.Value('numeric', value.amount)
            return valuetypes.UNMAPPED

        converter = valuetypes.Converter(
            [convert_money] + list(valuetypes.DEFAULT_RULES))
        self.assertEqual(converter.convert(Money(3)),
                         valuetypes.Value('numeric', 3))
        self.assertEqual(converter.convert(3), valuetypes.Value('bigint', 3))


class Content(Persistent):
    """Stands in for a Zope content object."""

    portal_type = 'AnalysisRequest'


class ClassifierTests(unittest.TestCase):

    def setUp(self):
        self.classifier = projection.Classifier()

    def test_content_is_recognised(self):
        self.assertEqual(self.classifier.portal_type(Content()),
                         u'AnalysisRequest')

    def test_plain_persistent_object_is_not_content(self):
        self.assertIsNone(self.classifier.portal_type(Persistent()))
        self.assertIsNone(self.classifier.portal_type(PersistentMapping()))

    def test_bytes_portal_type_is_decoded(self):
        class Bytes(Persistent):
            portal_type = b'Client'

        self.assertEqual(self.classifier.portal_type(Bytes()), u'Client')

    def test_empty_portal_type_is_not_content(self):
        class Empty(Persistent):
            portal_type = '   '

        self.assertIsNone(self.classifier.portal_type(Empty()))

    def test_portal_type_that_is_not_a_name_is_ignored(self):
        class Weird(Persistent):
            portal_type = 42

        self.assertIsNone(self.classifier.portal_type(Weird()))

    def test_object_that_raises_on_attribute_access_is_not_content(self):
        class Broken(Persistent):
            @property
            def portal_type(self):
                raise RuntimeError('no')

        self.assertIsNone(self.classifier.portal_type(Broken()))


class ProjectorTests(unittest.TestCase):

    def setUp(self):
        self.projector = projection.Projector()

    def _project(self, obj, state, pickle=b'PICKLE', oid=7, **kw):
        return self.projector.project(p64(oid), obj, state, pickle, **kw)

    def test_content_object_is_spread_across_columns(self):
        row = self._project(Content(), {
            'Result': u'5.2',
            'DateReceived': 1,
            'ClientSampleID': u'CS-1',
        })
        self.assertEqual(row.table, 'analysis_request')
        self.assertEqual(row.oid, 7)
        self.assertEqual(row.columns['result'],
                         valuetypes.Value('text', u'5.2'))
        self.assertEqual(row.columns['date_received'],
                         valuetypes.Value('bigint', 1))
        self.assertEqual(row.columns['client_sample_id'],
                         valuetypes.Value('text', u'CS-1'))

    def test_content_row_also_keeps_the_pickle(self):
        row = self._project(Content(), {'Result': u'5.2'})
        self.assertEqual(row.columns[projection.STATE_COLUMN],
                         valuetypes.Value('bytea', b'PICKLE'))

    def test_keeping_the_pickle_can_be_turned_off(self):
        projector = projection.Projector(keep_state=False)
        row = projector.project(p64(7), Content(), {'Result': u'5.2'}, b'P')
        self.assertNotIn(projection.STATE_COLUMN, row.columns)
        self.assertIn('result', row.columns)

    def test_fields_with_no_column_are_reported(self):
        row = self._project(Content(), {
            'Result': u'5.2',
            'Analyses': [1, 2, 3],
            'Client': Persistent(),
        })
        self.assertEqual(row.unmapped, frozenset(['Analyses', 'Client']))

    def test_non_content_object_is_kept_whole(self):
        row = self._project(PersistentMapping(), {'data': {'a': 1}})
        self.assertEqual(row.table, projection.OPAQUE_TABLE)
        self.assertEqual(row.oid, 7)
        self.assertEqual(row.columns[projection.STATE_COLUMN],
                         valuetypes.Value('bytea', b'PICKLE'))
        self.assertEqual(row.columns[projection.CLASS_COLUMN],
                         valuetypes.Value(
                             'text', u'persistent.mapping.PersistentMapping'))

    def test_opaque_row_keeps_the_pickle_even_when_state_is_off(self):
        # Without it there would be nothing in the row at all, and the
        # object could not be restored from the projection.
        projector = projection.Projector(keep_state=False)
        row = projector.project(p64(7), PersistentMapping(), {}, b'P')
        self.assertEqual(row.columns[projection.STATE_COLUMN],
                         valuetypes.Value('bytea', b'P'))

    def test_state_that_is_not_a_mapping(self):
        row = self._project(Content(), ('not', 'a', 'mapping'))
        self.assertEqual(row.table, 'analysis_request')
        self.assertIn('__getstate__', row.unmapped)

    def test_oid_is_the_zodb_object_id(self):
        self.assertEqual(self._project(Content(), {}, oid=0).oid, 0)
        self.assertEqual(self._project(Content(), {}, oid=1 << 40).oid,
                         1 << 40)

    def test_is_new_is_carried_through(self):
        self.assertTrue(self._project(Content(), {}, is_new=True).is_new)
        self.assertFalse(self._project(Content(), {}).is_new)

    def test_table_and_column_names_can_be_overridden(self):
        projector = projection.Projector(
            namer=naming.Namer(
                tables={'AnalysisRequest': 'sample'},
                columns={('AnalysisRequest', 'ClientSampleID'): 'client_ref'}))
        row = projector.project(p64(7), Content(), {'ClientSampleID': u'x'},
                                b'P')
        self.assertEqual(row.table, 'sample')
        self.assertIn('client_ref', row.columns)


class DateTimeTests(unittest.TestCase):
    """Moments in time have to become real timestamp columns.

    Zope's DateTime is what Archetypes date fields hold, and left alone
    it is an opaque object no query can filter on.
    """

    def setUp(self):
        self.convert = valuetypes.Converter().convert

    def test_naive_and_aware_share_one_column_type(self):
        # A column whose type depended on whether a value carried a zone
        # would change the first time a naive one turned up.
        import datetime
        naive = self.convert(datetime.datetime(2026, 9, 24, 10, 30))
        self.assertEqual(naive.sql_type, valuetypes.TIMESTAMP)

    def test_date(self):
        import datetime
        self.assertEqual(self.convert(datetime.date(2026, 9, 24)),
                         valuetypes.Value('date', datetime.date(2026, 9, 24)))

    def test_zope_datetime_when_zope_is_absent(self):
        # ZODB does not depend on Zope; the rule simply never fires.
        if valuetypes._zope_datetime_class() is None:
            self.assertIs(self.convert(object()), valuetypes.UNMAPPED)

    def test_zope_datetime_is_converted(self):
        class FakeDateTime(object):
            def asdatetime(self):
                import datetime
                return datetime.datetime(2026, 9, 24, 10, 30)

        del valuetypes._zope_datetime[:]
        valuetypes._zope_datetime.append(FakeDateTime)
        try:
            converted = self.convert(FakeDateTime())
            self.assertEqual(converted.sql_type, valuetypes.TIMESTAMP)
        finally:
            del valuetypes._zope_datetime[:]

    def test_a_datetime_that_cannot_say_when_it_is_gets_no_column(self):
        class BrokenDateTime(object):
            def asdatetime(self):
                raise ValueError('corrupt')

        del valuetypes._zope_datetime[:]
        valuetypes._zope_datetime.append(BrokenDateTime)
        try:
            self.assertIs(self.convert(BrokenDateTime()),
                          valuetypes.UNMAPPED)
        finally:
            del valuetypes._zope_datetime[:]


class NumericDerivationTests(unittest.TestCase):
    """A result is stored as text; statistics need a number."""

    def setUp(self):
        self.derive = derived.NUMERIC.derive

    def test_plain_number(self):
        self.assertEqual(self.derive(u'5.2'),
                         {'num': valuetypes.Value('double precision', 5.2)})

    def test_below_a_detection_limit_keeps_both_parts(self):
        # The number can be averaged; the operator says it was a limit.
        self.assertEqual(
            self.derive(u'<0.05'),
            {'num': valuetypes.Value('double precision', 0.05),
             'operator': valuetypes.Value('text', u'<')})

    def test_operators_and_spacing(self):
        for text, number, operator in [
                (u'>100', 100.0, u'>'),
                (u'>= 7', 7.0, u'>='),
                (u'  <=3.5 ', 3.5, u'<='),
                (u'= 9', 9.0, None),
                (u'-2.5', -2.5, None),
                (u'1.2e3', 1200.0, None),
                (u'.5', 0.5, None),
        ]:
            got = self.derive(text)
            self.assertEqual(got['num'],
                             valuetypes.Value('double precision', number))
            if operator is None:
                self.assertNotIn('operator', got)
            else:
                self.assertEqual(got['operator'],
                                 valuetypes.Value('text', operator))

    def test_results_that_are_not_numbers_derive_nothing(self):
        # An aggregate should skip these, which is what NULL does.
        for text in [u'ND', u'', u'   ', u'positive', u'5.2 mg/L', u'1-2',
                     CJK_BYTES.decode('utf-8')]:
            self.assertEqual(self.derive(text), {})

    def test_numbers_stored_as_numbers(self):
        self.assertEqual(self.derive(5),
                         {'num': valuetypes.Value('double precision', 5.0)})
        self.assertEqual(self.derive(True), {})

    def test_utf8_bytes(self):
        self.assertEqual(self.derive(b'5.2'),
                         {'num': valuetypes.Value('double precision', 5.2)})


class FieldInspectorTests(unittest.TestCase):
    """Reading a class's schema to find which fields are references."""

    def setUp(self):
        self.inspector = fields.FieldInspector()

    def _klass(self, *field_specs):
        class Field(object):
            def __init__(self, name, multi=False):
                self._name = name
                self.multiValued = multi

            def getName(self):
                return self._name

        class UIDReferenceField(Field):
            pass

        class Schema(object):
            def __init__(self, fields):
                self._fields = fields

            def fields(self):
                return self._fields

        built = []
        for name, is_ref, multi in field_specs:
            klass = UIDReferenceField if is_ref else Field
            built.append(klass(name, multi))

        class Content(object):
            schema = Schema(built)

        return Content

    def test_reference_fields_are_found_by_class_name(self):
        klass = self._klass(('Client', True, False), ('Title', False, False))
        self.assertEqual(self.inspector.references(klass), set(['Client']))

    def test_multi_valued_references_are_kept_apart(self):
        klass = self._klass(('Analyses', True, True),
                            ('Client', True, False))
        self.assertEqual(self.inspector.references(klass), set(['Client']))
        self.assertEqual(self.inspector.multi_references(klass),
                         set(['Analyses']))

    def test_class_without_a_schema_is_not_an_error(self):
        class Plain(object):
            pass

        self.assertEqual(self.inspector.fields(Plain), {})
        self.assertEqual(self.inspector.references(Plain), set())

    def test_schema_that_raises_is_not_an_error(self):
        class Angry(object):
            class schema(object):
                @staticmethod
                def fields():
                    raise RuntimeError('no')

        self.assertEqual(self.inspector.fields(Angry), {})

    def test_answer_is_cached_per_class(self):
        calls = []

        class Counting(object):
            class schema(object):
                @staticmethod
                def fields():
                    calls.append(1)
                    return []

        self.inspector.fields(Counting)
        self.inspector.fields(Counting)
        self.assertEqual(len(calls), 1)


class SenaiteShapedTests(unittest.TestCase):
    """The projector against the shapes senaite actually stores."""

    def setUp(self):
        self.projector = projection.Projector(
            derivations=derived.Derivations(
                {('Analysis', 'Result'): derived.NUMERIC}))

    def _project(self, state, portal_type='Analysis', schema=None):
        attributes = {'portal_type': portal_type}
        if schema is not None:
            attributes['schema'] = schema
        klass = type('Content', (Persistent,), attributes)
        return self.projector.project(p64(7), klass(), state, b'P')

    def _schema(self, name, reference=True, multi=False):
        class Field(object):
            multiValued = multi

            def getName(self):
                return name

        class UIDReferenceField(Field):
            pass

        field = (UIDReferenceField if reference else Field)()

        class Schema(object):
            @staticmethod
            def fields():
                return [field]

        return Schema

    def test_own_uid_becomes_the_join_key(self):
        row = self._project({'_at_uid': u'abc123'})
        self.assertEqual(row.columns['uid'],
                         valuetypes.Value('text', u'abc123'))
        self.assertNotIn('at_uid', row.columns)

    def test_dexterity_uid_lands_in_the_same_column(self):
        # So nothing querying has to know which framework a type uses.
        row = self._project({'_plone.uuid': u'abc123'})
        self.assertEqual(row.columns['uid'],
                         valuetypes.Value('text', u'abc123'))
        self.assertNotIn('plone_uuid', row.columns)

    def test_object_without_a_uid(self):
        row = self._project({'Result': u'1'})
        self.assertNotIn('uid', row.columns)

    def test_reference_is_an_ordinary_column_that_gets_indexed(self):
        row = self._project({'Client': u'deadbeef'},
                            schema=self._schema('Client'))
        # Named and typed like any other column, so that improving
        # reference detection later never renames anything.
        self.assertEqual(row.columns['client'],
                         valuetypes.Value('text', u'deadbeef'))
        self.assertEqual(row.references, frozenset(['client']))

    def test_multi_valued_reference_is_decomposed_not_an_index_candidate(self):
        # Unlike a single reference, a list has no column of its own to
        # index -- it becomes rows instead (see
        # ProjectorReferenceTests), so it is not in row.references and,
        # having been handled, not in row.unmapped either.
        row = self._project({'Analyses': [u'a', u'b']},
                            schema=self._schema('Analyses', multi=True))
        self.assertEqual(row.references, frozenset())
        self.assertNotIn('Analyses', row.unmapped)
        self.assertNotIn('analyses', row.columns)
        self.assertEqual(len(row.children), 2)

    def test_reference_detection_is_not_guessed_from_the_value(self):
        # A class whose schema says nothing still gets the column, just
        # without the index.
        row = self._project({'Client': u'0' * 32})
        self.assertIn('client', row.columns)
        self.assertEqual(row.references, frozenset())

    def test_result_keeps_its_text_and_gains_a_number(self):
        row = self._project({'Result': u'<0.05'})
        self.assertEqual(row.columns['result'],
                         valuetypes.Value('text', u'<0.05'))
        self.assertEqual(row.columns['result_num'],
                         valuetypes.Value('double precision', 0.05))
        self.assertEqual(row.columns['result_operator'],
                         valuetypes.Value('text', u'<'))

    def test_unmeasurable_result_has_text_but_no_number(self):
        row = self._project({'Result': u'ND'})
        self.assertEqual(row.columns['result'],
                         valuetypes.Value('text', u'ND'))
        self.assertNotIn('result_num', row.columns)

    def test_only_declared_fields_are_derived(self):
        row = self._project({'Uncertainty': u'0.1'})
        self.assertNotIn('uncertainty_num', row.columns)

    def test_derivations_are_per_content_type(self):
        row = self._project({'Result': u'5.2'}, portal_type='Sample')
        self.assertNotIn('result_num', row.columns)


class WorkflowExpanderTests(unittest.TestCase):
    """Turning workflow_history into transition rows, in isolation."""

    def setUp(self):
        self.expander = workflow.WorkflowExpander(valuetypes.Converter())

    def _expand(self, history, content_uid=None, oid=7,
                portal_type=u'Analysis'):
        return self.expander.expand(oid, content_uid, portal_type, history)

    def test_senaite_shaped_history(self):
        # The exact keys senaite's own workflow definitions produce
        # (confirmed against senaite_analysis_workflow/definition.xml):
        # action, actor, comments, review_state, time.
        rows = self._expand({
            'senaite_analysis_workflow': [
                {'action': None, 'actor': u'admin', 'comments': u'',
                 'review_state': u'unassigned', 'time': 1},
                {'action': u'submit', 'actor': u'lab1', 'comments': u'ok',
                 'review_state': u'to_be_verified', 'time': 2},
            ],
        })
        self.assertEqual(len(rows), 2)
        first, second = rows
        self.assertEqual(first.table, workflow.TRANSITION_TABLE)
        self.assertIsNone(first.oid)
        self.assertEqual(first.columns[workflow.CONTENT_OID_COLUMN],
                         valuetypes.Value('bigint', 7))
        self.assertEqual(first.columns[workflow.PORTAL_TYPE_COLUMN],
                         valuetypes.Value('text', u'Analysis'))
        self.assertEqual(
            first.columns[workflow.WORKFLOW_COLUMN],
            valuetypes.Value('text', u'senaite_analysis_workflow'))
        self.assertEqual(first.columns[workflow.SEQUENCE_COLUMN],
                         valuetypes.Value('bigint', 0))
        self.assertEqual(second.columns[workflow.SEQUENCE_COLUMN],
                         valuetypes.Value('bigint', 1))
        # action is None for the creation event: a NULL, not a missing
        # column, because other rows establish 'action' as text.
        self.assertEqual(first.columns['action'], valuetypes.NULL)
        self.assertEqual(second.columns['action'],
                         valuetypes.Value('text', u'submit'))
        self.assertEqual(second.columns['actor'],
                         valuetypes.Value('text', u'lab1'))
        self.assertEqual(second.columns['review_state'],
                         valuetypes.Value('text', u'to_be_verified'))

    def test_content_uid_is_carried_when_present(self):
        uid = valuetypes.Value('text', u'abc123')
        rows = self._expand({'wf': [{'action': u'x'}]}, content_uid=uid)
        self.assertEqual(rows[0].columns[workflow.CONTENT_UID_COLUMN], uid)

    def test_content_uid_column_absent_when_there_is_no_uid(self):
        rows = self._expand({'wf': [{'action': u'x'}]})
        self.assertNotIn(workflow.CONTENT_UID_COLUMN, rows[0].columns)

    def test_multiple_workflows_all_produce_rows(self):
        rows = self._expand({
            'wf_one': [{'action': u'a'}],
            'wf_two': [{'action': u'b'}, {'action': u'c'}],
        })
        by_workflow = {}
        for row in rows:
            wf = row.columns[workflow.WORKFLOW_COLUMN].value
            by_workflow.setdefault(wf, []).append(row)
        self.assertEqual(len(by_workflow['wf_one']), 1)
        self.assertEqual(len(by_workflow['wf_two']), 2)

    def test_custom_workflow_variable_gets_its_own_column(self):
        rows = self._expand({'wf': [{'action': u'x', 'batch_uid': u'b-1'}]})
        self.assertEqual(rows[0].columns['batch_uid'],
                         valuetypes.Value('text', u'b-1'))

    def test_variable_colliding_with_a_reserved_column_is_dropped(self):
        # A custom workflow variable happens to be called "sequence".
        # The real sequence number must not be overwritten by it, and
        # the rest of the row must still come through.
        rows = self._expand({'wf': [{'action': u'x', 'sequence': u'oops'}]})
        self.assertEqual(rows[0].columns[workflow.SEQUENCE_COLUMN],
                         valuetypes.Value('bigint', 0))
        self.assertEqual(rows[0].columns['action'],
                         valuetypes.Value('text', u'x'))

    def test_value_the_converter_cannot_type_has_no_column(self):
        rows = self._expand({'wf': [{'action': u'x', 'blob': object()}]})
        self.assertNotIn('blob', rows[0].columns)

    def test_absent_history_is_not_an_error(self):
        self.assertEqual(self._expand(None), [])
        self.assertEqual(self._expand(u'not a mapping'), [])

    def test_non_sequence_events_for_a_workflow_are_skipped(self):
        # One workflow's value is malformed; others still come through.
        rows = self._expand({'bad': 'nope', 'good': [{'action': u'x'}]})
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].columns[workflow.WORKFLOW_COLUMN],
                         valuetypes.Value('text', u'good'))

    def test_non_mapping_event_is_skipped(self):
        rows = self._expand({'wf': ['not-a-dict', {'action': u'x'}]})
        self.assertEqual(len(rows), 1)

    def test_null_expander_finds_nothing(self):
        expander = workflow.NullExpander()
        self.assertEqual(
            expander.expand(7, None, 'Analysis', {'wf': [{'action': 1}]}),
            [])


class ProjectorWorkflowHistoryTests(unittest.TestCase):
    """workflow_history through the whole Projector, not in isolation."""

    def setUp(self):
        self.projector = projection.Projector()

    def test_history_becomes_children_not_a_column(self):
        row = self.projector.project(p64(7), Content(), {
            'Result': u'5.2',
            'workflow_history': {
                'senaite_analysis_workflow': [{'action': None}],
            },
        }, b'P')
        self.assertNotIn('workflow_history', row.unmapped)
        self.assertNotIn('workflow_history', row.columns)
        self.assertEqual(len(row.children), 1)
        self.assertEqual(row.children[0].table, workflow.TRANSITION_TABLE)

    def test_children_carry_the_uid_already_computed_for_the_parent(self):
        row = self.projector.project(p64(7), Content(), {
            '_at_uid': u'abc123',
            'workflow_history': {'wf': [{'action': u'x'}]},
        }, b'P')
        self.assertEqual(
            row.children[0].columns[workflow.CONTENT_UID_COLUMN],
            valuetypes.Value('text', u'abc123'))

    def test_no_history_means_no_children(self):
        row = self.projector.project(p64(7), Content(), {'Result': u'1'},
                                     b'P')
        self.assertEqual(row.children, ())

    def test_expansion_can_be_disabled(self):
        projector = projection.Projector(
            workflow_expander=workflow.NullExpander())
        row = projector.project(p64(7), Content(), {
            'workflow_history': {'wf': [{'action': u'x'}]},
        }, b'P')
        self.assertEqual(row.children, ())


class ReferenceExpanderTests(unittest.TestCase):
    """Turning a list-of-references field into rows, in isolation."""

    def setUp(self):
        self.expander = references.ReferenceExpander()

    def _expand(self, targets, content_uid=None, oid=7,
                portal_type=u'AnalysisRequest', field=u'Analyses'):
        return self.expander.expand(oid, content_uid, portal_type, field,
                                    targets)

    def test_one_row_per_target_with_position(self):
        rows, prune = self._expand([u'uid-a', u'uid-b'])
        self.assertEqual(len(rows), 2)
        first, second = rows
        self.assertEqual(first.table, references.REFERENCE_TABLE)
        self.assertIsNone(first.oid)
        self.assertEqual(first.natural_key, references.NATURAL_KEY)
        self.assertEqual(first.columns[references.CONTENT_OID_COLUMN],
                         valuetypes.Value('bigint', 7))
        self.assertEqual(first.columns[references.PORTAL_TYPE_COLUMN],
                         valuetypes.Value('text', u'AnalysisRequest'))
        self.assertEqual(first.columns[references.FIELD_COLUMN],
                         valuetypes.Value('text', u'Analyses'))
        self.assertEqual(first.columns[references.TARGET_UID_COLUMN],
                         valuetypes.Value('text', u'uid-a'))
        self.assertEqual(first.columns[references.POSITION_COLUMN],
                         valuetypes.Value('bigint', 0))
        self.assertEqual(second.columns[references.TARGET_UID_COLUMN],
                         valuetypes.Value('text', u'uid-b'))
        self.assertEqual(second.columns[references.POSITION_COLUMN],
                         valuetypes.Value('bigint', 1))

    def test_content_uid_is_carried_when_present(self):
        uid = valuetypes.Value('text', u'abc123')
        rows, _ = self._expand([u'uid-a'], content_uid=uid)
        self.assertEqual(rows[0].columns[references.CONTENT_UID_COLUMN], uid)

    def test_content_uid_column_absent_when_there_is_no_uid(self):
        rows, _ = self._expand([u'uid-a'])
        self.assertNotIn(references.CONTENT_UID_COLUMN, rows[0].columns)

    def test_empty_list_produces_no_rows_but_still_a_prune(self):
        rows, prune = self._expand([])
        self.assertEqual(rows, [])
        self.assertIsNotNone(prune)
        table, scope, item_columns = prune
        self.assertEqual(table, references.REFERENCE_TABLE)
        self.assertEqual(scope, {references.CONTENT_OID_COLUMN: 7,
                                 references.FIELD_COLUMN: u'Analyses'})
        self.assertEqual(item_columns, references.PRUNE_ITEM_COLUMNS)

    def test_non_sequence_value_is_treated_as_empty(self):
        for bad in (None, 42, object()):
            rows, prune = self._expand(bad)
            self.assertEqual(rows, [])
            self.assertIsNotNone(prune)

    def test_a_bare_string_is_not_treated_as_a_sequence_of_characters(self):
        # A string is technically iterable; it must not be mistaken for
        # a list of one-character UIDs.
        rows, prune = self._expand(u'uid-a')
        self.assertEqual(rows, [])
        self.assertIsNotNone(prune)

    def test_empty_string_targets_are_skipped(self):
        rows, _ = self._expand([u'uid-a', u'', None])
        self.assertEqual([r.columns[references.TARGET_UID_COLUMN].value
                          for r in rows], [u'uid-a'])

    def test_prune_scope_identifies_this_object_and_field(self):
        _, prune = self._expand([u'uid-a'], oid=99, field=u'Analyses')
        table, scope, item_columns = prune
        self.assertEqual(scope[references.CONTENT_OID_COLUMN], 99)
        self.assertEqual(scope[references.FIELD_COLUMN], u'Analyses')

    def test_null_expander_finds_and_prunes_nothing(self):
        expander = references.NullReferenceExpander()
        rows, prune = expander.expand(7, None, u'AnalysisRequest',
                                      u'Analyses', [u'uid-a'])
        self.assertEqual(rows, [])
        self.assertIsNone(prune)


class ProjectorReferenceTests(unittest.TestCase):
    """Multi-valued references through the whole Projector."""

    def setUp(self):
        self.projector = projection.Projector()

    def _schema(self, name, multi=True):
        class Field(object):
            multiValued = multi

            def getName(self):
                return name

        class UIDReferenceField(Field):
            pass

        class Schema(object):
            @staticmethod
            def fields():
                return [UIDReferenceField()]

        return Schema

    def _project(self, state, schema):
        klass = type('Content', (Persistent,),
                     {'portal_type': u'AnalysisRequest', 'schema': schema})
        return self.projector.project(p64(7), klass(), state, b'P')

    def test_field_becomes_children_not_a_column(self):
        row = self._project({'Analyses': [u'uid-a', u'uid-b']},
                            self._schema('Analyses'))
        self.assertNotIn('analyses', row.columns)
        self.assertNotIn('Analyses', row.unmapped)
        self.assertEqual(len(row.children), 2)
        self.assertTrue(all(c.table == references.REFERENCE_TABLE
                            for c in row.children))

    def test_prune_entry_is_on_the_parent_row(self):
        row = self._project({'Analyses': [u'uid-a']},
                            self._schema('Analyses'))
        self.assertEqual(len(row.prune), 1)
        table, scope, item_columns = row.prune[0]
        self.assertEqual(table, references.REFERENCE_TABLE)
        self.assertEqual(scope[references.FIELD_COLUMN], u'Analyses')

    def test_emptied_field_still_produces_a_prune_entry(self):
        # No children to infer a group from -- the parent must say so
        # explicitly, or a field cleared out entirely would never be
        # pruned.
        row = self._project({'Analyses': []}, self._schema('Analyses'))
        self.assertEqual(row.children, ())
        self.assertEqual(len(row.prune), 1)

    def test_field_not_present_at_all_produces_no_prune_entry(self):
        # Nothing to prune for a field this object's schema has but
        # this particular state never touched.
        row = self._project({'Result': u'1'}, self._schema('Analyses'))
        self.assertEqual(row.prune, ())

    def test_children_carry_the_parents_uid(self):
        row = self._project(
            {'_at_uid': u'abc123', 'Analyses': [u'uid-a']},
            self._schema('Analyses'))
        self.assertEqual(
            row.children[0].columns[references.CONTENT_UID_COLUMN],
            valuetypes.Value('text', u'abc123'))

    def test_expansion_can_be_disabled(self):
        projector = projection.Projector(
            reference_expander=references.NullReferenceExpander())
        row = projector.project(p64(7), type(
            'C', (Persistent,),
            {'portal_type': u'AnalysisRequest',
             'schema': self._schema('Analyses')})(),
            {'Analyses': [u'uid-a']}, b'P')
        self.assertEqual(row.children, ())
        self.assertEqual(row.prune, ())

    def test_single_valued_reference_is_unaffected(self):
        # Only a field the schema actually says is multi-valued goes
        # through this path; an ordinary reference still becomes a
        # plain, indexed column (see SenaiteShapedTests).
        row = self._project({'Client': u'uid-a'},
                            self._schema('Analyses', multi=True))
        self.assertEqual(row.columns['client'],
                         valuetypes.Value('text', u'uid-a'))
        self.assertEqual(row.children, ())


class CollectingWriter(object):

    def __init__(self):
        self.batches = []

    def write(self, rows, storage):
        self.batches.append(rows)

    @property
    def rows(self):
        return [row for batch in self.batches for row in batch]

    def tables(self):
        return sorted(set(row.table for row in self.rows))


class BufferingMapperTests(unittest.TestCase):
    """The mapper driven by real transactions, end to end."""

    def setUp(self):
        import ZODB
        from ZODB.MappingStorage import MappingStorage
        from ZODB.relational.mapper import BufferingMapper

        self.writer = CollectingWriter()
        self.db = ZODB.DB(
            MappingStorage(),
            relational_mapper=lambda conn: BufferingMapper(
                conn, writer=self.writer))
        self.conn = self.db.open()
        del self.writer.batches[:]

    def tearDown(self):
        import transaction
        transaction.abort()
        self.conn.close()
        self.db.close()

    def test_a_commit_produces_rows(self):
        import transaction
        self.conn.root()['child'] = Content()
        transaction.commit()
        # The root is a persistent mapping, so it is kept whole; the
        # content object is spread across columns.
        self.assertEqual(self.writer.tables(),
                         ['analysis_request', projection.OPAQUE_TABLE])

    def test_nothing_written_when_nothing_changed(self):
        import transaction
        transaction.commit()
        self.assertEqual(self.writer.batches, [])

    def test_rows_are_dropped_when_the_transaction_aborts(self):
        import transaction
        self.conn.root()['child'] = Content()
        transaction.abort()
        self.assertEqual(self.writer.batches, [])

    def test_one_row_per_object_however_often_it_was_stored(self):
        import transaction
        child = Content()
        self.conn.root()['child'] = child
        transaction.savepoint()
        child.Result = u'later'
        transaction.commit()

        oids = [row.oid for row in self.writer.rows]
        self.assertEqual(len(oids), len(set(oids)))
        row = [r for r in self.writer.rows
               if r.table == 'analysis_request'][0]
        self.assertEqual(row.columns['result'],
                         valuetypes.Value('text', u'later'))

    def test_objects_taken_back_by_a_rollback_are_not_written(self):
        import transaction
        self.conn.root()['keep'] = Content()
        savepoint = transaction.savepoint()
        self.conn.root()['discard'] = Content()
        transaction.savepoint()
        savepoint.rollback()
        transaction.commit()

        written = set(row.oid for row in self.writer.rows)
        kept = self.conn.root()['keep']
        self.assertIn(u64(kept._p_oid), written)
        self.assertNotIn('discard', self.conn.root())
        # The discarded object was recorded before the rollback took it
        # back; it must not reach the database.
        self.assertEqual(len(written), len(self.writer.rows))
        for row in self.writer.rows:
            self.assertIn(row.oid, self._live_oids())

    def _live_oids(self):
        live = set([u64(self.conn.root()._p_oid)])
        for value in self.conn.root().values():
            live.add(u64(value._p_oid))
        return live

    def test_workflow_history_produces_transition_rows(self):
        import transaction
        from persistent.mapping import PersistentMapping

        child = Content()
        child.workflow_history = PersistentMapping()
        child.workflow_history['wf'] = [
            {'action': None, 'actor': u'admin'},
            {'action': u'submit', 'actor': u'lab1'},
        ]
        self.conn.root()['child'] = child
        transaction.commit()

        transitions = [r for r in self.writer.rows
                       if r.table == workflow.TRANSITION_TABLE]
        self.assertEqual(len(transitions), 2)
        for row in transitions:
            self.assertIsNone(row.oid)
            self.assertEqual(row.columns[workflow.CONTENT_OID_COLUMN],
                             valuetypes.Value('bigint', u64(child._p_oid)))
        # The PersistentMapping is its own persistent object; it still
        # gets a faithful, restorable opaque row of its own, same as
        # any object with no portal_type.
        self.assertIn(projection.OPAQUE_TABLE, self.writer.tables())

    def test_transitions_are_dropped_with_their_rolled_back_parent(self):
        import transaction
        from persistent.mapping import PersistentMapping

        self.conn.root()['keep'] = Content()
        savepoint = transaction.savepoint()
        discard = Content()
        discard.workflow_history = PersistentMapping()
        discard.workflow_history['wf'] = [{'action': u'x'}]
        self.conn.root()['discard'] = discard
        transaction.savepoint()
        savepoint.rollback()
        transaction.commit()

        transitions = [r for r in self.writer.rows
                       if r.table == workflow.TRANSITION_TABLE]
        self.assertEqual(transitions, [])


def test_suite():
    suite = unittest.TestSuite()
    for klass in (SnakeCaseTests, NamerTests, ConverterTests, ClassifierTests,
                  ProjectorTests, DateTimeTests, NumericDerivationTests,
                  FieldInspectorTests, SenaiteShapedTests,
                  WorkflowExpanderTests, ProjectorWorkflowHistoryTests,
                  ReferenceExpanderTests, ProjectorReferenceTests,
                  BufferingMapperTests):
        suite.addTest(unittest.makeSuite(klass))
    return suite
