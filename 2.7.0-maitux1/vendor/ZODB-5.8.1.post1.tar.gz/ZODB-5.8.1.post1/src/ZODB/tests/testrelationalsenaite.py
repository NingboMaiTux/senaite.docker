##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Tests for the senaite-specific wiring, against MappingStorage.

Fast checks that ``mapper_factory`` assembles a working mapper and that
the one thing this module promises about process lifetime -- one
shared writer -- actually holds. Whether that writer's SQL is valid
PostgreSQL is proven elsewhere (testrelational_relstorage), against the
real thing; this file is only about the wiring.
"""
from __future__ import absolute_import

import unittest

import transaction
from persistent import Persistent

import ZODB
from ZODB.MappingStorage import MappingStorage
from ZODB.relational import senaite
from ZODB.relational.mapper import BufferingMapper


class Analysis(Persistent):
    portal_type = u'Analysis'


class MapperFactoryTests(unittest.TestCase):

    def test_returns_a_buffering_mapper(self):
        db = ZODB.DB(MappingStorage())
        try:
            conn = db.open()
            mapper = senaite.mapper_factory(conn)
            self.assertIsInstance(mapper, BufferingMapper)
            conn.close()
        finally:
            db.close()

    def test_every_connection_shares_the_one_writer(self):
        db = ZODB.DB(MappingStorage())
        try:
            conn_one = db.open()
            conn_two = db.open()
            try:
                mapper_one = senaite.mapper_factory(conn_one)
                mapper_two = senaite.mapper_factory(conn_two)
                self.assertIs(mapper_one.writer, mapper_two.writer)
                self.assertIs(mapper_one.writer, senaite.writer)
            finally:
                conn_one.close()
                conn_two.close()
        finally:
            db.close()

    def test_result_is_derived_end_to_end(self):
        captured = []

        class CapturingWriter(object):
            def write(self, rows, storage):
                captured.extend(rows)

        original_writer = senaite.writer
        senaite.writer = CapturingWriter()
        try:
            db = ZODB.DB(MappingStorage(),
                         relational_mapper=senaite.mapper_factory)
            try:
                conn = db.open()
                a = Analysis()
                a.Result = u'<0.05'
                conn.root()['a'] = a
                transaction.commit()
                conn.close()
            finally:
                db.close()
        finally:
            senaite.writer = original_writer

        rows = [r for r in captured if r.table == 'analysis']
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].columns['result_num'].value, 0.05)
        self.assertEqual(rows[0].columns['result_operator'].value, '<')


def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(MapperFactoryTests))
    return suite
