##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Tests for the relational projection hooks."""
from __future__ import absolute_import

import unittest

import transaction
from persistent.mapping import PersistentMapping

import ZODB
from ZODB.MappingStorage import MappingStorage
from ZODB.relational import relstorage_support


class RecordingMapper(object):
    """A mapper that just writes down what it was asked to do."""

    def __init__(self, connection):
        self.connection = connection
        self.calls = []
        self.records = []

    def tpc_begin(self, transaction):
        self.calls.append('tpc_begin')

    def record(self, oid, obj, state, pickle, is_new):
        self.calls.append('record')
        self.records.append((oid, obj, state, pickle, is_new))

    def tpc_vote(self, storage):
        self.calls.append('tpc_vote')
        self.voted_storage = storage

    def tpc_finish(self, tid):
        self.calls.append('tpc_finish')
        self.tid = tid

    def tpc_abort(self):
        self.calls.append('tpc_abort')

    def abort(self):
        self.calls.append('abort')


class MapperTests(unittest.TestCase):

    def setUp(self):
        self.mappers = []
        self.db = ZODB.DB(MappingStorage(),
                          relational_mapper=self._make_mapper)

    def tearDown(self):
        self.db.close()

    def _make_mapper(self, connection):
        mapper = RecordingMapper(connection)
        self.mappers.append(mapper)
        return mapper

    def test_no_mapper_by_default(self):
        db = ZODB.DB(MappingStorage())
        try:
            conn = db.open()
            self.assertIsNone(conn._relational_mapper())
            conn.root()['x'] = PersistentMapping()
            transaction.commit()
            conn.close()
        finally:
            db.close()

    def _fresh(self):
        """A connection whose mapper has forgotten the root creation.

        DB.__init__ commits the root object, so a pooled connection's
        mapper has already seen a transaction before any test starts.
        """
        conn = self.db.open()
        mapper = conn._relational_mapper()
        del mapper.calls[:]
        del mapper.records[:]
        return conn, mapper

    def test_mapper_sees_committed_objects(self):
        conn, mapper = self._fresh()
        child = PersistentMapping()
        child['answer'] = 42
        conn.root()['child'] = child
        transaction.commit()

        self.assertEqual(mapper.calls[0], 'tpc_begin')
        self.assertEqual(mapper.calls[-2:], ['tpc_vote', 'tpc_finish'])

        states = [state for (_, _, state, _, _) in mapper.records]
        # What __getstate__ returned, not a pickle. PersistentMapping
        # keeps its contents under 'data'.
        self.assertIn({'data': {'answer': 42}}, states)
        conn.close()

    def test_new_versus_modified(self):
        conn, mapper = self._fresh()
        child = PersistentMapping()
        conn.root()['child'] = child
        transaction.commit()

        by_oid = dict(
            (oid, is_new) for (oid, _, _, _, is_new) in mapper.records)
        # The child is created; the root that now points at it is only
        # modified.
        self.assertTrue(by_oid[child._p_oid])
        self.assertFalse(by_oid[conn.root()._p_oid])

        del mapper.records[:]
        child['x'] = 1
        transaction.commit()
        self.assertEqual(
            [is_new for (_, _, _, _, is_new) in mapper.records], [False])
        conn.close()

    def test_abort_notifies_mapper(self):
        conn, mapper = self._fresh()
        conn.root()['child'] = PersistentMapping()
        transaction.abort()
        # Abandoned before the commit began: no tpc at all, but the
        # mapper is still told, because a savepoint could have left it
        # holding rows.
        self.assertEqual(mapper.calls, ['abort'])
        conn.close()

    def test_abort_during_commit_notifies_mapper(self):
        conn, mapper = self._fresh()
        conn.root()['child'] = PersistentMapping()
        txn = transaction.get()
        conn.tpc_begin(txn)
        conn.commit(txn)
        conn.tpc_abort(txn)
        self.assertIn('tpc_abort', mapper.calls)
        self.assertNotIn('tpc_finish', mapper.calls)
        transaction.abort()
        conn.close()

    def test_mapper_installed_after_connection_pooled(self):
        # DB.__init__ opens, uses and pools a connection before the
        # application gets a say; that connection must still pick up a
        # mapper installed afterwards.
        db = ZODB.DB(MappingStorage())
        try:
            made = []

            def factory(connection):
                mapper = RecordingMapper(connection)
                made.append(mapper)
                return mapper

            db.relational_mapper = factory
            conn = db.open()
            conn.root()['x'] = PersistentMapping()
            transaction.commit()
            self.assertEqual(len(made), 1)
            self.assertIn('tpc_finish', made[0].calls)
            conn.close()
        finally:
            db.close()

    def test_vote_is_given_the_storage(self):
        conn, mapper = self._fresh()
        conn.root()['child'] = PersistentMapping()
        transaction.commit()
        self.assertIs(mapper.voted_storage, conn._storage)
        conn.close()


class PickleUnchangedTests(unittest.TestCase):
    """The projection must not disturb what gets stored."""

    def _pickles(self, **db_kw):
        storage = MappingStorage()
        db = ZODB.DB(storage, **db_kw)
        conn = db.open()
        child = PersistentMapping()
        child['answer'] = 42
        conn.root()['child'] = child
        transaction.commit()
        pickles = dict((oid, storage.load(oid)[0])
                       for oid in storage._data)
        conn.close()
        db.close()
        return pickles

    def test_identical_with_and_without_mapper(self):
        without = self._pickles()
        with_mapper = self._pickles(
            relational_mapper=lambda conn: RecordingMapper(conn))
        self.assertEqual(without, with_mapper)


class StoreCursorTests(unittest.TestCase):
    """Reaching into RelStorage for its live connection.

    RelStorage is not a dependency, so these exercise the guards with
    stand-ins shaped like the real thing.
    """

    def test_non_relstorage_yields_nothing(self):
        self.assertIsNone(relstorage_support.store_cursor(MappingStorage()))

    def test_not_in_transaction_yields_nothing(self):
        class NotInTransaction(object):
            pass

        class Storage(object):
            _tpc_phase = NotInTransaction()

        self.assertIsNone(relstorage_support.store_cursor(Storage()))

    def test_unborrowed_connection_is_not_forced_open(self):
        class SharedState(object):
            borrowed = False

            @property
            def store_connection(self):
                SharedState.borrowed = True
                return object()

        class Storage(object):
            class _tpc_phase(object):
                shared_state = SharedState()

        self.assertIsNone(relstorage_support.store_cursor(Storage()))
        self.assertFalse(SharedState.borrowed)

    def test_live_cursor_is_returned(self):
        cursor = object()

        class ManagedConnection(object):
            connection = object()

        managed = ManagedConnection()
        managed.cursor = cursor

        class SharedState(object):
            pass

        shared = SharedState()
        # A materialized Lazy lives in the instance dict, which is what
        # distinguishes "already borrowed" from "would borrow now".
        shared.store_connection = managed

        class Storage(object):
            class _tpc_phase(object):
                pass

        Storage._tpc_phase.shared_state = shared
        self.assertIs(relstorage_support.store_cursor(Storage()), cursor)

    def test_closed_connection_yields_nothing(self):
        class ClosedConnection(object):
            connection = None
            cursor = None

        class SharedState(object):
            pass

        shared = SharedState()
        shared.store_connection = ClosedConnection()

        class Storage(object):
            class _tpc_phase(object):
                pass

        Storage._tpc_phase.shared_state = shared
        self.assertIsNone(relstorage_support.store_cursor(Storage()))


#: Mappers built by :func:`recording_mapper`, which ZConfig names by
#: dotted path and so has to live at module level.
configured_mappers = []


def recording_mapper(connection):
    mapper = RecordingMapper(connection)
    configured_mappers.append(mapper)
    return mapper


class ZConfigTests(unittest.TestCase):

    def setUp(self):
        del configured_mappers[:]

    def _database(self, body=''):
        import ZODB.config
        return ZODB.config.databaseFromString(
            "<zodb>\n%s<mappingstorage>\n</mappingstorage>\n</zodb>\n" % body)

    def test_absent_by_default(self):
        db = self._database()
        try:
            self.assertIsNone(db.relational_mapper)
        finally:
            db.close()

    def test_mapper_named_by_dotted_path(self):
        db = self._database(
            "relational-mapper ZODB.tests.testrelational.recording_mapper\n")
        try:
            self.assertIs(db.relational_mapper, recording_mapper)
            conn = db.open()
            conn.root()['x'] = PersistentMapping()
            transaction.commit()
            self.assertTrue(configured_mappers)
            self.assertIn('tpc_finish', configured_mappers[0].calls)
            conn.close()
        finally:
            db.close()

    def test_unimportable_name_is_rejected(self):
        import ZConfig
        self.assertRaises(
            ZConfig.DataConversionError,
            self._database,
            "relational-mapper ZODB.tests.testrelational.no_such_thing\n")


def test_suite():
    suite = unittest.TestSuite()
    for klass in (MapperTests, PickleUnchangedTests, StoreCursorTests,
                  ZConfigTests):
        suite.addTest(unittest.makeSuite(klass))
    return suite
