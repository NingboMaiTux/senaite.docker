##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Real RelStorage, real PostgreSQL: proving the one thing that can't be
proved by reading source code.

Every other test in this package works against ``MappingStorage`` and
proves the mapper protocol is driven correctly. None of them can prove
the actual point of ``relstorage_support.py``: that the cursor it hands
back is a live connection to a real database, on which SQL genuinely
joins RelStorage's own transaction -- commits when it commits, and
rolls back when it doesn't, even after ``tpc_vote`` has already sent
statements over the wire.

Skipped unless ``ZODB_RELSTORAGE_TEST_DSN`` is set, since it needs a
running PostgreSQL: a psycopg2 DSN string naming a database that
already exists and is safe to create and drop tables in. Nothing here
ever touches a database other than the one named there -- in
particular, never any table this suite did not itself create.
"""
from __future__ import absolute_import

import os
import unittest

from persistent import Persistent

DSN = os.environ.get('ZODB_RELSTORAGE_TEST_DSN')

try:
    import psycopg2
    from relstorage.adapters.postgresql import PostgreSQLAdapter
    from relstorage.options import Options
    from relstorage.storage import RelStorage
except ImportError:
    RelStorage = None


class Analysis(Persistent):
    """Stands in for a Zope content object.

    Must stay at module level: pickle resolves a class by module and
    name, and a class defined inside a method has no such name to be
    found by.
    """
    portal_type = u'Analysis'


class _AnalysesField(object):
    """Enough of an Archetypes field for FieldInspector to recognise."""
    multiValued = True

    def getName(self):
        return 'Analyses'


# FieldInspector matches by exact class name (see fields.py), not
# inheritance from any real Archetypes base class, so this name -
# unlike everything else in this test module - is load-bearing and
# must not be prefixed or renamed.
class UIDReferenceField(_AnalysesField):
    pass


class _SampleSchema(object):
    @staticmethod
    def fields():
        return [UIDReferenceField()]


class Sample(Persistent):
    """Stands in for a content object with a multi-valued reference
    field -- an AnalysisRequest's own Analyses, in senaite's real
    shape. Must stay at module level; see Analysis above.
    """
    portal_type = u'AnalysisRequest'
    schema = _SampleSchema


@unittest.skipUnless(
    DSN and RelStorage is not None,
    "set ZODB_RELSTORAGE_TEST_DSN (and install RelStorage+psycopg2) to "
    "run this against a real PostgreSQL")
class RelStorageIntegrationTests(unittest.TestCase):

    def setUp(self):
        import transaction
        from ZODB.relational.derived import NUMERIC
        from ZODB.relational.derived import Derivations
        from ZODB.relational.mapper import BufferingMapper
        from ZODB.relational.projection import Projector
        from ZODB.relational.schema import PostgreSQLWriter

        self.transaction = transaction
        self.writer = PostgreSQLWriter()
        self._drop_our_tables()
        self.baseline_object_state_rows = self._count('object_state')

        def make_mapper(conn):
            # Mirrors what a real senaite deployment would configure:
            # Result is a measured value, so it gets the numeric/
            # operator derivation. See ZODB.relational.derived.
            projector = Projector(
                derivations=Derivations({('Analysis', 'Result'): NUMERIC}))
            return BufferingMapper(conn, projector=projector,
                                   writer=self.writer)

        import ZODB
        self.storage = RelStorage(
            adapter=PostgreSQLAdapter(dsn=DSN, options=Options()))
        self.db = ZODB.DB(self.storage, relational_mapper=make_mapper)
        self.conn = self.db.open()

    def tearDown(self):
        self.transaction.abort()
        self.conn.close()
        self.db.close()
        self._drop_our_tables()

    def _drop_our_tables(self):
        self._exec("DROP TABLE IF EXISTS analysis CASCADE")
        self._exec("DROP TABLE IF EXISTS analysis_request CASCADE")
        self._exec("DROP TABLE IF EXISTS workflow_transition CASCADE")
        self._exec("DROP TABLE IF EXISTS object_reference CASCADE")

    def _exec(self, sql, params=()):
        # A connection independent of RelStorage's, so a read through it
        # proves durability rather than just reading back what we
        # ourselves still hold open.
        conn = psycopg2.connect(DSN)
        conn.autocommit = True
        try:
            cur = conn.cursor()
            cur.execute(sql, params)
            return cur.fetchall() if cur.description else None
        finally:
            conn.close()

    def _exists(self, relation):
        return self._exec(
            "SELECT to_regclass(%s)", (relation,))[0][0] is not None

    def _count(self, table):
        if not self._exists(table):
            return 0
        return self._exec("SELECT count(*) FROM %s" % table)[0][0]

    def _make_analysis(self):
        from persistent.mapping import PersistentMapping

        a = Analysis()
        a.Result = u'<0.05'
        a._at_uid = u'11111111111111111111111111111111'
        import datetime
        a.DateReceived = datetime.datetime(2026, 9, 24, 10, 30)
        a.workflow_history = PersistentMapping()
        a.workflow_history['senaite_analysis_workflow'] = [
            {'action': None, 'actor': u'admin', 'comments': u'',
             'review_state': u'unassigned', 'time': 1},
            {'action': u'submit', 'actor': u'lab1', 'comments': u'',
             'review_state': u'to_be_verified', 'time': 2},
        ]
        return a

    def test_commit_is_visible_from_an_independent_connection(self):
        self.conn.root()['a'] = self._make_analysis()
        self.transaction.commit()

        rows = self._exec(
            "SELECT result, result_num, result_operator, uid, "
            "date_received FROM analysis")
        self.assertEqual(len(rows), 1)
        result, result_num, result_operator, uid, date_received = rows[0]
        self.assertEqual(result, '<0.05')
        self.assertAlmostEqual(result_num, 0.05)
        self.assertEqual(result_operator, '<')
        self.assertEqual(uid, '11111111111111111111111111111111')
        self.assertEqual(str(date_received)[:19], '2026-09-24 10:30:00')

        transitions = self._exec(
            "SELECT action, actor, review_state FROM workflow_transition "
            "ORDER BY sequence")
        self.assertEqual(transitions, [
            (None, 'admin', 'unassigned'),
            ('submit', 'lab1', 'to_be_verified'),
        ])

        # RelStorage's own write landed in the same commit, not just
        # ours.
        self.assertGreater(self._count('object_state'),
                           self.baseline_object_state_rows)

    def test_rows_written_during_vote_roll_back_with_relstorages_own(self):
        self.conn.root()['never_committed'] = self._make_analysis()
        txn = self.transaction.get()
        self.conn.tpc_begin(txn)
        self.conn.commit(txn)
        self.conn.tpc_vote(txn)
        # Our SQL has now actually gone over the wire, on RelStorage's
        # own connection: PostgreSQLWriter always ensures its sequence
        # exists first, so its presence here is proof of that (this is
        # not "we never tried").
        self.assertTrue(self._exists('zodb_write_seq'))
        self.conn.tpc_abort(txn)

        # Postgres DDL is transactional too, so the CREATE TABLE our
        # writer issued may have rolled back along with everything
        # else, in which case there is certainly no row in it.
        if self._exists('analysis'):
            rows = self._exec("SELECT * FROM analysis")
            self.assertEqual(rows, [])
        self.assertEqual(self._count('object_state'),
                         self.baseline_object_state_rows)

    def test_restoring_an_object_does_not_duplicate_its_transitions(self):
        # workflow_history is re-derived in full every time its object
        # is stored, in a real, separately-committed transaction this
        # time, not a savepoint within one: without something to
        # upsert against, this is exactly the scenario that would grow
        # the same two transitions into four, six, eight...
        a = self._make_analysis()
        self.conn.root()['a'] = a
        self.transaction.commit()

        a.Result = u'0.09'
        self.transaction.commit()
        a.Result = u'0.10'
        self.transaction.commit()

        transitions = self._exec(
            "SELECT action, actor FROM workflow_transition ORDER BY sequence")
        self.assertEqual(transitions, [(None, 'admin'), ('submit', 'lab1')])

    def test_write_seq_advances_on_update_not_just_insert(self):
        a = self._make_analysis()
        self.conn.root()['a'] = a
        self.transaction.commit()
        first = self._exec(
            "SELECT write_seq FROM analysis WHERE uid = %s",
            (a._at_uid,))[0][0]

        a.Result = u'0.09'
        self.transaction.commit()
        second = self._exec(
            "SELECT write_seq FROM analysis WHERE uid = %s",
            (a._at_uid,))[0][0]

        self.assertGreater(second, first)

    def test_write_seq_does_not_advance_when_nothing_changed(self):
        # The object's history is re-derived in full every time it is
        # stored, regardless of what actually changed about it -- so
        # without a guard, touching one field would make every OTHER
        # row derived from the same object (including transitions from
        # years ago) look freshly written too, to a consumer polling
        # write_seq.
        a = self._make_analysis()
        self.conn.root()['a'] = a
        self.transaction.commit()
        before = self._exec(
            "SELECT sequence, write_seq FROM workflow_transition "
            "ORDER BY sequence")

        # A real, unrelated change: re-stores the object, re-deriving
        # its whole (unchanged) transition history along the way.
        a.Result = u'0.09'
        self.transaction.commit()
        after = self._exec(
            "SELECT sequence, write_seq FROM workflow_transition "
            "ORDER BY sequence")

        self.assertEqual(before, after)

    def _references(self):
        return self._exec(
            "SELECT target_uid, position FROM object_reference "
            "WHERE field = 'Analyses' ORDER BY position")

    def test_reference_list_becomes_rows(self):
        sample = Sample()
        sample.Analyses = [u'uid-a', u'uid-b', u'uid-c']
        self.conn.root()['s'] = sample
        self.transaction.commit()
        self.assertEqual(
            self._references(),
            [('uid-a', 0), ('uid-b', 1), ('uid-c', 2)])

    def test_shrinking_the_list_deletes_the_stale_rows(self):
        sample = Sample()
        sample.Analyses = [u'uid-a', u'uid-b', u'uid-c']
        self.conn.root()['s'] = sample
        self.transaction.commit()

        sample.Analyses = [u'uid-a']
        self.transaction.commit()

        self.assertEqual(self._references(), [('uid-a', 0)])

    def test_emptying_the_list_deletes_every_row(self):
        sample = Sample()
        sample.Analyses = [u'uid-a', u'uid-b']
        self.conn.root()['s'] = sample
        self.transaction.commit()

        sample.Analyses = []
        self.transaction.commit()

        self.assertEqual(self._references(), [])

    def test_growing_the_list_adds_rows_without_touching_existing_ones(self):
        sample = Sample()
        sample.Analyses = [u'uid-a']
        self.conn.root()['s'] = sample
        self.transaction.commit()
        first_seq = self._exec(
            "SELECT write_seq FROM object_reference "
            "WHERE target_uid = 'uid-a'")[0][0]

        sample.Analyses = [u'uid-a', u'uid-b']
        self.transaction.commit()

        self.assertEqual(
            self._references(), [('uid-a', 0), ('uid-b', 1)])
        second_seq = self._exec(
            "SELECT write_seq FROM object_reference "
            "WHERE target_uid = 'uid-a'")[0][0]
        self.assertEqual(
            first_seq, second_seq,
            "an unrelated addition to the list must not touch an "
            "existing member's write_seq")

    def test_a_different_objects_list_is_not_affected(self):
        kept = Sample()
        kept.Analyses = [u'uid-keep']
        other = Sample()
        other.Analyses = [u'uid-other']
        self.conn.root()['kept'] = kept
        self.conn.root()['other'] = other
        self.transaction.commit()

        other.Analyses = []
        self.transaction.commit()

        self.assertEqual(self._references(), [('uid-keep', 0)])

    def test_a_bad_row_does_not_fail_the_real_commit(self):
        from ZODB.relational.rows import Row

        class Explosive(object):
            """A Projector stand-in whose second row is impossible SQL."""

            def __init__(self, real):
                self.real = real

            def project(self, oid, obj, state, pickle, is_new=False):
                if getattr(obj, 'Result', None) == u'BOOM':
                    return Row('analysis', oid, {
                        'result': type('Bad', (), {
                            'sql_type': 'obviously_not_a_real_pg_type',
                            'value': 'x'})()})
                return self.real.project(oid, obj, state, pickle, is_new)

        from ZODB.relational.derived import NUMERIC
        from ZODB.relational.derived import Derivations
        from ZODB.relational.mapper import BufferingMapper
        from ZODB.relational.projection import Projector

        real_projector = Projector(
            derivations=Derivations({('Analysis', 'Result'): NUMERIC}))

        def make_mapper(conn):
            return BufferingMapper(
                conn, projector=Explosive(real_projector), writer=self.writer)

        import ZODB
        db = ZODB.DB(self.storage, relational_mapper=make_mapper)
        conn = db.open()
        try:
            good = self._make_analysis()
            bad = Analysis()
            bad.Result = u'BOOM'
            conn.root()['good'] = good
            conn.root()['bad'] = bad
            # Must not raise: a broken row is this test's whole point,
            # and it must not become a failed commit.
            self.transaction.commit()
        finally:
            conn.close()
            db.close()

        # RelStorage's own data for BOTH objects committed regardless
        # -- the pickle is never at the mercy of the projection.
        self.assertGreater(self._count('object_state'),
                           self.baseline_object_state_rows)
        rows = self._exec("SELECT result FROM analysis")
        self.assertEqual([r[0] for r in rows], ['<0.05'])


@unittest.skipUnless(
    DSN and RelStorage is not None,
    "set ZODB_RELSTORAGE_TEST_DSN (and install RelStorage+psycopg2) to "
    "run this against a real PostgreSQL")
class ConcurrentConstraintCreationTests(unittest.TestCase):
    """Confirms the constraint-race handling against real PostgreSQL.

    The unit tests in testrelationalschema exercise this same code path
    with a fake, injected exception; nothing there proves that
    PostgreSQL's real duplicate-object SQLSTATE is really ``42710``, or
    that a second session really does hit it rather than, say,
    blocking forever on a lock. Both are asserted here instead.
    """

    def setUp(self):
        conn = psycopg2.connect(DSN)
        conn.autocommit = True
        cur = conn.cursor()
        cur.execute("DROP TABLE IF EXISTS workflow_transition CASCADE")
        cur.execute(
            "CREATE TABLE workflow_transition ("
            "id bigserial PRIMARY KEY, content_oid bigint, "
            "workflow_id text, sequence bigint)")
        conn.close()

    def tearDown(self):
        conn = psycopg2.connect(DSN)
        conn.autocommit = True
        conn.cursor().execute(
            "DROP TABLE IF EXISTS workflow_transition CASCADE")
        conn.close()

    def test_two_sessions_racing_to_add_the_constraint(self):
        from ZODB.relational.rows import Row
        from ZODB.relational.schema import PostgreSQLWriter

        row = Row('workflow_transition', None, {
            'content_oid': _Value('bigint', 1),
            'workflow_id': _Value('text', 'wf'),
            'sequence': _Value('bigint', 0),
        }, natural_key=('content_oid', 'workflow_id', 'sequence'))

        conn_a = psycopg2.connect(DSN)
        conn_b = psycopg2.connect(DSN)
        try:
            cursor_a = conn_a.cursor()
            cursor_b = conn_b.cursor()
            writer_a = PostgreSQLWriter()
            writer_b = PostgreSQLWriter()
            # Each writer must believe the table already exists (so it
            # goes straight for the constraint, the part under test),
            # without believing the constraint itself already does.
            writer_a.cache.learned_table('workflow_transition')
            writer_b.cache.learned_table('workflow_transition')

            writer_a._ensure_natural_key_constraint(cursor_a, row, [])
            conn_a.commit()
            # Should not raise, and should recognise the real race
            # rather than treating it as an unrecognised error.
            writer_b._ensure_natural_key_constraint(cursor_b, row, [])
            conn_b.commit()
        finally:
            conn_a.close()
            conn_b.close()

        conn = psycopg2.connect(DSN)
        conn.autocommit = True
        count = conn.cursor()
        count.execute(
            "SELECT count(*) FROM information_schema.table_constraints "
            "WHERE table_name = 'workflow_transition' "
            "AND constraint_type = 'UNIQUE'")
        self.assertEqual(count.fetchone()[0], 1)
        conn.close()


def _Value(sql_type, value):
    from ZODB.relational.valuetypes import Value
    return Value(sql_type, value)


@unittest.skipUnless(
    DSN and RelStorage is not None,
    "set ZODB_RELSTORAGE_TEST_DSN (and install RelStorage+psycopg2) to "
    "run this against a real PostgreSQL")
class SenaiteWiringIntegrationTests(unittest.TestCase):
    """The actual production wiring (ZODB.relational.senaite), not the
    hand-assembled Projector+Derivations the tests above build for
    themselves -- proving the thing a real ``zope.conf`` would point
    at actually works end to end, against real PostgreSQL.
    """

    def setUp(self):
        from ZODB.relational import senaite

        self.senaite = senaite
        self._original_writer = senaite.writer
        senaite.writer = senaite.PostgreSQLWriter()
        self._drop_our_tables()

    def tearDown(self):
        self.senaite.writer = self._original_writer
        self._drop_our_tables()

    def _drop_our_tables(self):
        conn = psycopg2.connect(DSN)
        conn.autocommit = True
        cur = conn.cursor()
        cur.execute("DROP TABLE IF EXISTS analysis CASCADE")
        conn.close()

    def test_mapper_factory_writes_a_derived_result_for_real(self):
        import ZODB
        import transaction

        db = ZODB.DB(
            RelStorage(adapter=PostgreSQLAdapter(dsn=DSN, options=Options())),
            relational_mapper=self.senaite.mapper_factory)
        conn = db.open()
        try:
            a = Analysis()
            a.Result = u'<0.05'
            conn.root()['a'] = a
            transaction.commit()
        finally:
            conn.close()
            db.close()

        read_conn = psycopg2.connect(DSN)
        read_conn.autocommit = True
        cur = read_conn.cursor()
        cur.execute(
            "SELECT result, result_num, result_operator FROM analysis")
        rows = cur.fetchall()
        read_conn.close()
        self.assertEqual(rows, [('<0.05', 0.05, '<')])


def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(RelStorageIntegrationTests))
    suite.addTest(unittest.makeSuite(ConcurrentConstraintCreationTests))
    suite.addTest(unittest.makeSuite(SenaiteWiringIntegrationTests))
    return suite
