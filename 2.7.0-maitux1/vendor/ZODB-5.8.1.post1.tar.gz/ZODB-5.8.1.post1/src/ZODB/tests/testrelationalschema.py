##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Tests for the SQL-generation half of the relational writer.

These test SQL generation, caching and error isolation with a fake
cursor -- no real PostgreSQL needed for any of it, which is also why
none of this can prove the SQL is actually valid PostgreSQL syntax or
that ``ON CONFLICT`` really behaves this way. That proof lives in
``testrelational_relstorage``, against the real thing.
"""
from __future__ import absolute_import

import re
import unittest

from ZODB.relational import schema
from ZODB.relational.rows import Row
from ZODB.relational.valuetypes import NULL
from ZODB.relational.valuetypes import Value


class FakeStorage(object):
    """Just enough for relstorage_support.store_cursor() to find a cursor."""

    def __init__(self, cursor):
        class Connection(object):
            pass

        connection = Connection()
        connection.cursor = cursor
        connection.connection = object()  # not None: "open"

        class SharedState(object):
            pass

        shared_state = SharedState()
        shared_state.store_connection = connection

        class Phase(object):
            pass

        Phase.shared_state = shared_state
        self._tpc_phase = Phase


class FakeCursor(object):
    """Records every statement; can be told to raise on a chosen one."""

    def __init__(self, raise_on=None):
        self.statements = []
        self.raise_on = dict(raise_on or {})

    def execute(self, sql, params=None):
        self.statements.append((sql, params))
        for substring, exc in self.raise_on.items():
            if substring in sql:
                raise exc

    def sql_containing(self, substring):
        return [sql for (sql, params) in self.statements if substring in sql]


class DuplicateTable(Exception):
    """What PostgreSQL really raises; see schema.py's already_exists_code."""
    pgcode = '42P07'


def content_row(oid=7, columns=None, is_new=False, table='analysis'):
    return Row(table, oid, dict(columns or {}), is_new=is_new)


def transition_row(columns):
    return Row('workflow_transition', None, dict(columns),
               natural_key=('content_oid', 'workflow_id', 'sequence'))


def reference_row(content_oid, target_uid, position=0, field='Analyses'):
    return Row('object_reference', None, {
        'content_oid': Value('bigint', content_oid),
        'field': Value('text', field),
        'target_uid': Value('text', target_uid),
        'position': Value('bigint', position),
    }, natural_key=('content_oid', 'field', 'target_uid'))


def parent_row(content_oid, children, field='Analyses'):
    prune = [('object_reference',
             {'content_oid': content_oid, 'field': field},
             ('target_uid',))]
    return Row('analysis_request', content_oid, {}, children=children,
               prune=prune)


class QuoteIdentTests(unittest.TestCase):

    def test_plain_name(self):
        self.assertEqual(schema.quote_ident('analysis'), '"analysis"')

    def test_embedded_quote_is_escaped(self):
        self.assertEqual(schema.quote_ident('a"b'), '"a""b"')


class WriteTests(unittest.TestCase):

    def setUp(self):
        self.cursor = FakeCursor()
        self.storage = FakeStorage(self.cursor)
        self.writer = schema.PostgreSQLWriter(
            already_exists_code=DuplicateTable.pgcode)

    def test_no_live_cursor_is_not_an_error(self):
        class NoConnection(object):
            _tpc_phase = None

        # Should not raise.
        self.writer.write([content_row()], NoConnection())

    def test_sequence_is_created_once(self):
        self.writer.write(
            [content_row(columns={'result': Value('text', 'x')})],
            self.storage)
        self.writer.write(
            [content_row(columns={'result': Value('text', 'y')})],
            self.storage)
        creates = self.cursor.sql_containing('CREATE SEQUENCE')
        self.assertEqual(len(creates), 1)

    def test_table_created_once_across_writes(self):
        for value in ('a', 'b', 'c'):
            self.writer.write(
                [content_row(columns={'result': Value('text', value)})],
                self.storage)
        creates = self.cursor.sql_containing('CREATE TABLE')
        self.assertEqual(len(creates), 1)
        self.assertIn('"analysis"', creates[0])
        self.assertIn('"oid" bigint PRIMARY KEY', creates[0])
        self.assertIn('"write_seq" bigint NOT NULL DEFAULT', creates[0])

    def test_column_added_once_across_writes(self):
        for value in ('a', 'b'):
            self.writer.write(
                [content_row(columns={'result': Value('text', value)})],
                self.storage)
        alters = self.cursor.sql_containing('ADD COLUMN')
        self.assertEqual(len(alters), 1)
        self.assertIn('"result" text', alters[0])

    def test_second_row_adds_only_its_new_column(self):
        self.writer.write(
            [content_row(oid=1, columns={'result': Value('text', 'x')})],
            self.storage)
        self.writer.write(
            [content_row(oid=2, columns={'result': Value('text', 'y'),
                                         'uid': Value('text', 'u')})],
            self.storage)
        alters = self.cursor.sql_containing('ADD COLUMN')
        self.assertEqual(len(alters), 2)
        self.assertIn('"uid" text', alters[1])

    def test_null_value_adds_no_column_and_is_not_inserted(self):
        self.writer.write(
            [content_row(columns={'action': NULL})], self.storage)
        self.assertEqual(self.cursor.sql_containing('ADD COLUMN'), [])
        insert = self.cursor.sql_containing('INSERT')[0]
        self.assertNotIn('action', insert)

    def test_null_value_is_insertable_once_column_exists(self):
        self.writer.write(
            [content_row(oid=1, columns={'action': Value('text', 'submit')})],
            self.storage)
        self.writer.write(
            [content_row(oid=2, columns={'action': NULL})], self.storage)
        insert_sql, insert_params = [
            (s, p) for (s, p) in self.cursor.statements if 'INSERT' in s][-1]
        self.assertIn('"action"', insert_sql)
        self.assertIn(None, insert_params)

    def test_oid_row_upserts_on_oid(self):
        self.writer.write(
            [content_row(columns={'result': Value('text', 'x')})],
            self.storage)
        sql, params = [(s, p) for (s, p) in self.cursor.statements
                       if 'INSERT' in s][0]
        self.assertIn('ON CONFLICT ("oid")', sql)
        self.assertIn('DO UPDATE SET', sql)
        self.assertIn('"write_seq" = nextval(', sql)
        self.assertIn(7, params)

    def test_update_is_guarded_against_unchanged_values(self):
        # Without this, re-deriving an object's whole current state on
        # every commit -- which is what every row here does -- would
        # bump write_seq on every column of every row derived from an
        # object every time that object is merely stored again, whether
        # or not the specific value actually changed.
        self.writer.write(
            [content_row(columns={'result': Value('text', 'x'),
                                  'uid': Value('text', 'u')})],
            self.storage)
        sql = self.cursor.sql_containing('ON CONFLICT')[0]
        match = re.search(
            r'WHERE \(([^)]+)\) IS DISTINCT FROM \(([^)]+)\)', sql)
        self.assertIsNotNone(match, sql)
        left = [c.strip() for c in match.group(1).split(',')]
        right = [c.strip() for c in match.group(2).split(',')]
        # The "old value" side must be table-qualified: both the table
        # and EXCLUDED are in scope in this WHERE clause, and every one
        # of these columns exists on both sides by construction, so an
        # unqualified name is rejected outright as ambiguous rather
        # than resolved to the table -- caught only by testing against
        # a real server, not by this fake cursor (see
        # testrelational_relstorage).
        self.assertEqual(
            set(left), {'"analysis"."result"', '"analysis"."uid"'})
        # Same columns, same order as the left side, just qualified
        # differently: the two sides are built from the same list, so
        # this is a structural guarantee, not a coincidence of dict
        # ordering.
        self.assertEqual(
            right,
            [c.replace('"analysis".', 'EXCLUDED.') for c in left])

    def test_natural_key_row_creates_constraint_after_columns(self):
        self.writer.write([transition_row({
            'content_oid': Value('bigint', 1),
            'workflow_id': Value('text', 'wf'),
            'sequence': Value('bigint', 0),
            'actor': Value('text', 'admin'),
        })], self.storage)

        statements = [sql for (sql, params) in self.cursor.statements]
        add_constraint_index = next(
            i for i, s in enumerate(statements) if 'ADD CONSTRAINT' in s)
        add_column_indexes = [
            i for i, s in enumerate(statements) if 'ADD COLUMN' in s]
        self.assertTrue(add_column_indexes)
        self.assertTrue(all(i < add_constraint_index
                            for i in add_column_indexes))
        self.assertIn('UNIQUE ("content_oid", "workflow_id", "sequence")',
                      statements[add_constraint_index])

    def test_natural_key_row_upserts_do_nothing_when_no_other_columns(self):
        self.writer.write([transition_row({
            'content_oid': Value('bigint', 1),
            'workflow_id': Value('text', 'wf'),
            'sequence': Value('bigint', 0),
        })], self.storage)
        insert = self.cursor.sql_containing('INSERT')[0]
        self.assertIn(
            'ON CONFLICT ("content_oid", "workflow_id", "sequence") '
            'DO NOTHING', insert)

    def test_natural_key_row_upserts_with_do_update_when_more_to_say(self):
        self.writer.write([transition_row({
            'content_oid': Value('bigint', 1),
            'workflow_id': Value('text', 'wf'),
            'sequence': Value('bigint', 0),
            'actor': Value('text', 'admin'),
        })], self.storage)
        insert = self.cursor.sql_containing('INSERT')[0]
        self.assertIn('DO UPDATE SET "actor" = EXCLUDED."actor"', insert)
        # The key columns must not be listed a second time as ordinary
        # columns in the VALUES list -- PostgreSQL rejects a column
        # named twice in one INSERT's column list outright. (It is
        # expected and correct for "content_oid" to also appear once
        # more, in the ON CONFLICT target.)
        column_list = insert[insert.index('('):insert.index('VALUES')]
        self.assertEqual(column_list.count('"content_oid"'), 1)

    def test_constraint_race_is_absorbed(self):
        cursor = FakeCursor(raise_on={
            'ADD CONSTRAINT': DuplicateTable()})
        storage = FakeStorage(cursor)
        writer = schema.PostgreSQLWriter(
            already_exists_code=DuplicateTable.pgcode)
        # Should not raise, and the row should still be written.
        writer.write([transition_row({
            'content_oid': Value('bigint', 1),
            'workflow_id': Value('text', 'wf'),
            'sequence': Value('bigint', 0),
        })], storage)
        self.assertTrue(cursor.sql_containing('ROLLBACK TO SAVEPOINT '
                                              'maizodb_constraint'))
        self.assertTrue(cursor.sql_containing('INSERT'))

    def test_unrecognised_error_during_constraint_is_not_absorbed(self):
        cursor = FakeCursor(raise_on={'ADD CONSTRAINT': RuntimeError('boom')})
        storage = FakeStorage(cursor)
        writer = schema.PostgreSQLWriter(
            already_exists_code=DuplicateTable.pgcode)
        # The row-level savepoint in write() catches this -- it must
        # not escape to fail the caller's transaction -- but the
        # attempt to write this one row's data must not have happened.
        writer.write([transition_row({
            'content_oid': Value('bigint', 1),
            'workflow_id': Value('text', 'wf'),
            'sequence': Value('bigint', 0),
        })], storage)
        self.assertEqual(cursor.sql_containing('INSERT'), [])
        self.assertTrue(cursor.sql_containing('ROLLBACK TO SAVEPOINT '
                                              'maizodb_row'))

    def test_one_bad_row_does_not_stop_the_others(self):
        cursor = FakeCursor(raise_on={'"bad_table"': RuntimeError('boom')})
        storage = FakeStorage(cursor)
        writer = schema.PostgreSQLWriter(
            already_exists_code=DuplicateTable.pgcode)
        writer.write([
            content_row(oid=1, table='bad_table',
                        columns={'x': Value('text', '1')}),
            content_row(oid=2, table='good_table',
                        columns={'x': Value('text', '2')}),
        ], storage)
        self.assertTrue(cursor.sql_containing('"good_table"'))
        good_inserts = [
            sql for (sql, params) in cursor.statements
            if 'INSERT' in sql and 'good_table' in sql]
        self.assertEqual(len(good_inserts), 1)

    def test_sequence_failure_skips_the_whole_batch(self):
        cursor = FakeCursor(raise_on={'CREATE SEQUENCE': RuntimeError('down')})
        storage = FakeStorage(cursor)
        writer = schema.PostgreSQLWriter()
        writer.write([content_row(columns={'x': Value('text', '1')})],
                     storage)
        self.assertEqual(cursor.sql_containing('INSERT'), [])
        self.assertTrue(cursor.sql_containing('ROLLBACK TO SAVEPOINT '
                                              'maizodb_sequence'))

    def test_bytea_value_is_wrapped(self):
        wrapped = []

        def binary(value):
            wrapped.append(value)
            return ('WRAPPED', value)

        writer = schema.PostgreSQLWriter(binary=binary)
        writer.write([content_row(
            columns={'zodb_state': Value('bytea', b'pickle-bytes')})],
            self.storage)
        self.assertEqual(wrapped, [b'pickle-bytes'])

    def test_shared_cache_means_no_ddl_on_a_second_writer_call(self):
        cache = schema.SchemaCache()
        writer_one = schema.PostgreSQLWriter(cache=cache)
        writer_two = schema.PostgreSQLWriter(cache=cache)
        writer_one.write(
            [content_row(oid=1, columns={'result': Value('text', 'x')})],
            self.storage)
        before = len(self.cursor.statements)
        writer_two.write(
            [content_row(oid=2, columns={'result': Value('text', 'y')})],
            self.storage)
        after = self.cursor.statements[before:]
        self.assertEqual([s for (s, p) in after if 'CREATE TABLE' in s
                         or 'ADD COLUMN' in s or 'CREATE SEQUENCE' in s], [])


class PruneTests(unittest.TestCase):

    def setUp(self):
        self.cursor = FakeCursor()
        self.storage = FakeStorage(self.cursor)
        self.writer = schema.PostgreSQLWriter(
            already_exists_code=DuplicateTable.pgcode)

    def _deletes(self):
        return [(s, p) for (s, p) in self.cursor.statements
                if s.startswith('DELETE')]

    def test_prune_runs_after_all_upserts(self):
        child = reference_row(1, u'uid-a')
        parent = parent_row(1, [child])
        self.writer.write([parent, child], self.storage)
        statements = [s for (s, p) in self.cursor.statements]
        insert_index = max(i for i, s in enumerate(statements)
                           if 'INSERT' in s)
        delete_index = statements.index(self._deletes()[0][0])
        self.assertGreater(delete_index, insert_index)

    def test_kept_siblings_are_excluded_from_deletion(self):
        child = reference_row(1, u'uid-a')
        parent = parent_row(1, [child])
        self.writer.write([parent, child], self.storage)
        sql, params = self._deletes()[0]
        self.assertIn('"object_reference"', sql)
        self.assertIn('"content_oid" = %s', sql)
        self.assertIn('"field" = %s', sql)
        self.assertIn('NOT IN', sql)
        self.assertIn(1, params)
        self.assertIn(u'Analyses', params)
        self.assertIn(u'uid-a', params)

    def test_no_kept_siblings_deletes_the_whole_scope(self):
        # The field was emptied out entirely: nothing to protect. This
        # object's rows already exist from an earlier commit -- hence
        # seeding the cache -- since that is the only way this object
        # can have anything for the empty field to have been emptied
        # *of*.
        self.writer.cache.learned_table('object_reference')
        parent = parent_row(1, [])
        self.writer.write([parent], self.storage)
        sql, params = self._deletes()[0]
        self.assertNotIn('NOT IN', sql)
        self.assertEqual(params, [1, u'Analyses'])

    def test_first_ever_write_with_an_empty_field_prunes_nothing(self):
        # The exact opposite precondition from the test above: this
        # object has never been written before, object_reference does
        # not exist anywhere yet, and its reference field happens to be
        # empty. Nothing to insert and nothing to prune -- this must not
        # be confused with "the table exists but happens to be empty".
        parent = parent_row(1, [])
        self.writer.write([parent], self.storage)
        self.assertEqual(self._deletes(), [])

    def test_a_different_objects_rows_are_not_treated_as_kept(self):
        # object 1's prune must not be satisfied by object 2's rows,
        # even though both are in the same table in the same batch.
        other_objects_child = reference_row(2, u'uid-z')
        parent = parent_row(1, [])
        self.writer.write([parent, other_objects_child], self.storage)
        sql, params = self._deletes()[0]
        self.assertNotIn('NOT IN', sql)

    def test_prune_failure_is_isolated(self):
        cursor = FakeCursor(raise_on={'DELETE': RuntimeError('boom')})
        storage = FakeStorage(cursor)
        writer = schema.PostgreSQLWriter()
        child = reference_row(1, u'uid-a')
        parent = parent_row(1, [child])
        # Must not raise: a failed prune must not fail the commit that
        # already, successfully, wrote real data.
        writer.write([parent, child], storage)
        self.assertTrue(
            cursor.sql_containing('ROLLBACK TO SAVEPOINT maizodb_prune'))
        # The child row's own insert is unaffected by the later,
        # unrelated prune failure.
        self.assertTrue(cursor.sql_containing('INSERT'))


def test_suite():
    suite = unittest.TestSuite()
    for klass in (QuoteIdentTests, WriteTests, PruneTests):
        suite.addTest(unittest.makeSuite(klass))
    return suite
