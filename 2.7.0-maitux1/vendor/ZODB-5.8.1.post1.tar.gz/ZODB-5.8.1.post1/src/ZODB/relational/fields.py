##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Asking a content class which of its fields point at other objects.

A reference between two content objects is stored as the target's UID,
which is an ordinary string: nothing about the value distinguishes
``Client`` holding a UID from ``Title`` holding a sentence. The
difference has to come from the class's schema.

It has to come from the *class*, not the value, because a column's
identity must not depend on what happened to be in it. If an empty
reference looked like plain text and a filled one looked like a
reference, one field would drift between two columns, and anything
reading the projection downstream would break.

What this buys is an index on the columns joins are written against.
The column itself is named and typed the same either way, so a class
this cannot read -- Dexterity schemas are not introspected yet -- still
gets a perfectly usable text column holding the UID, just without the
index.
"""
from __future__ import absolute_import


#: Field classes holding a reference to another object. Matched by name
#: so that neither Archetypes nor senaite has to be importable here.
REFERENCE_FIELD_NAMES = frozenset([
    'UIDReferenceField',
    'ReferenceField',
])


class FieldInfo(object):
    """What the schema says about one field."""

    __slots__ = ('name', 'is_reference', 'multi_valued')

    def __init__(self, name, is_reference=False, multi_valued=False):
        self.name = name
        self.is_reference = is_reference
        self.multi_valued = multi_valued

    def __repr__(self):
        return '<FieldInfo %s%s%s>' % (
            self.name,
            ' reference' if self.is_reference else '',
            ' multi' if self.multi_valued else '')


class FieldInspector(object):
    """Reads schemas, once per class.

    Schemas do not change while a process runs, and this is consulted
    for every object of every commit, so the answer is cached against
    the class.
    """

    def __init__(self, reference_field_names=REFERENCE_FIELD_NAMES):
        self.reference_field_names = frozenset(reference_field_names)
        self._cache = {}

    def fields(self, klass):
        """``{field name: FieldInfo}`` for a content class.

        Empty for a class whose schema cannot be read, which is not an
        error: its values still become columns, just without knowing
        which of them are references.
        """
        try:
            return self._cache[klass]
        except KeyError:
            pass
        except TypeError:
            # Unhashable class. Answer without caching.
            return self._read(klass)
        info = self._read(klass)
        self._cache[klass] = info
        return info

    def references(self, klass):
        """Names of the fields holding a single reference."""
        return set(name for name, info in self.fields(klass).items()
                   if info.is_reference and not info.multi_valued)

    def multi_references(self, klass):
        """Names of the fields holding a list of references."""
        return set(name for name, info in self.fields(klass).items()
                   if info.is_reference and info.multi_valued)

    def _read(self, klass):
        info = {}
        for field in self._schema_fields(klass):
            try:
                name = field.getName()
            except Exception:
                continue
            if not name:
                continue
            info[name] = FieldInfo(
                name,
                is_reference=self._is_reference(field),
                multi_valued=bool(getattr(field, 'multiValued', False)))
        return info

    def _schema_fields(self, klass):
        # The Archetypes schema, read off the class rather than the
        # instance: instance access runs schema extenders, which means
        # adapter lookups in the middle of a commit.
        schema = getattr(klass, 'schema', None)
        if schema is None:
            return ()
        fields = getattr(schema, 'fields', None)
        if not callable(fields):
            return ()
        try:
            return fields()
        except Exception:
            return ()

    def _is_reference(self, field):
        for base in type(field).__mro__:
            if base.__name__ in self.reference_field_names:
                return True
        return False
