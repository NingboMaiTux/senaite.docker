##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Extra columns computed from a stored value.

A measured result is stored as text, because a laboratory has to be
able to record ``<0.05`` or ``ND`` as readily as ``5.2``. Text cannot be
averaged or compared, so a field declared numeric gets companion
columns beside the original: the number, where there is one, and the
operator that qualified it.

The original column is always kept as it was stored. The companions are
derived, never a replacement, so nothing is lost and no value has to be
made to fit.

Which fields get this is configuration -- these are laboratory
judgements, not facts about ZODB. A senaite deployment would say::

    Derivations({('Analysis', 'Result'): NUMERIC})
"""
from __future__ import absolute_import

import re

from ZODB.relational.valuetypes import UNMAPPED
from ZODB.relational.valuetypes import Value


#: Leading comparison operator, then a number: ``<0.05``, ``>= 100``.
_QUALIFIED_NUMBER = re.compile(
    r'^\s*(?P<operator><=|>=|<|>|=)?\s*(?P<number>[-+]?(?:\d+\.?\d*|\.\d+)'
    r'(?:[eE][-+]?\d+)?)\s*$')


class Derivation(object):
    """Companion columns computed from one field's value."""

    #: Suffixes this derivation appends, so the schema knows the shape
    #: of a table before any row has arrived.
    suffixes = ()

    def derive(self, value):
        """``{suffix: Value}`` for this value."""
        raise NotImplementedError


class Numeric(Derivation):
    """Pull a number, and any comparison operator, out of a result.

    ``5.2`` gives 5.2. ``<0.05`` gives 0.05 qualified by ``<``, so a
    query can average the numbers and still see which were below a
    detection limit. ``ND`` gives nothing, and the row simply has no
    number -- which is the truth, and is what an aggregate should skip.
    """

    suffixes = ('num', 'operator')

    def derive(self, value):
        if isinstance(value, bytes):
            try:
                value = value.decode('utf-8')
            except UnicodeDecodeError:
                return {}
        if isinstance(value, bool):
            return {}
        if isinstance(value, (int, float)):
            return {'num': Value('double precision', float(value))}
        if not isinstance(value, type(u'')):
            return {}

        match = _QUALIFIED_NUMBER.match(value)
        if match is None:
            return {}
        try:
            number = float(match.group('number'))
        except (ValueError, OverflowError):
            return {}
        derived = {'num': Value('double precision', number)}
        operator = match.group('operator')
        if operator and operator != '=':
            derived['operator'] = Value('text', operator)
        return derived


#: The derivation a measured value wants.
NUMERIC = Numeric()


class Derivations(object):
    """Which fields get companion columns.

    :param fields: ``{(portal type, field name): Derivation}``. Empty by
        default: ZODB has no opinion about which of an application's
        fields are measurements.
    """

    def __init__(self, fields=None):
        self.fields = dict(fields or {})

    def for_field(self, portal_type, field):
        return self.fields.get((portal_type, field))

    def derive(self, portal_type, field, value):
        """``{suffix: Value}``, empty when the field derives nothing."""
        derivation = self.for_field(portal_type, field)
        if derivation is None or value is None:
            return {}
        derived = derivation.derive(value)
        return dict((suffix, converted)
                    for suffix, converted in derived.items()
                    if converted is not UNMAPPED)

    def suffixes(self, portal_type, field):
        derivation = self.for_field(portal_type, field)
        return derivation.suffixes if derivation is not None else ()
