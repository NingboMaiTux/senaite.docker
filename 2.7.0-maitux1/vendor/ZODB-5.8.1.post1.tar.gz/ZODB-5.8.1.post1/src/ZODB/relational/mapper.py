##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Collecting a transaction's rows and handing them over at the vote.

Rows are held until the storage has voted rather than written as each
object goes by, for two reasons. The transaction id the rows want to be
stamped with is not assigned until then; and an object can be stored
more than once in one transaction, or stored and then taken back by a
savepoint rollback, so what the transaction finally says about an object
is only settled at the end.
"""
from __future__ import absolute_import

import logging

from ZODB.relational import Mapper
from ZODB.relational.projection import Projector
from ZODB.utils import u64

logger = logging.getLogger('ZODB.relational')


class BufferingMapper(Mapper):
    """Projects objects into rows and gives them to a writer at the vote.

    :param connection: the connection being committed.
    :param projector: turns objects into rows.
    :param writer: given ``(rows, storage)`` at the vote, or ``None`` to
        collect rows and write nothing, which is what the tests and a
        dry run use.
    """

    def __init__(self, connection, projector=None, writer=None):
        self.connection = connection
        self.projector = projector if projector is not None else Projector()
        self.writer = writer
        self.rows = []

    def tpc_begin(self, transaction):
        # Deliberately not clearing: a savepoint stores objects before
        # the commit begins, so by now there may already be rows for
        # this very transaction. The buffer is cleared when the
        # transaction ends, not when its commit starts.
        pass

    def record(self, oid, obj, state, pickle, is_new):
        self.rows.append(
            self.projector.project(oid, obj, state, pickle, is_new))

    def tpc_vote(self, storage):
        rows = self.settled_rows()
        if self.writer is None or not rows:
            return
        try:
            self.writer.write(rows, storage)
        except Exception:
            # However well-behaved a writer is expected to be (see the
            # note on Mapper.tpc_vote), this is the reference mapper,
            # so it is the backstop: a bug in the relational projection
            # must never be the reason a real commit fails. A writer
            # that already isolates its own per-row failures, such as
            # PostgreSQLWriter, should never actually reach here.
            logger.exception(
                "Relational mapper's writer raised during tpc_vote; "
                "the projection for this transaction is incomplete, but "
                "the transaction itself is not affected.")

    def tpc_finish(self, tid):
        self.rows = []

    def tpc_abort(self):
        self.rows = []

    def abort(self):
        self.rows = []

    def settled_rows(self):
        """The rows this transaction actually stands behind.

        Drops objects a savepoint rollback took back, which were
        recorded before being abandoned and would otherwise be written
        for objects the transaction never stored; and, where an object
        was stored more than once, keeps only what was said about it
        last -- including that last row's own ``children``, so a stale
        copy of an object cannot leave behind children a fresher copy
        never produced.
        """
        stored = self._stored_oids()
        settled = {}
        for row in self.rows:
            if stored is not None and row.oid not in stored:
                continue
            settled[row.oid] = row
        # Insertion order is not meaningful across a dict on Python 2,
        # and rows are independent of each other, so sort for a stable
        # write order: it keeps deadlocks between concurrent
        # transactions from depending on the order objects happened to
        # be serialized in.
        result = []
        for oid in sorted(settled):
            row = settled[oid]
            result.append(row)
            result.extend(row.children)
        return result

    def _stored_oids(self):
        """OIDs the connection is committing, or None if it will not say.

        ``_modified`` and ``_creating`` are what the connection itself
        hands to the storage, so they are the authority on what is in
        the transaction once the objects have all been stored.
        """
        connection = self.connection
        try:
            modified = connection._modified
            creating = connection._creating
        except AttributeError:
            return None
        return set(u64(oid) for oid in modified) | set(
            u64(oid) for oid in creating)
