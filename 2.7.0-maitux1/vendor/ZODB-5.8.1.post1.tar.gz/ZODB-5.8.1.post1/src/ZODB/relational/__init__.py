##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Relational projection of persistent object state.

While an object graph is committed, ZODB hands each object's state to a
*mapper* configured on the database, which projects that state into real
relational tables alongside the pickle that the storage writes anyway.
The pickle remains authoritative and the read path is untouched: the
tables exist so the data can be queried with ordinary SQL and shipped to
downstream consumers.

No mapper is configured by default, in which case none of this code runs
and ZODB behaves exactly as it does without this package.

A mapper is any object implementing the protocol described by
:class:`Mapper`. It is installed with the ``relational_mapper`` argument
to :class:`ZODB.DB.DB`, or the ``relational-mapper`` key of a ``zodb``
ZConfig section.
"""
from __future__ import absolute_import


class Mapper(object):
    """The protocol a relational mapper must implement.

    One mapper instance serves one :class:`~ZODB.Connection.Connection`,
    so implementations do not need to be thread safe, but a single
    instance is reused across many transactions on that connection.

    The methods are called in this order during a successful commit::

        tpc_begin  record*  tpc_vote  tpc_finish

    with one wrinkle: ``record`` also happens *before* ``tpc_begin``,
    once per savepoint, because taking a savepoint stores objects.
    A mapper must therefore treat ``tpc_begin`` as news about the
    storage rather than as the start of its own bookkeeping, and must
    not throw away what savepoints have already told it.

    Either ``tpc_abort`` or ``abort`` ends the transaction instead,
    depending on whether the commit had begun, and both must leave the
    mapper ready for a fresh one. Because rows are written on the
    storage's own connection, an aborted transaction discards them
    without the mapper having to undo anything itself.

    Subclassing is optional; this class exists to document the protocol
    and to give implementations sane no-op defaults.
    """

    def tpc_begin(self, transaction):
        """Begin a transaction. Any state left over from a previous one
        must be discarded here."""

    def record(self, oid, obj, state, pickle, is_new):
        """Take note of one object being stored.

        ``state`` is what ``obj.__getstate__()`` returned and ``pickle``
        is the record built from it -- the very bytes handed to the
        storage, so the projection and the stored record cannot
        disagree. ``is_new`` is true when the object is being created
        rather than modified.

        Implementations should buffer rather than write: a savepoint
        rollback can still discard these objects, and the transaction id
        the rows want to be stamped with is not assigned until the vote.
        """

    def tpc_vote(self, storage):
        """Write the recorded rows.

        Called once the storage has voted, which is the last moment at
        which the storage's transaction is still open. Raising from here
        aborts the whole transaction, so a mapper that would rather lose
        its projection than fail the user's commit must swallow its own
        errors.
        """

    def tpc_finish(self, tid):
        """The transaction committed, with transaction id ``tid``."""

    def tpc_abort(self):
        """The commit was aborted. Discard anything buffered."""

    def abort(self):
        """The transaction was abandoned before the commit began.

        Distinct from ``tpc_abort`` only in that the storage was never
        told anything; the mapper may still be holding objects recorded
        by a savepoint.
        """
