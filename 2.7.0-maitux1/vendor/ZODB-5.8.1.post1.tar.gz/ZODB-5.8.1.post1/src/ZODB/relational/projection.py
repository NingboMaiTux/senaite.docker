##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Turning a stored object into the row that represents it.

Two kinds of object come past, and they are here for different reasons.

Content objects -- a sample, an analysis, a client -- are what the
laboratory asks questions about, so their fields are spread across
columns that can be filtered, joined and aggregated.

Everything else -- the BTrees a folder keeps its children in, catalogue
internals, registries -- is of no interest to a query, but it still has
to be present, because the projection is also meant to be restorable on
its own: an object missing from it is an object missing from anything
rebuilt out of it, and every reference to it dangles. Those objects get
a row holding their pickle and nothing else.

Every row carries the pickle, including the decomposed ones. Columns
alone cannot always rebuild an object -- a field holding a sub-object or
a list has no column -- so the pickle is what makes the projection
faithful, and the columns are what make it queryable. See
:class:`Projector` for turning that off.

Nothing here touches a database or composes SQL; a row is a description.
"""
from __future__ import absolute_import

from ZODB.relational.derived import Derivations
from ZODB.relational.fields import FieldInspector
from ZODB.relational.naming import Namer
from ZODB.relational.references import ReferenceExpander
from ZODB.relational.rows import Row
from ZODB.relational.valuetypes import UNMAPPED
from ZODB.relational.valuetypes import Converter
from ZODB.relational.valuetypes import Value
from ZODB.relational.workflow import HISTORY_ATTRIBUTE
from ZODB.relational.workflow import WorkflowExpander
from ZODB.utils import u64


#: Table holding objects that are not decomposed into columns.
OPAQUE_TABLE = 'zodb_object'

#: Column holding a pickle, on both kinds of row.
STATE_COLUMN = 'zodb_state'

#: Column naming the class of an object in the opaque table.
CLASS_COLUMN = 'zodb_class'

#: Attributes an object's own identifier is stored under: Archetypes
#: first, then plone.uuid, which is what Dexterity content uses. Both
#: land in the instance dictionary, so both arrive in the state.
#:
#: Whichever is present becomes the ``uid`` column, so that every table
#: offers the same join key and nobody querying has to know which
#: framework a content type happens to be built on.
IDENTITY_ATTRIBUTES = ('_at_uid', '_plone.uuid')


class Classifier(object):
    """Decides which objects are worth spreading across columns.

    A Zope content object announces itself with ``portal_type``, and
    that is the whole test: it is the same set of objects the
    application treats as content, it needs no list to be kept up to
    date as types are added, and it excludes the BTrees and internals
    that have no ``portal_type`` without naming them one by one.
    """

    def portal_type(self, obj):
        """The object's content type name, or None if it is not content."""
        try:
            portal_type = getattr(obj, 'portal_type', None)
        except Exception:
            # A broken or partially loaded object is not worth failing a
            # commit over; it still gets an opaque row.
            return None
        if isinstance(portal_type, bytes):
            try:
                portal_type = portal_type.decode('utf-8')
            except UnicodeDecodeError:
                return None
        if not isinstance(portal_type, type(u'')) or not portal_type.strip():
            return None
        return portal_type


class Projector(object):
    """Builds rows from stored objects.

    :param keep_state: whether rows carry the object's pickle as well as
        its columns. On by default, because it is what lets the
        projection be restored on its own. Turning it off halves what
        the projection costs to store and gives up that property for
        every object with a field no column could hold.
    """

    def __init__(self, namer=None, converter=None, classifier=None,
                 inspector=None, derivations=None, workflow_expander=None,
                 reference_expander=None, keep_state=True):
        self.namer = namer if namer is not None else Namer()
        self.converter = (converter if converter is not None
                          else Converter())
        self.classifier = (classifier if classifier is not None
                           else Classifier())
        self.inspector = (inspector if inspector is not None
                          else FieldInspector())
        self.derivations = (derivations if derivations is not None
                            else Derivations())
        # Unlike the components above, a deployment with no interest in
        # this would pass workflow.NullExpander() explicitly:
        # workflow_history is a stable, framework-level convention (see
        # workflow.py), not a per-deployment judgement call the way
        # `derivations` is.
        self.workflow_expander = (workflow_expander
                                  if workflow_expander is not None
                                  else WorkflowExpander(self.converter))
        # Same reasoning as workflow_expander above: a multi-valued
        # reference field is found from the schema, not decided by the
        # deployment, so a real expander is the default; disinterest is
        # opted into with references.NullReferenceExpander().
        self.reference_expander = (reference_expander
                                   if reference_expander is not None
                                   else ReferenceExpander())
        self.keep_state = keep_state

    def project(self, oid, obj, state, pickle, is_new=False):
        """Return the :class:`Row` describing this object."""
        key = u64(oid)
        portal_type = self.classifier.portal_type(obj)
        if portal_type is None:
            return self._opaque_row(key, obj, pickle, is_new)
        return self._content_row(key, obj, portal_type, state, pickle, is_new)

    def _content_row(self, key, obj, portal_type, state, pickle, is_new):
        fields = state if isinstance(state, dict) else {}
        identity, fields = self._take_identity(fields)
        history = fields.pop(HISTORY_ATTRIBUTE, None)
        reference_fields = self.inspector.references(type(obj))
        multi_reference_fields = self.inspector.multi_references(type(obj))

        children = []
        prune = []
        for field in list(multi_reference_fields):
            if field not in fields:
                continue
            targets = fields.pop(field)
            rows, prune_entry = self.reference_expander.expand(
                key, identity, portal_type, field, targets)
            children.extend(rows)
            if prune_entry is not None:
                prune.append(prune_entry)

        columns = {}
        references = set()
        unmapped = set()
        names = self.namer.columns_for(portal_type, sorted(fields))
        for field, value in fields.items():
            column = names[field]
            converted = self.converter.convert(value)
            if converted is UNMAPPED:
                unmapped.add(field)
            else:
                columns[column] = converted
                if field in reference_fields:
                    references.add(column)
            for suffix, derived in self.derivations.derive(
                    portal_type, field, value).items():
                columns['%s_%s' % (column, suffix)] = derived

        if identity is not None:
            columns[self.namer.uid_column] = identity
        if not isinstance(state, dict):
            # An object whose state is not a mapping at all: it has a
            # content type, but nothing to spread across columns.
            unmapped.add('__getstate__')
        self._add_state(columns, pickle)

        if history is not None:
            children.extend(self.workflow_expander.expand(
                key, identity, portal_type, history))

        return Row(self.namer.table_for(portal_type), key, columns,
                   unmapped, is_new, references, children, prune=prune)

    def _take_identity(self, fields):
        """Split the object's own UID out of its fields.

        Returned separately so it lands in one ``uid`` column whatever
        the framework called the attribute, instead of an ``at_uid``
        here and a ``plone_uuid`` there.
        """
        remaining = dict(fields)
        for attribute in IDENTITY_ATTRIBUTES:
            if attribute not in remaining:
                continue
            converted = self.converter.convert(remaining.pop(attribute))
            if converted is not UNMAPPED and converted.value is not None:
                return converted, remaining
        return None, remaining

    def _opaque_row(self, key, obj, pickle, is_new):
        columns = {CLASS_COLUMN: Value('text', _class_name(obj))}
        # Not optional here: an opaque row is nothing but its pickle.
        columns[STATE_COLUMN] = Value('bytea', pickle)
        return Row(OPAQUE_TABLE, key, columns, (), is_new)

    def _add_state(self, columns, pickle):
        if self.keep_state:
            columns[STATE_COLUMN] = Value('bytea', pickle)


def _class_name(obj):
    klass = type(obj)
    module = getattr(klass, '__module__', None)
    name = getattr(klass, '__name__', None) or repr(klass)
    return u'%s.%s' % (module, name) if module else u'%s' % (name,)
