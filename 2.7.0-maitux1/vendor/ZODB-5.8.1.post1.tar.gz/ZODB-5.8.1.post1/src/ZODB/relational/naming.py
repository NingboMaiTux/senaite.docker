##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Deciding what the tables and columns are called.

The projection exists to be read and queried by people who know the
laboratory but not Zope, so names are chosen for them: a table per
content type under a business name, columns in the lower-case
underscored style SQL is normally written in. Anything else would mean
quoting every identifier in every query.

Names are derived mechanically and can be overridden one by one, which
is also how two content types whose class names collide are told apart.
"""
from __future__ import absolute_import

import re


#: Longest identifier PostgreSQL will keep without silently truncating.
MAX_IDENTIFIER_LENGTH = 63

_CAMEL_BOUNDARY = re.compile(r'(.)([A-Z][a-z]+)')
_LOWER_UPPER_BOUNDARY = re.compile(r'([a-z0-9])([A-Z])')
_ILLEGAL = re.compile(r'[^a-z0-9_]+')


class NameConflict(ValueError):
    """Two different names in the source would become one identifier."""


def snake_case(name):
    """``ClientSampleID`` -> ``client_sample_id``."""
    name = _CAMEL_BOUNDARY.sub(r'\1_\2', name)
    name = _LOWER_UPPER_BOUNDARY.sub(r'\1_\2', name)
    name = _ILLEGAL.sub('_', name.lower()).strip('_')
    if name and name[0].isdigit():
        name = '_' + name
    return name[:MAX_IDENTIFIER_LENGTH]


class Namer(object):
    """Names tables after content types and columns after fields.

    :param tables: overrides keyed by portal type, for giving a type a
        name the laboratory would recognise, or for separating two
        types that would otherwise land on the same table.
    :param columns: overrides keyed by ``(portal type, field name)``.
    """

    #: Column holding the ZODB object id, the primary key of every table.
    oid_column = 'oid'

    #: Column holding the object's own UID, which is what references
    #: from other tables are written against.
    uid_column = 'uid'

    def __init__(self, tables=None, columns=None):
        self.tables = dict(tables or {})
        self.columns = dict(columns or {})

    def table_for(self, portal_type):
        try:
            return self.tables[portal_type]
        except KeyError:
            pass
        name = snake_case(portal_type)
        if not name:
            raise NameConflict(
                'Content type %r does not yield a usable table name'
                % (portal_type,))
        return name

    def column_for(self, portal_type, field):
        try:
            return self.columns[(portal_type, field)]
        except KeyError:
            pass
        name = snake_case(field)
        if not name:
            raise NameConflict(
                'Field %r of %r does not yield a usable column name'
                % (field, portal_type))
        return name

    def columns_for(self, portal_type, fields):
        """Name several fields at once, refusing to lose one to a clash.

        Returns ``{field: column}``. Two fields differing only in case
        or punctuation would otherwise quietly become one column, with
        whichever was written last winning.
        """
        result = {}
        taken = {}
        for field in fields:
            column = self.column_for(portal_type, field)
            if column in taken:
                raise NameConflict(
                    'Fields %r and %r of %r both map to column %r; give one '
                    'of them an explicit name' % (taken[column], field,
                                                  portal_type, column))
            if column in (self.oid_column, self.uid_column):
                raise NameConflict(
                    'Field %r of %r maps to %r, which is reserved'
                    % (field, portal_type, column))
            taken[column] = field
            result[field] = column
        return result
