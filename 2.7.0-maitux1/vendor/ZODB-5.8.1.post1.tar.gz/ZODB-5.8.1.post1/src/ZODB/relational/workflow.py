##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Turning workflow history into rows a turnaround-time query can use.

CMFCore keeps every transition a DCWorkflow-based object has ever gone
through -- who did what, when, and what state it left the object in --
in a ``workflow_history`` attribute: a mapping from workflow id to a
list of plain dicts, one per transition, added to but never edited.
"How long does a sample sit in each state" and "who released this
result" are questions about that list, and today the only way to ask
them is to load every object and walk its history in Python.

``workflow_history`` never has to be reproduced here faithfully: it is
itself a persistent object, and gets its own row -- a whole pickle --
through the ordinary path for objects with no ``portal_type``. What
this module adds is a queryable, best-effort copy of the same
information, one row per transition. Losing a field this cannot make
sense of costs nothing beyond that field not being queryable; the
pickle is still the complete, restorable record.
"""
from __future__ import absolute_import

from ZODB.relational.naming import snake_case
from ZODB.relational.rows import Row
from ZODB.relational.valuetypes import UNMAPPED
from ZODB.relational.valuetypes import Value


#: Attribute CMFCore stores workflow history under, on every object a
#: DCWorkflow has ever acted on. See
#: ``Products.CMFCore.CMFCatalogAware`` and ``WorkflowTool.setStatusOf``;
#: stable across senaite, Plone, and any other CMF-based application.
HISTORY_ATTRIBUTE = 'workflow_history'

#: Table holding one row per transition, across every workflow and
#: every content type: turnaround-time questions ("how long from
#: received to published") are usually asked across a workflow, not
#: within one content type's own table.
TRANSITION_TABLE = 'workflow_transition'

CONTENT_OID_COLUMN = 'content_oid'
CONTENT_UID_COLUMN = 'content_uid'
PORTAL_TYPE_COLUMN = 'portal_type'
WORKFLOW_COLUMN = 'workflow_id'
SEQUENCE_COLUMN = 'sequence'

#: Columns naming the transition itself, reserved the same way the oid
#: and uid columns are: a workflow variable happening to be named
#: ``portal_type`` must not collide with the column that already means
#: something else here.
RESERVED_COLUMNS = frozenset([
    CONTENT_OID_COLUMN, CONTENT_UID_COLUMN, PORTAL_TYPE_COLUMN,
    WORKFLOW_COLUMN, SEQUENCE_COLUMN,
])

#: What makes one transition row unique, for upserting against: an
#: object's whole history is re-derived every time it is stored again,
#: so without this the same transition would accumulate as a new row
#: each time rather than staying one row.
NATURAL_KEY = (CONTENT_OID_COLUMN, WORKFLOW_COLUMN, SEQUENCE_COLUMN)


class WorkflowExpander(object):
    """Turns one object's ``workflow_history`` into transition rows."""

    def __init__(self, converter, table=TRANSITION_TABLE):
        self.converter = converter
        self.table = table

    def expand(self, content_oid, content_uid, portal_type, history):
        """Rows for one object's history.

        ``content_uid`` is the already-converted :class:`Value` from
        :meth:`Projector._take_identity`, or ``None``.

        ``history`` is whatever a live object's ``workflow_history``
        attribute holds, which is application data ZODB has no control
        over, not something whose shape it can guarantee -- so anything
        that does not look like a mapping of workflow id to a sequence
        of event dicts is skipped rather than raising out of a commit.
        Skipped here costs nothing: the object holding this history
        still gets its own faithful, restorable row elsewhere.
        """
        try:
            workflows = history.items()
        except AttributeError:
            return []

        rows = []
        for workflow_id, events in workflows:
            if isinstance(events, (bytes, str)) or not _is_sequence(events):
                continue
            for sequence, event in enumerate(events):
                row = self._event_row(
                    content_oid, content_uid, portal_type, workflow_id,
                    sequence, event)
                if row is not None:
                    rows.append(row)
        return rows

    def _event_row(self, content_oid, content_uid, portal_type, workflow_id,
                   sequence, event):
        try:
            items = event.items()
        except AttributeError:
            return None

        columns = {
            CONTENT_OID_COLUMN: Value('bigint', content_oid),
            PORTAL_TYPE_COLUMN: Value('text', _text(portal_type)),
            WORKFLOW_COLUMN: Value('text', _text(workflow_id)),
            SEQUENCE_COLUMN: Value('bigint', sequence),
        }
        if content_uid is not None:
            columns[CONTENT_UID_COLUMN] = content_uid

        for key, value in items:
            column = snake_case(_text(key))
            if not column or column in RESERVED_COLUMNS:
                # A custom workflow variable that collides with one of
                # the columns above. Rare, and not worth losing the
                # whole row over: this one field just does not get a
                # column, same as any value the converter cannot type.
                continue
            converted = self.converter.convert(value)
            if converted is not UNMAPPED:
                columns[column] = converted

        return _Row(self.table, columns)


class NullExpander(object):
    """A :class:`WorkflowExpander` that finds nothing.

    For a :class:`~ZODB.relational.projection.Projector` built for an
    application with no CMFCore-style workflow history to expand.
    """

    def expand(self, content_oid, content_uid, portal_type, history):
        return []


def _is_sequence(value):
    return isinstance(value, (list, tuple)) or hasattr(value, '__getitem__')


def _text(value):
    if isinstance(value, bytes):
        try:
            return value.decode('utf-8')
        except UnicodeDecodeError:
            return repr(value)
    return value if isinstance(value, type(u'')) else u'%s' % (value,)


def _Row(table, columns):
    return Row(table, None, columns, natural_key=NATURAL_KEY)
