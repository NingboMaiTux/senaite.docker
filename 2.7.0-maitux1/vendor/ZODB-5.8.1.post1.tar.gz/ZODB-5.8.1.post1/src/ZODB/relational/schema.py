##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Writing rows to PostgreSQL: creating what is missing, then upserting.

Two things this module exists to get right, both because getting them
wrong is expensive to notice:

Schema changes are rare in the life of a process, but every commit
would otherwise pay for that: without a cache, "does this table exist,
does this column exist" would mean an ``ALTER TABLE`` -- an ACCESS
EXCLUSIVE lock, however briefly -- on every single commit, forever, not
just the first time a table or column is seen. :class:`SchemaCache`
remembers what this process has already confirmed, so that DDL for a
given table or column is only ever issued once per process. Several
worker processes racing to create the same thing for the first time,
right after a deploy, is expected and left to PostgreSQL's own
``IF NOT EXISTS`` (or, for a constraint, a caught duplicate-object
error) rather than coordinated between them.

A failure here must never fail the commit it rode in on: this
projection exists to be queried, not to be the reason a lab result
failed to save. Every row is written under its own savepoint, so a
problem with one row -- or with the projection generally -- is logged
and left behind without disturbing the rows around it or the storage's
own writes in the same transaction.
"""
from __future__ import absolute_import

import logging

from ZODB.relational import relstorage_support

logger = logging.getLogger('ZODB.relational')

#: Global, shared by every table, so that write order is comparable
#: across tables too, not just within one. See CHANGES.rst for why this
#: -- not the ZODB transaction id -- is the watermark: by the time a
#: commit's tid is known, this connection's transaction has already
#: closed.
WRITE_SEQUENCE = 'zodb_write_seq'

#: Column every table gets, whether or not the mapper asked for it.
WRITE_SEQ_COLUMN = 'write_seq'


def quote_ident(name):
    """A PostgreSQL identifier, quoted and escaped.

    Column and table names normally come from :mod:`naming`, which
    already produces safe lowercase identifiers -- but an explicit
    override (a business name someone chose by hand) is not guaranteed
    to, and generated SQL should not depend on that guarantee holding.
    """
    return '"' + name.replace('"', '""') + '"'


def _matches_scope(row, scope):
    return all(col in row.columns and row.columns[col].value == value
               for col, value in scope.items())


class SchemaCache(object):
    """What this process has already confirmed exists in the database.

    Not a cache of *all* schema, only of what this process has itself
    touched -- built up lazily, one table or column at a time, as rows
    for it are actually written.
    """

    def __init__(self):
        self.tables = set()
        self.columns = set()       # (table, column)
        self.constrained = set()   # tables whose natural-key constraint exists
        self.sequence_created = False

    def has_table(self, table):
        return table in self.tables

    def learned_table(self, table):
        self.tables.add(table)

    def has_column(self, table, column):
        return (table, column) in self.columns

    def learned_column(self, table, column):
        self.columns.add((table, column))

    def has_constraint(self, table):
        return table in self.constrained

    def learned_constraint(self, table):
        self.constrained.add(table)


class PostgreSQLWriter(object):
    """Writes :class:`~ZODB.relational.rows.Row` objects to PostgreSQL.

    One instance -- and so one :class:`SchemaCache` -- should be shared
    by every connection a process opens: the cache is only worth having
    if it outlives a single commit. A :class:`~ZODB.DB.DB` configured
    with a ``relational_mapper`` factory typically closes over one
    writer instance created outside that factory, so every connection's
    mapper is handed the same one.

    :param binary: wraps a ``bytea`` value for the DBAPI driver, or
        ``None`` (the default) to import ``psycopg2.Binary`` the first
        time one is needed. Overridable so this module stays importable
        -- for the parts of it that do not touch a real value -- where
        psycopg2 is not installed at all.
    :param already_exists_code: the SQLSTATE for "an object of this
        name already exists", used to recognise (and ignore) two
        processes racing to create the same constraint. ``42P07`` --
        ``duplicate_table``, not the more general-sounding
        ``duplicate_object`` (``42710``) -- is what PostgreSQL actually
        raises here, confirmed against a real server rather than
        assumed: ``ADD CONSTRAINT ... UNIQUE`` backs the constraint
        with an index of the same name, and it is *that* name
        collision speaking. Needs no driver-specific import to check
        for; it is PostgreSQL's own code, the same for any driver.
    """

    def __init__(self, cache=None, binary=None,
                 already_exists_code='42P07'):
        self.cache = cache if cache is not None else SchemaCache()
        self._binary = binary
        self.already_exists_code = already_exists_code

    def write(self, rows, storage):
        cursor = relstorage_support.store_cursor(storage)
        if cursor is None:
            logger.warning(
                "Relational projection has rows to write but no live "
                "RelStorage connection was found; skipping this "
                "transaction's projection entirely.")
            return
        cursor.execute('SAVEPOINT maizodb_sequence')
        try:
            self._ensure_sequence(cursor)
        except Exception:
            cursor.execute('ROLLBACK TO SAVEPOINT maizodb_sequence')
            logger.exception(
                "Relational projection could not ensure its write-order "
                "sequence exists; skipping this transaction's projection "
                "entirely (the storage's own writes are unaffected).")
            return
        else:
            cursor.execute('RELEASE SAVEPOINT maizodb_sequence')

        for row in rows:
            cursor.execute('SAVEPOINT maizodb_row')
            # What this row's DDL confirmed, held back from self.cache
            # until we know the whole row survives: a ROLLBACK TO
            # SAVEPOINT below undoes every statement since the savepoint
            # -- including a column added earlier in this very row's
            # processing, if something later in the same row then
            # failed -- and the cache must not go on believing in
            # something that Postgres just took back.
            pending = []
            try:
                self._ensure_table(cursor, row, pending)
                self._upsert(cursor, row, pending)
            except Exception:
                cursor.execute('ROLLBACK TO SAVEPOINT maizodb_row')
                logger.exception(
                    "Relational projection failed for table %r oid=%r; "
                    "that object's own record is unaffected, only this "
                    "update to its SQL projection is missing.",
                    row.table, row.oid)
            else:
                cursor.execute('RELEASE SAVEPOINT maizodb_row')
                for kind, args in pending:
                    getattr(self.cache, 'learned_%s' % kind)(*args)

        self._run_prunes(cursor, rows)

    def _run_prunes(self, cursor, rows):
        # A row's own children are only ever additive -- what is
        # missing from them, because a list shrank or emptied out, has
        # to be found and removed separately, after they have all been
        # written, by comparing what a prune's scope says should be
        # the group's complete membership now against the group's
        # membership before this commit.
        for row in rows:
            for prune in row.prune:
                cursor.execute('SAVEPOINT maizodb_prune')
                try:
                    self._prune(cursor, rows, prune)
                except Exception:
                    cursor.execute('ROLLBACK TO SAVEPOINT maizodb_prune')
                    logger.exception(
                        "Relational projection could not prune stale "
                        "rows from %r for %r; those rows may now be "
                        "stale until the next successful write for the "
                        "same group.", prune[0], prune[1])
                else:
                    cursor.execute('RELEASE SAVEPOINT maizodb_prune')

    def _prune(self, cursor, rows, prune):
        table, scope, item_columns = prune
        if not self.cache.has_table(table):
            # Nothing has ever been written to this table, so this
            # group has no stale rows to remove -- and, since the very
            # first object ever written for it can easily have an empty
            # list for this field (nothing to insert, only a prune to
            # run), this is not a corner case to special-case away, it
            # is the ordinary first-write case.
            return
        kept = [
            tuple(self._param(sibling.columns[c]) for c in item_columns)
            for sibling in rows
            if sibling.table == table and _matches_scope(sibling, scope)
        ]
        conditions = ['%s = %%s' % quote_ident(c) for c in scope]
        params = list(scope.values())
        if kept:
            item_list = ', '.join(quote_ident(c) for c in item_columns)
            placeholders = ', '.join(
                '(%s)' % ', '.join(['%s'] * len(item_columns))
                for _ in kept)
            conditions.append(
                '(%s) NOT IN (%s)' % (item_list, placeholders))
            for row_values in kept:
                params.extend(row_values)
        cursor.execute(
            'DELETE FROM %s WHERE %s'
            % (quote_ident(table), ' AND '.join(conditions)),
            params)

    def _ensure_sequence(self, cursor):
        if self.cache.sequence_created:
            return
        cursor.execute(
            'CREATE SEQUENCE IF NOT EXISTS %s' % quote_ident(WRITE_SEQUENCE))
        self.cache.sequence_created = True

    def _ensure_table(self, cursor, row, pending):
        if not self.cache.has_table(row.table):
            self._create_table(cursor, row)
            pending.append(('table', (row.table,)))
        for name, value in row.columns.items():
            if value.sql_type is None:
                # Cannot bring a column into existence; see
                # valuetypes.NULL. If the column already exists from an
                # earlier row, the INSERT below still writes NULL into
                # it -- just not on the strength of this row alone.
                continue
            if self.cache.has_column(row.table, name):
                continue
            cursor.execute(
                'ALTER TABLE %s ADD COLUMN IF NOT EXISTS %s %s'
                % (quote_ident(row.table), quote_ident(name), value.sql_type))
            pending.append(('column', (row.table, name)))
        # After the loop above, not before: a natural key's own columns
        # are ordinary entries in row.columns, created by that loop like
        # any other, and the constraint cannot be added before they
        # exist to be constrained.
        if row.natural_key and not self.cache.has_constraint(row.table):
            self._ensure_natural_key_constraint(cursor, row, pending)

    def _create_table(self, cursor, row):
        table = quote_ident(row.table)
        if row.oid is not None:
            pk = '%s bigint PRIMARY KEY' % quote_ident('oid')
        else:
            pk = '%s bigserial PRIMARY KEY' % quote_ident('id')
        write_seq = '%s bigint NOT NULL DEFAULT nextval(%r)' % (
            quote_ident(WRITE_SEQ_COLUMN), WRITE_SEQUENCE)
        cursor.execute(
            'CREATE TABLE IF NOT EXISTS %s (%s, %s)' % (table, pk, write_seq))

    def _ensure_natural_key_constraint(self, cursor, row, pending):
        table = quote_ident(row.table)
        constraint = quote_ident('uq_%s' % row.table)
        columns = ', '.join(quote_ident(c) for c in row.natural_key)
        # PostgreSQL has no ADD CONSTRAINT IF NOT EXISTS: two processes
        # can both decide it is missing and both try to add it. That is
        # fine -- one succeeds, the other's attempt is a duplicate
        # object error -- as long as it does not poison the surrounding
        # transaction, hence the nested savepoint. An unrecognised
        # error is left to propagate to write()'s own savepoint, so it
        # is not this method's place to record anything as pending.
        cursor.execute('SAVEPOINT maizodb_constraint')
        try:
            cursor.execute(
                'ALTER TABLE %s ADD CONSTRAINT %s UNIQUE (%s)'
                % (table, constraint, columns))
        except Exception as e:
            if getattr(e, 'pgcode', None) != self.already_exists_code:
                raise
            cursor.execute('ROLLBACK TO SAVEPOINT maizodb_constraint')
        else:
            cursor.execute('RELEASE SAVEPOINT maizodb_constraint')
        pending.append(('constraint', (row.table,)))

    def _upsert(self, cursor, row, pending):
        # Key columns are identified and valued differently depending
        # on what kind of row this is, but in every case they must not
        # ALSO appear among the "other" columns below: a natural key's
        # columns are ordinary entries in row.columns too, and listing
        # a column twice in one INSERT is something PostgreSQL flatly
        # refuses, not something that quietly does the wrong thing.
        if row.oid is not None:
            key_columns = ('oid',)
            key_values = (row.oid,)
        elif row.natural_key:
            key_columns = row.natural_key
            key_values = tuple(self._param(row.columns[c])
                               for c in key_columns)
        else:
            key_columns = ()
            key_values = ()

        # A column this same row just added by ALTER TABLE is real in
        # the database already, even though self.cache will not learn
        # about it unless and until this whole row succeeds -- so a
        # column counts as available here if either says so.
        added_this_row = set(
            args for (kind, args) in pending if kind == 'column')
        other_columns = [n for n in row.columns
                         if n not in key_columns
                         and (self.cache.has_column(row.table, n)
                              or (row.table, n) in added_this_row)]
        other_values = [self._param(row.columns[n]) for n in other_columns]

        all_names = list(key_columns) + other_columns
        all_values = list(key_values) + other_values
        table = quote_ident(row.table)
        collist = ', '.join(quote_ident(n) for n in all_names)
        placeholders = ', '.join(['%s'] * len(all_values))

        if not key_columns:
            cursor.execute(
                'INSERT INTO %s (%s) VALUES (%s)'
                % (table, collist, placeholders), all_values)
            return

        conflict_target = ', '.join(quote_ident(c) for c in key_columns)
        if other_columns:
            quoted = [quote_ident(n) for n in other_columns]
            assignments = ', '.join(
                '%s = EXCLUDED.%s' % (n, n) for n in quoted)
            assignments += (', %s = nextval(%r)'
                            % (quote_ident(WRITE_SEQ_COLUMN), WRITE_SEQUENCE))
            # Without this, re-deriving an object's full current state
            # every time it is stored -- which is what this whole
            # projection does -- would bump write_seq on every column
            # of every row derived from it on every commit, whether or
            # not that value actually changed: a workflow transition
            # from years ago would look "just modified" to a consumer
            # polling write_seq every time its object is merely
            # touched again for an unrelated reason. Comparing full
            # row tuples, not column by column, also means a value
            # that flips from real to NULL (or back) counts as a
            # change: IS DISTINCT FROM treats NULL as a value here,
            # unlike a plain <>. The "old value" side must be qualified
            # with the table name: both the table and EXCLUDED are in
            # scope here, so a bare column name that exists in both --
            # which is every one of these, by construction -- is
            # rejected as ambiguous, not resolved to the table.
            where = (' WHERE (%s) IS DISTINCT FROM (%s)'
                     % (', '.join('%s.%s' % (table, n) for n in quoted),
                        ', '.join('EXCLUDED.%s' % n for n in quoted)))
            action = 'DO UPDATE SET %s%s' % (assignments, where)
        else:
            # Nothing but the key itself: a transition row's own
            # columns never change once written, so a repeat is a
            # no-op rather than an update with nothing new to say.
            action = 'DO NOTHING'
        cursor.execute(
            'INSERT INTO %s (%s) VALUES (%s) ON CONFLICT (%s) %s'
            % (table, collist, placeholders, conflict_target, action),
            all_values)

    def _param(self, value):
        if value.sql_type == 'bytea':
            binary = self._binary
            if binary is None:
                from psycopg2 import Binary as binary
            return binary(value.value)
        return value.value
