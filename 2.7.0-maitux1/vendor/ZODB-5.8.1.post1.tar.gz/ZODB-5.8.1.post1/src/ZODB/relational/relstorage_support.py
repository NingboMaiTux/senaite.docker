##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Borrowing RelStorage's own database connection.

A mapper that writes its rows on a *separate* connection buys only weak
consistency: the projection can survive a transaction that was rolled
back, or be lost for one that committed. Writing them on the connection
the storage is already using makes both halves one database transaction,
so they commit or roll back together and there is nothing to reconcile.

RelStorage exposes no public API for this, so the chain below reaches
through one private attribute. Everything version-specific about that is
confined to this module.

Verified against RelStorage 3.5.0, where:

- ``ZODB.DB`` does not wrap RelStorage in an ``MVCCAdapter``, because
  RelStorage provides ``IMVCCStorage`` itself, so a Connection's
  ``_storage`` is a RelStorage instance already.
- ``RelStorage._tpc_phase`` holds the current two-phase-commit state,
  and RelStorage reaches the connection by the same
  ``_tpc_phase.shared_state.store_connection`` chain used here
  (``relstorage/storage/__init__.py``, in ``pack``).
- Outside a transaction ``_tpc_phase`` is a ``NotInTransaction``, which
  has no ``shared_state`` at all; hence the guards.
- PostgreSQL commits are ordinary single-transaction commits.
  ``commit_phase1`` is a no-op returning ``'-'`` and ``commit_phase2``
  is a plain ``store_connection.commit()``
  (``relstorage/adapters/txncontrol.py``); no ``PREPARE TRANSACTION`` is
  used anywhere. So statements issued on this connection up until
  ``tpc_finish`` join the storage's own transaction.

If a future RelStorage moves these attributes, :func:`store_cursor`
starts returning ``None`` rather than raising, and the caller decides
whether to degrade or fail.
"""
from __future__ import absolute_import


def store_cursor(storage):
    """Return the open DBAPI cursor the storage is committing on.

    Returns ``None`` when the storage is not a RelStorage, is not
    currently in a transaction, or has not yet borrowed its store
    connection -- all of which are ordinary situations, not errors.
    """
    connection = store_connection(storage)
    if connection is None:
        return None
    return getattr(connection, 'cursor', None)


def store_connection(storage):
    """Return the storage's managed store connection, or ``None``.

    The returned object is RelStorage's wrapper, whose ``cursor`` and
    ``connection`` attributes are the DBAPI objects.
    """
    shared_state = _shared_state(storage)
    if shared_state is None:
        return None
    # Ask only for a connection that has already been borrowed for this
    # transaction. Touching the descriptor otherwise would borrow one
    # from the pool as a side effect, and a mapper with nothing to say
    # should not cause a connection to be opened.
    if 'store_connection' not in shared_state.__dict__:
        return None
    connection = shared_state.store_connection
    if getattr(connection, 'connection', None) is None:
        # A closed or dropped connection. RelStorage substitutes a
        # sentinel object here after an abort.
        return None
    return connection


def _shared_state(storage):
    phase = getattr(storage, '_tpc_phase', None)
    if phase is None:
        return None
    # NotInTransaction has no shared_state, which is how "no transaction
    # is in progress" presents itself.
    return getattr(phase, 'shared_state', None)
