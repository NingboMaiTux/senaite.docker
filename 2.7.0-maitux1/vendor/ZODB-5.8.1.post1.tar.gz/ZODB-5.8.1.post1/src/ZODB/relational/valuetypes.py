##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Turning stored Python values into typed column values.

The point of the projection is arithmetic: averages, trends, counts per
month. So a value keeps the narrowest honest SQL type it can, and a
value that cannot be typed is left out of the schema rather than being
flattened into text. A text column that used to be numeric cannot be
averaged, cannot use its index, and hides the fact that something
unexpected arrived.

Conversion is a list of rules tried in order, so a deployment can teach
it about its own value types by inserting rules at the front.
"""
from __future__ import absolute_import

import datetime


class Unmapped(object):
    """A value that does not become a column of its own."""

    __slots__ = ()

    def __repr__(self):
        return 'UNMAPPED'


#: Returned for values the rules do not claim: sub-objects, sequences,
#: and anything a deployment has not taught the mapper about. The value
#: still reaches the database inside the object's pickle; it simply has
#: no column.
UNMAPPED = Unmapped()


class Value(object):
    """A converted value and the column type that holds it.

    ``sql_type`` is ``None`` when the value is ``None`` and nothing can
    be inferred from it: such a value cannot bring a column into
    existence, but it can be written as NULL into a column that other
    objects have already established.
    """

    __slots__ = ('sql_type', 'value')

    def __init__(self, sql_type, value):
        self.sql_type = sql_type
        self.value = value

    def __eq__(self, other):
        return (isinstance(other, Value)
                and other.sql_type == self.sql_type
                and other.value == self.value
                and type(other.value) is type(self.value))

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash((self.sql_type, self.value))

    def __repr__(self):
        return 'Value(%r, %r)' % (self.sql_type, self.value)


#: A NULL of unknown type.
NULL = Value(None, None)

try:
    _TEXT_TYPES = (str, unicode)  # noqa: F821 (Python 2)
    _INTEGER_TYPES = (int, long)  # noqa: F821 (Python 2)
except NameError:
    _TEXT_TYPES = (str,)
    _INTEGER_TYPES = (int,)


def convert_none(value):
    if value is None:
        return NULL
    return UNMAPPED


def convert_bool(value):
    # Before the integer rule: bool is a subclass of int, and a column
    # that says true/false is worth more to someone reading the data
    # than one that says 1/0.
    if isinstance(value, bool):
        return Value('boolean', value)
    return UNMAPPED


def convert_integer(value):
    if isinstance(value, _INTEGER_TYPES):
        return Value('bigint', value)
    return UNMAPPED


def convert_float(value):
    if isinstance(value, float):
        return Value('double precision', value)
    return UNMAPPED


def convert_text(value):
    if isinstance(value, bytes):
        try:
            value = value.decode('utf-8')
        except UnicodeDecodeError:
            # Bytes that are not text at all. Keeping them out of a text
            # column is better than writing mojibake nobody can query.
            return UNMAPPED
        return Value('text', value)
    if isinstance(value, _TEXT_TYPES):
        return Value('text', value)
    return UNMAPPED


#: Column type every moment in time lands in.
#:
#: One type for all of them, whether or not the value carried a zone.
#: A column whose type depended on that would change under us the first
#: time a naive value turned up, and anything reading the projection
#: downstream would break. PostgreSQL reads a naive value as being in
#: the session's time zone.
TIMESTAMP = 'timestamp with time zone'

_zope_datetime = []


def _zope_datetime_class():
    """Zope's ``DateTime`` class, or None where Zope is not installed.

    ZODB does not depend on Zope, so the rule below simply never fires
    outside a Zope application.
    """
    if not _zope_datetime:
        try:
            from DateTime.DateTime import DateTime
        except ImportError:
            _zope_datetime.append(None)
        else:
            _zope_datetime.append(DateTime)
    return _zope_datetime[0]


def convert_zope_datetime(value):
    """Zope ``DateTime``, which is what Archetypes date fields hold.

    Left as an opaque object it would be unqueryable, and the whole
    point of the projection is asking for this month against last.
    """
    DateTime = _zope_datetime_class()
    if DateTime is None or not isinstance(value, DateTime):
        return UNMAPPED
    try:
        moment = value.asdatetime()
    except Exception:
        # A DateTime that cannot say when it is. Better no column than
        # a wrong one.
        return UNMAPPED
    return Value(TIMESTAMP, moment)


def convert_datetime(value):
    # Before the date rule: datetime is a subclass of date.
    if isinstance(value, datetime.datetime):
        return Value(TIMESTAMP, value)
    return UNMAPPED


def convert_date(value):
    if isinstance(value, datetime.date):
        return Value('date', value)
    return UNMAPPED


#: Rules in the order they are tried. A deployment adds its own by
#: inserting at the front of a copy.
DEFAULT_RULES = (
    convert_none,
    convert_bool,
    convert_zope_datetime,
    convert_datetime,
    convert_date,
    convert_integer,
    convert_float,
    convert_text,
)


class Converter(object):
    """Applies conversion rules in order."""

    def __init__(self, rules=None):
        self.rules = list(DEFAULT_RULES if rules is None else rules)

    def convert(self, value):
        """Return a :class:`Value`, or :data:`UNMAPPED`."""
        for rule in self.rules:
            converted = rule(value)
            if converted is not UNMAPPED:
                return converted
        return UNMAPPED
