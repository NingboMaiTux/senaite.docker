##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""The one place senaite-specific knowledge is allowed to live.

Every other module under :mod:`ZODB.relational` knows nothing about
senaite -- ``projection`` decomposes any object with a ``portal_type``,
``fields`` reads any Archetypes-shaped schema, ``workflow`` understands
any CMFCore ``workflow_history``. What's senaite-specific is not the
mechanism, only two small policy choices: which fields are measured
values worth deriving a number from (currently just ``Analysis.Result``
-- see ``ZODB.relational.derived``), and that one shared
:class:`~ZODB.relational.schema.PostgreSQLWriter` should back every
connection in the process rather than a fresh one each time.

Wire this in without editing senaite at all: point Zope's ``zope.conf``
at :data:`mapper_factory` (see ``ZODB/component.xml``'s
``relational-mapper`` key, added alongside this package)::

    <zodb_db main>
      <zeo>
        ...
      </zeo>
      cache-size 30000
      relational-mapper ZODB.relational.senaite.mapper_factory
    </zodb_db>

or, constructing ``ZODB.DB`` directly::

    from ZODB.relational.senaite import mapper_factory
    db = ZODB.DB(storage, relational_mapper=mapper_factory)

No PostgreSQL connection details belong here, and none are configured:
:class:`~ZODB.relational.schema.PostgreSQLWriter` never opens a
connection of its own, only ever borrows the one RelStorage is already
using for the current transaction. Whatever ``rel-storage`` in
buildout.cfg already points RelStorage at is where this writes too, by
construction, not by being told to separately.
"""
from __future__ import absolute_import

from ZODB.relational.derived import NUMERIC
from ZODB.relational.derived import Derivations
from ZODB.relational.mapper import BufferingMapper
from ZODB.relational.projection import Projector
from ZODB.relational.schema import PostgreSQLWriter

#: Which stored fields are measured values a number should be derived
#: from, alongside the text they are stored as. Add to this as more
#: such fields are identified and confirmed against senaite's own
#: schema -- see ZODB.relational.derived for what "confirmed" means
#: here and why guessing at the shape is specifically what this
#: project has tried not to do.
DERIVATIONS = Derivations({
    ('Analysis', 'Result'): NUMERIC,
})

#: One writer for the whole process: its SchemaCache is only useful if
#: it outlives a single connection. See PostgreSQLWriter and
#: SchemaCache in ZODB.relational.schema for why a fresh one per
#: commit would mean paying for DDL that a shared one only ever pays
#: for once.
writer = PostgreSQLWriter()


def mapper_factory(connection):
    """The callable a ``relational-mapper`` config setting names.

    A fresh :class:`~ZODB.relational.mapper.BufferingMapper` per
    connection (it holds per-transaction state, so it cannot be
    shared), a fresh :class:`~ZODB.relational.projection.Projector`
    per connection (cheap; it holds no state worth sharing beyond
    :data:`DERIVATIONS`, which is itself shared), but the one
    process-wide :data:`writer`.
    """
    return BufferingMapper(
        connection,
        projector=Projector(derivations=DERIVATIONS),
        writer=writer)
