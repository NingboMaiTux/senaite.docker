##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""The one shared description of "a row to write"."""
from __future__ import absolute_import


class Row(object):
    """One row: a table, typed column values, and how it relates to ZODB.

    ``oid`` is the primary key for a row that corresponds 1:1 with a
    stored object -- the usual case. It is ``None`` for a row derived
    from *part* of an object rather than the whole of it (a single
    workflow transition out of an object's history, say): such a row
    has no ZODB identity of its own; whatever uniquely identifies it is
    just among its ``columns``, same as any other business fact.

    ``unmapped`` names the fields that got no column, which is the
    answer to "why can I not see that field in SQL".

    ``references`` names the columns holding another object's UID.
    PostgreSQL indexes the side a foreign key points at, never the side
    pointing, so without this every join from here would be a
    sequential scan.

    ``children`` are further rows derived from this object that do not
    themselves correspond to a stored object -- see ``oid`` above. They
    travel with the row that produced them so that a mapper which
    decides to drop a stale copy of an object (a savepoint rollback, an
    object stored twice in one transaction) drops what was derived from
    it too, without having to know how it was derived.

    ``natural_key`` names the columns that make a row like this one
    unique, for a row with no ``oid`` of its own to upsert against
    instead: the same transition can genuinely be written more than
    once (an object's whole history is re-derived every time it is
    stored again), and without something to conflict on, that would
    mean a growing pile of duplicate rows rather than one row per
    transition.

    ``prune`` declares that some of this row's ``children`` are the
    *complete* current membership of a group, so that whatever used to
    be in that group and is not among them anymore should be deleted --
    a list a field once referenced five objects through and now only
    references three needs the other two rows gone, not left behind as
    stale, and this is the only place that can be known: unlike an
    object's own state, which only says what it *is* now, this is
    ZODB's one authoritative answer to what a field's list-of-references
    no longer includes. Each entry is
    ``(table, scope, item_columns)``: ``scope`` (a ``{column: value}``
    mapping) identifies the group -- typically this row's own oid or
    uid plus the field's name -- and ``item_columns`` names the
    remaining ``natural_key`` columns of the children that belong to
    it, the ones that vary per member of the group. Declared here,
    on the row whose field this is, rather than inferred from which
    children happen to be present, so that a field emptied out
    entirely -- no children left to infer a group from -- still gets
    pruned down to nothing rather than silently left alone.
    """

    __slots__ = ('table', 'oid', 'columns', 'unmapped', 'is_new',
                 'references', 'children', 'natural_key', 'prune')

    def __init__(self, table, oid, columns, unmapped=(), is_new=False,
                 references=(), children=(), natural_key=(), prune=()):
        self.table = table
        self.oid = oid
        self.columns = columns
        self.unmapped = frozenset(unmapped)
        self.is_new = is_new
        self.references = frozenset(references)
        self.children = tuple(children)
        self.natural_key = tuple(natural_key)
        self.prune = tuple(prune)

    def __repr__(self):
        return '<Row %s oid=%s %d columns>' % (
            self.table, self.oid, len(self.columns))
