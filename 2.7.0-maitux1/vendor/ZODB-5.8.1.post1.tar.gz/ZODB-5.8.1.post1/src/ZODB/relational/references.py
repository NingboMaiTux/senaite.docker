##############################################################################
#
# Copyright (c) 2026 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################
"""Turning a list-of-references field into rows a JOIN can use.

``fields.FieldInspector.multi_references`` finds fields whose schema
says they hold a list of references rather than one -- an
``AnalysisRequest``'s ``Analyses``, say. The value stored for one of
these is a plain list of UID strings (see the confirmation in
CHANGES.rst: senaite references are UID strings, not persistent object
references, for single- and multi-valued fields alike), which is
exactly the shape a single-valued reference field has too, except
there can be more than one -- so unlike a single reference, which
becomes an ordinary column, a list needs a row per member to be
joinable at all.

Every row here is one (object, field, referenced UID) fact, in one
table shared across every content type and field, the same way
workflow transitions share one table: the row shape never depends on
which field or type it came from, so there is nothing to gain from
separate tables and a real cost (an extra table per field) to doing
it anyway.
"""
from __future__ import absolute_import

from ZODB.relational.rows import Row
from ZODB.relational.valuetypes import Value

#: Table holding one row per (object, field, referenced UID).
REFERENCE_TABLE = 'object_reference'

CONTENT_OID_COLUMN = 'content_oid'
CONTENT_UID_COLUMN = 'content_uid'
PORTAL_TYPE_COLUMN = 'portal_type'
FIELD_COLUMN = 'field'
TARGET_UID_COLUMN = 'target_uid'
POSITION_COLUMN = 'position'

#: What makes one reference row unique: this is what an upsert targets,
#: so that adding to or reordering a list updates in place rather than
#: piling up duplicates each time the object holding it is stored
#: again. Position is deliberately not part of it -- an item that
#: moves within the list should update its existing row, not be
#: dropped and recreated as a new one -- so it is an ordinary
#: (updatable) column instead.
NATURAL_KEY = (CONTENT_OID_COLUMN, FIELD_COLUMN, TARGET_UID_COLUMN)

#: The part of NATURAL_KEY that identifies the group a row's prune
#: entry (see Row.prune) is about, rather than one member within it.
PRUNE_SCOPE = (CONTENT_OID_COLUMN, FIELD_COLUMN)

#: The rest of NATURAL_KEY: what actually varies from one member of
#: the group to the next.
PRUNE_ITEM_COLUMNS = (TARGET_UID_COLUMN,)


class ReferenceExpander(object):
    """Turns one field's list of references into rows, plus a prune."""

    def __init__(self, table=REFERENCE_TABLE):
        self.table = table

    def expand(self, content_oid, content_uid, portal_type, field, targets):
        """``(rows, prune_entry)`` for one multi-valued reference field.

        ``targets`` is whatever a live object's field holds -- schema
        metadata said it should be a list of UIDs, but that is a
        promise about the field, not something ZODB can verify about
        the value, so anything that is not actually a sequence of
        strings is treated as an empty list (pruned down to nothing)
        rather than raising out of a commit.
        """
        rows = []
        for position, target in enumerate(_as_sequence(targets)):
            uid = _text(target)
            if not uid:
                continue
            columns = {
                CONTENT_OID_COLUMN: Value('bigint', content_oid),
                PORTAL_TYPE_COLUMN: Value('text', _text(portal_type)),
                FIELD_COLUMN: Value('text', _text(field)),
                TARGET_UID_COLUMN: Value('text', uid),
                POSITION_COLUMN: Value('bigint', position),
            }
            if content_uid is not None:
                columns[CONTENT_UID_COLUMN] = content_uid
            rows.append(
                Row(self.table, None, columns, natural_key=NATURAL_KEY))

        scope = {CONTENT_OID_COLUMN: content_oid, FIELD_COLUMN: _text(field)}
        prune_entry = (self.table, scope, PRUNE_ITEM_COLUMNS)
        return rows, prune_entry


class NullReferenceExpander(object):
    """A :class:`ReferenceExpander` that finds nothing and prunes nothing.

    For a :class:`~ZODB.relational.projection.Projector` built for an
    application with no multi-valued reference fields to expand.
    """

    def expand(self, content_oid, content_uid, portal_type, field, targets):
        return [], None


def _as_sequence(value):
    # bytes/str and unicode (type(u'')) are both excluded explicitly: a
    # plain isinstance(value, (bytes, str)) check misses unicode
    # strings entirely under Python 2, where str means bytes, and a
    # unicode string has both __getitem__ and __len__, so it would
    # otherwise pass the duck-typed check below and be iterated one
    # character at a time.
    if isinstance(value, (bytes, str, type(u''))):
        return ()
    if isinstance(value, (list, tuple)):
        return value
    if hasattr(value, '__getitem__') and hasattr(value, '__len__'):
        return value
    return ()


def _text(value):
    if isinstance(value, bytes):
        try:
            return value.decode('utf-8')
        except UnicodeDecodeError:
            return None
    if isinstance(value, type(u'')):
        return value
    if value is None:
        return None
    return u'%s' % (value,)
