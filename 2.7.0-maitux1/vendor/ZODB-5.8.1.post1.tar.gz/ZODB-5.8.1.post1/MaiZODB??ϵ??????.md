# MaiZODB 关系化方案（方案 A）

| 项 | 值 |
|---|---|
| 日期 | 2026-09-23 |
| 状态 | 方案 A 已确定；ZODB 包的打包与接入 senaite.docker 构建已完成；`ObjectWriter`/`ObjectReader` 的实际改造代码**尚未开始** |
| 范围 | senaite.docker 的 `2.7.0-maitux1`（`latest/` 未逐项核实，buildout.cfg 结构相同但版本未单独确认） |
| 来源 | 本文档所有内容均来自同一次对话里逐项问答确认的结论，不含独立推测的业务表结构/组件/时间表 |

---

## 1. 目标与优先级

- **主目标**：业务对象的存储字段能以真实关系列的形式被 SQL 直接查询（`WHERE`/`JOIN`），不再只有 ZCatalog 那种倒排索引。
- **次目标**（明确排在主目标之后）：只备份关系表也能用自定义工具还原出完整的 ZODB/RelStorage 数据库，作为常规整库备份之外的一种轻量手段——**不替代**现有的 `lims_db` 整库备份。

---

## 2. 版本基线

基线版本：**ZODB 5.8.0**——从 `maitux-lims` 容器实际运行环境里直接读出的版本（`/home/senaite/senaitelims/eggs/cp27mu/`），不是查文档猜的。这也是本方案唯一要改造的包：实测的 pip 依赖关系是 `ZODB` 依赖 `persistent`/`BTrees`/`transaction`，没有包反过来依赖 `ZODB`；本方案要改的钩子（见第 4 节）只存在于 `ZODB` 自己的源码里，其余依赖包保持官方版本不动。

本仓库（`NingboMaiTux/MaiZODB`）不是 GitHub 的 fork 关系，是从 zopefoundation/ZODB 的 `5.8.0` 版本源码压缩包重新建的独立仓库——完整拉取上游全部历史在实际操作中因为下载环境不稳定放弃了，这个仓库现在只有 5.8.0 这一份代码，没有上游的提交历史。不顺带升级 ZODB 大版本，避免把"关系化改造"和"升级 ZODB"两件事的风险混在一起排查。

当前 `setup.py` 里的版本号是 `5.8.0.post1`（跟官方 `5.8.0` 故意不一样），原因见第 7 节。

⚠️ 运行环境是 **Python 2.7**（已 EOL），这个仓库里的代码要在这个解释器下跑，不能用 Python 3 语法。对话中用来验证"自动建表/自动加列/引用变外键"这套机制是否可行的原型是在 Python 3 环境下写的，只用于验证思路是否成立，不是可复用的实现，不纳入这个仓库的代码基线。

---

## 3. 设计理念：让 ZODB 变成一个纯粹的 ORM

业务代码（senaite 及所有 addon）继续用 Python 对象编程——`obj.attribute`、`Persistent`、`transaction.commit()`，完全不感知底层怎么存。变的只是"对象状态最终落在哪"：从 pickle 字节，变成关系型的行和列。ZODB 对业务代码而言的角色，和 SQLAlchemy/Django ORM 对一个普通应用而言的角色是一样的——区别是这层映射不是在应用层另外套一个 ORM 库，而是直接内建进 ZODB 自己的持久化机制里，senaite 感知不到这层映射的存在。

具体机制：`ZODB/serialize.py` 里 `ObjectWriter.serialize()` 产出的 pickle 字节，照常交给 RelStorage 写入 `object_state`（RelStorage 的 MVCC、冲突解决、pack、多实例缓存失效全部不变，继续免费使用）；同时，把同一个对象的原始存储属性反射一份，自动建表/加列，写进关系表。

---

## 4. 具体设计

### 4.1 钩子位置

`ZODB/serialize.py` 的 `ObjectWriter.serialize(obj)` / `ObjectReader`。这里拿到的是完整的 Python 对象（不是 `IStorage.store()` 那种只有字节的接口），能反射 `__dict__`，但**不是** acquisition 包装过的对象——所以只能用它做到下面 4.2 这条边界内的事。

### 4.2 反射范围：只映射原始存储属性，不映射方法算出来的值

只反射 `obj.__getstate__()` 里本来就有的字段。不尝试把 `getClientTitle()` 这类需要 `aq_parent` 的方法结果也变成列——这类值在这个钩子位置本来就拿不到 acquisition 上下文。这条边界换来的是：**零 senaite 代码改动**。

### 4.3 特殊处理：容器类不拆列

`BTree`/`Bucket`/`Tree`/`Set`（以及由它们拼出来的 ZCatalog 索引内部结构）继续序列化成 pickle blob，不自动建表。理由：它们的 `__getstate__()` 是打包的键值数组，拆出来的"列"没有业务意义；留着不动，ZCatalog 和 senaite 现有的列表/搜索/报表代码完全不用碰。

### 4.4 引用与集合

- 单个持久对象引用 → 外键列（`<attr>_id`）。
- 属性是"元素全是持久对象的列表" → 识别为一对多，拆成子表，子表补一个指回父表的外键列。

这两条机制已经用一个独立的小规模原型验证过确实可行（自动建表、自动加列、引用变外键、集合拆子表、类型冲突自动处理，全部有实测输出）——该原型只用于验证思路是否成立，不是可复用的实现，不纳入这个仓库的代码基线。

### 4.5 容器归属（parent_uid）

Zope 的 Folder 类对象，子对象引用挂在**父级**的属性上，子对象自己的 `__dict__` 不知道自己的父是谁。所以做法是：序列化父级（Folder 类）对象时，顺手把每个子对象行的 `parent_uid` 列也写一份。这条要从一开始就设计进去——事后补的话，已经落进关系表的历史行都要重新过一遍。

⚠️ **待验证**：Zope/OFS 容器结构的具体实现细节（`_objects` 和真正的子对象引用具体怎么存），本对话是按一般性认知推理出来的方向，还没有对着 senaite 实际跑的这份 Zope 源码逐行确认过，实现前需要单独花时间核实。

### 4.6 主键

关系表主键用**真实 ZODB OID**，不用新生成的自增 id——这是第 6 节"轻量备份"能成立的前提：恢复时要在原 OID 上重建对象，否则对象之间的引用会对不上。

### 4.7 类型冲突

同一属性前后出现不同 Python 类型时，把该列放宽成 `text`（已验证的策略；`ALTER COLUMN ... TYPE text USING col::text` 会用 Postgres 自己的转换规则处理已有行，不是应用层再写一遍）。备选做法是保留原列另开 `jsonb` 兜底列，两种都能不丢数据，选哪种是可以晚点再定的实现细节。

### 4.8 索引

- 主键（OID）：自动获得，无需额外处理。
- 外键列：**应该自动建索引**——Postgres 的外键约束只保证被引用方（主键）有索引，不会给引用方这一列自动建索引，不专门处理的话，"查某样品下所有分析结果"这类最常见的查询会全表扫描。
- 其余业务字段（比如 `analysis.result`）：**不自动建索引**，上线后按实际查询模式（`EXPLAIN ANALYZE`/`pg_stat_statements`）手动加，这是常规 DBA 工作，和"是不是 ZODB 改出来的"无关。

---

## 5. 一致性：关系写入要不要和 RelStorage 共用同一个 Postgres 事务

这是方案 A 里唯一还需要动手验证、不能只靠推理确定的技术风险点：

- **理想情况**：关系列的写入复用 RelStorage 当前正在用的那个活连接（不是只拿 DSN 另开一个连接），这样两边其实是同一个 Postgres 事务，原子提交——"两份数据不一致"的风险退化到纯理论级别（等同于怀疑 Postgres 自己的 ACID）。
- **退化情况**：如果做不到共用连接，只能像 senaite.docker 里 `maitux.auditjournal` 这个 addon 现在那样（`2.7.0-maitux1/addons/common/maitux.auditjournal/src/maitux/auditjournal/db.py` 第 88-93 行）另开连接、退化成弱一致——这时候"理论上不一致"就变成了实打实的、概率很低但真实存在的风险。

⚠️ **待验证**：RelStorage 3.5.0 的 adapter/connmanager 是否暴露了"当前事务活连接"这个可以拿到手的对象（`maitux.auditjournal` 目前只拿到了 DSN，没有拿连接本身）。这个不确认清楚，就不知道一致性保证能做到哪一档。

---

## 6. 轻量备份（次目标，排在主目标做稳之后）

思路：只备份关系表 → 恢复工具读关系表 → 按 OID 反推每个对象的 `__dict__`（外键/子表拆回引用和集合，`parent_uid` 拆回容器结构）→ 喂给**未经修改的官方** `ObjectWriter.serialize()` 产出合法 pickle → 灌回一套全新初始化的 RelStorage schema。

- 关系表现在设计是"一个业务对象一行、覆盖式更新"，只存最新状态——这套恢复只能拿回当前状态，**拿不回 ZODB 的 undo/历史版本**。如果不需要 undo，这条不是问题；需要的话，关系表要改成按 `(对象, 版本)` 存多行，存储量和恢复工具都要跟着变。
- 恢复工具是离线批处理，不碰线上写入路径，坏了不影响真实数据；可靠性通过"恢复到干净环境 + 和原库比对"来验证，不是靠信任。
- 不管这个工具做成什么样，现有的整库 `lims_db` 常规备份（`pg_dump`/物理备份/WAL 归档）照常进行，两者并存。

---

## 7. 部署机制（已实现）

最初设想是 fork 一个带完整历史的 git 仓库，靠 buildout 的 `[sources]`/`mr.developer` 跟踪分支——实际操作时，完整拉取 ZODB 20 多年的历史在这台机器的网络环境下多次失败，改成了现在这套方式：

**仓库**：`NingboMaiTux/MaiZODB`，从 5.8.0 源码压缩包建的独立仓库，包名仍然是 `ZODB`（`setup.py:59`），业务代码 `import ZODB` 不受影响。

**分发方式**：不通过 git 拉取，打包成 sdist、以文件形式进 senaite.docker：

1. 改完代码后，在本仓库根目录 `python setup.py sdist`，产出 `dist/ZODB-<版本号>.tar.gz`。
2. 拷贝进 senaite.docker 的 `2.7.0-maitux1/vendor/`（Docker 构建上下文是 `2.7.0-maitux1/`，senaite.docker 仓库根目录在上下文之外，`COPY` 够不到，所以必须放在这一层里面；`latest/` 那个变体要用的话得再拷一份到 `latest/vendor/`）。
3. senaite.docker 的 `Dockerfile` 里 `COPY vendor/ZODB-<版本号>.tar.gz $WHEELHOUSE/`，落进 `buildout.cfg` 本来就有的 `find-links = file:///home/senaite/wheelhouse`。
4. `buildout.cfg` 的 `eggs +=` 显式加了 `ZODB`，`[versions]` 钉死 `ZODB = <版本号>`。

版本号故意跟官方不一样（当前是 `5.8.0.post1`），防止 buildout 从 PyPI 拿到官方版覆盖掉这份。**每次改完这个仓库的代码，版本号都要跟着提一个新号，重新打包、重新拷贝进 senaite.docker、重新钉版本**——这是相对最初"git 分支跟踪"方案的代价：改一次 ZODB 要手动走一遍这个流程，不是 push 完 buildout 自动拉到最新。

**Senaite 源码不用动。**

---

## 8. 尚未确定/需要在实现阶段解决的事

1. 第 5 节：RelStorage 3.5.0 能否拿到活跃事务连接（决定一致性保证的档位）。
2. 第 4.5 节：Zope/OFS 容器归属的具体实现细节。
3. 类名到表名的映射：现在的验证脚本直接用 `cls.__name__.lower()`，senaite 有 143+ 个注册内容类型，需要确认没有同名类跨模块冲突；有冲突的话表名要改用完整模块路径或一个显式的类注册表。
4. 第 4.7 节：类型冲突具体选"放宽成 text"还是"jsonb 兜底列"，两种都可行，实现前再定。

这几条都是"设计阶段诚实标注为未验证"，不是遗漏——都需要在正式动手实现 `ObjectWriter`/`ObjectReader` 前后逐项确认。
