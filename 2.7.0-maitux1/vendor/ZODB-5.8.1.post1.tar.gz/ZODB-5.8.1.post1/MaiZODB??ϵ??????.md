# MaiZODB 关系化方案

| 项 | 值 |
|---|---|
| 日期 | 2026-09-23 |
| 实现完成 | 2026-09-25，8 步，详见仓库 `CHANGES.rst` 的 unreleased 段 |
| 本次更新 | 2026-09-26，对着真实 `maitux-lims` 部署跑过一轮之后，把本文档几处"设计阶段的推测"换成"实测确认"或"实测推翻"，见各节内联标注 |

---

## 1. 目标与优先级

- **主目标**：业务对象的存储字段能以真实关系列的形式被 SQL 直接查询（`WHERE`/`JOIN`），不再只有 ZCatalog 那种倒排索引。
- **次目标**（明确排在主目标之后）：只备份关系表也能用自定义工具还原出完整的 ZODB/RelStorage 数据库，作为常规整库备份之外的一种轻量手段——**不替代**现有的 `lims_db` 整库备份。

---

## 2. 版本基线

基线版本：**ZODB 5.8.0** → 实现完成后是 **5.8.1.post1**——本方案正式动手前，先把上游 5.8.0→5.8.1 之间的两处有用变化（`classFactory` 惰性查找的一个真实 bug 修复；backport 上游 5.8.1 的其余改动）单独做完、单独提交，再在这个基线上做关系化，两件事的排查风险不混在一起。5.8.0 这个初始版本号是从 `maitux-lims` 容器实际运行环境里直接读出的（`/home/senaite/senaitelims/eggs/cp27mu/`），不是查文档猜的。这也是本方案唯一要改造的包：实测的 pip 依赖关系是 `ZODB` 依赖 `persistent`/`BTrees`/`transaction`，没有包反过来依赖 `ZODB`；本方案要改的钩子（见第 4 节）只存在于 `ZODB` 自己的源码里，其余依赖包保持官方版本不动。

本仓库（`NingboMaiTux/MaiZODB`）不是 GitHub 的 fork 关系，是从 zopefoundation/ZODB 的 `5.8.0` 版本源码压缩包重新建的独立仓库——完整拉取上游全部历史在实际操作中因为下载环境不稳定放弃了，没有上游的提交历史。不顺带升级 ZODB 大版本，避免把"关系化改造"和"升级 ZODB"两件事的风险混在一起排查。

当前 `setup.py` 里的版本号是 `5.8.1.post1`（跟官方 `5.8.1` 故意不一样，`.post1` 这个后缀在关系化改造期间一直没变过，见第 7 节为什么），原因见第 7 节。

⚠️ 运行环境是 **Python 2.7**（已 EOL），这个仓库里的代码要在这个解释器下跑，不能用 Python 3 语法。对话中用来验证"自动建表/自动加列/引用变外键"这套机制是否可行的原型是在 Python 3 环境下写的，只用于验证思路是否成立，不是可复用的实现，不纳入这个仓库的代码基线。

---

## 3. 设计理念：让 ZODB 变成一个纯粹的 ORM

业务代码（senaite 及所有 addon）继续用 Python 对象编程——`obj.attribute`、`Persistent`、`transaction.commit()`，完全不感知底层怎么存。变的只是"对象状态最终落在哪"：从 pickle 字节，变成关系型的行和列。ZODB 对业务代码而言的角色，和 SQLAlchemy/Django ORM 对一个普通应用而言的角色是一样的——区别是这层映射不是在应用层另外套一个 ORM 库，而是直接内建进 ZODB 自己的持久化机制里，senaite 感知不到这层映射的存在。

具体机制：`ZODB/serialize.py` 里 `ObjectWriter.serialize()` 产出的 pickle 字节，照常交给 RelStorage 写入 `object_state`（RelStorage 的 MVCC、冲突解决、pack、多实例缓存失效全部不变，继续免费使用）；同时，把同一个对象的原始存储属性反射一份，自动建表/加列，写进关系表。

---

## 4. 具体设计

### 4.1 钩子位置（实现后有调整）

原计划是单点挂在 `ZODB/serialize.py` 的 `ObjectWriter.serialize(obj)`。实际做出来的钩子更靠近 `Connection` 的两阶段提交本身：`Connection.py` 在 `tpc_begin`/每个对象 `record`/`tpc_vote`/`tpc_finish`/`tpc_abort`/`abort` 这几个节点都调用一个可插拔的 `Mapper`（见 `ZODB/relational/__init__.py`），`serialize.py` 只做了一件小事——把 `ObjectWriter.serialize()` 算出来的 `state` 顺手存一份（`self._last_state`），让 `record()` 不用对同一个对象重复调用一次 `__getstate__()`。这样改的原因：关系写入要和 RelStorage 共用一个 Postgres 连接（见第 5 节），只有在 `tpc_vote`——存储已经投票、事务还没关闭——这个窗口才拿得到那个连接；单挂在 `serialize()` 里够不着这个时机。

这里拿到的仍然是完整的 Python 对象（不是 `IStorage.store()` 那种只有字节的接口），能反射 `__dict__`，但**不是** acquisition 包装过的对象——这条边界的判断在设计阶段就是对的，第 4.5 节已经拿真实部署验证过。

### 4.2 反射范围：只映射原始存储属性，不映射方法算出来的值

只反射 `obj.__getstate__()` 里本来就有的字段。不尝试把 `getClientTitle()` 这类需要 `aq_parent` 的方法结果也变成列——这类值在这个钩子位置本来就拿不到 acquisition 上下文。这条边界换来的是：**零 senaite 代码改动**。

### 4.3 特殊处理：容器类不拆列

`BTree`/`Bucket`/`Tree`/`Set`（以及由它们拼出来的 ZCatalog 索引内部结构）继续序列化成 pickle blob，不自动建表。理由：它们的 `__getstate__()` 是打包的键值数组，拆出来的"列"没有业务意义；留着不动，ZCatalog 和 senaite 现有的列表/搜索/报表代码完全不用碰。

### 4.4 引用与集合（识别方式和设计阶段设想的不一样）

设计阶段设想的是"属性值本身是不是一个持久对象（的列表）"——按值的形状判断。实测发现 senaite 里单值和多值引用字段存的都是**目标对象的 UID 字符串**，不是持久对象引用本身，字符串没法和"这是一段普通文本"区分开来（见 `CHANGES.rst`）。所以实际做法改成了按**schema 声明**判断：读内容类的 Archetypes schema，字段类的类名精确匹配 `UIDReferenceField`/`ReferenceField`（不是继承自某个真实基类，因为这个环境里 Archetypes 基类未必能 import 到，见 `ZODB/relational/fields.py`），`multiValued` 标出是单值还是多值。

- 单值引用字段 → 普通文本列，存目标 UID。
- 多值引用字段 → 拆成子表（`object_reference`，所有类型共用一张表，见 `references.py`），每行一个 `(对象, 字段, 目标 UID)`；字段值收窄后比原来的目标列表少的那些成员，靠 `Row.prune` 机制在 UPDATE 之后单独删掉。

代价：只认 Archetypes 声明的引用字段，一个字段如果不是靠 schema field 存储引用（比如下面第 8.5 节提到的 Dexterity 内容），这套识别完全看不见。

### 4.5 容器归属（parent_uid）——实测推翻，未实现，留作已知限制

这条原计划：序列化父级（Folder 类）对象时，顺手把每个子对象行的 `parent_uid` 列也写一份。对着真实 `maitux-lims` 部署实测，这条路走不通，两个环节都是实测确认、不是推理：

1. **Acquisition 到不了 `record()` 时的对象**：给一次真实提交挂了诊断用的 `Mapper`，`hasattr(obj, 'aq_parent')` 是 `False`。Acquisition wrapper 只在"通过容器 `__getitem__` 取到这个对象"这次访问上短暂存在，`Connection` 自己缓存、拿去提交的是没包过的裸对象。
2. **子对象加进去时，父 Folder 也不会跟着一起存**：在一个 Client 下面新建一个 Contact，同一个事务里存了 180 个对象，全部是目录索引（`senaite_catalog_contact`/`uid_catalog` 等）内部的 BTree 结构，Client 这个父对象本身完全没有出现在里面——这个 senaite 版本的容器归属关系是靠 catalog 维护的，不是靠父对象自己的 `__dict__` 发生变化。

两条路都堵了之后，唯一还剩的办法是取数时去查 senaite 自己的 catalog（`reference_catalog`/`uid_catalog`），但那需要 Mapper 能拿到"当前 site"——现在完全没有这个能力，而且是把"提交时的本地计算"换成"提交时的一次实时查询"，代价性质和现在整套机制都不一样。**决定**：先不做，第一步（存成关系表能被 SQL 查）已经达成，不依赖这条；样品和分析的从属关系，等真正需要再单独设计。

### 4.6 主键

关系表主键用**真实 ZODB OID**，不用新生成的自增 id——这是第 6 节"轻量备份"能成立的前提：恢复时要在原 OID 上重建对象，否则对象之间的引用会对不上。

### 4.7 类型冲突

同一属性前后出现不同 Python 类型时，把该列放宽成 `text`（已验证的策略；`ALTER COLUMN ... TYPE text USING col::text` 会用 Postgres 自己的转换规则处理已有行，不是应用层再写一遍）。备选做法是保留原列另开 `jsonb` 兜底列，两种都能不丢数据，选哪种是可以晚点再定的实现细节。

### 4.8 索引

- 主键（OID）：自动获得，无需额外处理。
- 外键列：**应该自动建索引**——Postgres 的外键约束只保证被引用方（主键）有索引，不会给引用方这一列自动建索引，不专门处理的话，"查某样品下所有分析结果"这类最常见的查询会全表扫描。
- 其余业务字段（比如 `analysis.result`）：**不自动建索引**，上线后按实际查询模式（`EXPLAIN ANALYZE`/`pg_stat_statements`）手动加，这是常规 DBA 工作，和"是不是 ZODB 改出来的"无关。

---

## 5. 一致性：关系写入要不要和 RelStorage 共用同一个 Postgres 事务——**已实现理想情况**

结论：做到了。`storage._tpc_phase.shared_state.store_connection`（RelStorage 私有属性，没有公开 API，封装在 `ZODB/relational/relstorage_support.py` 一个文件里）就是"当前事务活连接"，`tpc_vote` 阶段——存储已经投票、事务还没关闭——借用这个连接写关系表，`commit_phase2` 就是普通的 `connection.commit()`（RelStorage 对 PostgreSQL 不用真两阶段提交），所以两边是同一个 Postgres 事务，原子提交，不是退化成弱一致。已对着真实 RelStorage 3.5.0 + PostgreSQL 验证过（一次性 docker 容器里跑的集成测试，见 `src/ZODB/tests/testrelational_relstorage.py`），不是只在文档里成立。

代价：这个连接借用方式依赖 RelStorage 的私有实现细节，`relstorage_support.py` 的 docstring 里记了具体是对哪个版本验证过的；RelStorage 大版本升级需要重新确认这几个私有属性还在。

---

## 6. 轻量备份（次目标，排在主目标做稳之后）——实现比设计简单

原计划是"按 OID 反推 `__dict__`，喂给官方 `ObjectWriter.serialize()` 重新产出 pickle"——这条路没有走。实际做法更直接：关系表里每一行**顺带存一份原始 pickle 字节**（`zodb_state` 列，`bytea`，见 `projection.py` 的 `STATE_COLUMN`），不需要反推。原因是这份 pickle 本来就在手边（借用同一次 `serialize()` 调用的产物，见 4.1），比"从若干个关系列倒推出一个等价的 `__dict__`"更简单也更不容易错——代价是每行多存一份 pickle 的空间，`Projector(keep_state=False)` 可以关掉这份冗余，但那样这行就不再能单独还原。

- 不拆列的对象（BTree/Bucket 等容器内部结构，见 4.3）本来就整份存 pickle，天然可还原。
- 拆了列的内容对象，pickle 和列两份都在，互为校验：关系列坏了不影响还原（还是从 pickle 来），列本身则是"pickle 之外多出来的、能被 SQL 直接查询"的东西。
- 关系表现在设计是"一个业务对象一行、覆盖式更新"，只存最新状态——这套恢复只能拿回当前状态，**拿不回 ZODB 的 undo/历史版本**。如果不需要 undo，这条不是问题；需要的话，得按 `(对象, 版本)` 存多行，存储量和恢复工具都要跟着变。
- 不管这个工具做成什么样，现有的整库 `lims_db` 常规备份（`pg_dump`/物理备份/WAL 归档）照常进行，两者并存。
- 严格来说恢复工具本身（读 `zodb_state` 列、灌回一套新 RelStorage）还没写；上面这段是"现在的数据形状已经支持这样做"，不是"恢复工具已经做完"。

---

## 7. 部署机制（已实现）

**仓库**：`NingboMaiTux/MaiZODB`，从 5.8.0 源码压缩包建的独立仓库，包名仍然是 `ZODB`（`setup.py:59`），业务代码 `import ZODB` 不受影响。

**分发方式**：不通过 git 拉取，打包成 sdist、以文件形式进 senaite.docker：

1. 改完代码后，在本仓库根目录 `python setup.py sdist`，产出 `dist/ZODB-<版本号>.tar.gz`。
2. 拷贝进 senaite.docker 的 `2.7.0-maitux1/vendor/`（Docker 构建上下文是 `2.7.0-maitux1/`，senaite.docker 仓库根目录在上下文之外，`COPY` 够不到，所以必须放在这一层里面；`latest/` 那个变体要用的话得再拷一份到 `latest/vendor/`）。
3. senaite.docker 的 `Dockerfile` 里 `COPY vendor/ZODB-<版本号>.tar.gz $WHEELHOUSE/`，落进 `buildout.cfg` 本来就有的 `find-links = file:///home/senaite/wheelhouse`。
4. `buildout.cfg` 的 `eggs +=` 显式加了 `ZODB`，`[versions]` 钉死 `ZODB = <版本号>`。

版本号故意跟官方不一样（当前是 `5.8.1.post1`），防止 buildout 从 PyPI 拿到官方版覆盖掉这份。**实际做法和最初设想相反：版本号定下来之后就不再跟着改动一起提——一直钉死同一个 `5.8.1.post1`，只换 `vendor/` 里那个 tar.gz 的内容**，这样 `buildout.cfg`/`Dockerfile` 完全不用碰，改一次 ZODB 只需要重新打包、重新拷贝这一步。原因：如果每次改动都要跟着改 `buildout.cfg` 的版本号，等于每次都要动 senaite.docker 仓库里一份手工维护的配置文件，出错的地方变多，而版本号本身除了"防止 buildout 去 PyPI 抓官方版"之外没有别的意义。

⚠️ **踩过的坑**：BuildKit 的 `--mount=type=cache` 这几层缓存（`/cache/eggs`、`/cache/wheelhouse`）是跨镜像构建持久化的，不受 `COPY`/`CACHEBUST` 影响；Dockerfile 里原来的写法是"先 `COPY` 新 tar.gz 进去，再从缓存 `cp -a` 回填"，回填这一步会把刚 `COPY` 进去的新内容覆盖成缓存里的旧内容，而且 buildout 自己的 `eggs/` 目录如果已经有同版本号的编译产物，也会直接复用、不会重新读 `wheelhouse` 里的 tar.gz——这两层缓存叠在一起，实测表现就是"改完代码重新 build，镜像里还是旧代码"，且现象和"没生效"完全一样，容易误判成别的问题。修法是在这几个缓存目录做 `cp -a` 回填之前，先把匹配这个包名版本号的缓存条目删掉，逼着 buildout 重新读、重新编译。

**Senaite 源码不用动。**

---

## 8. 尚未确定/需要在实现阶段解决的事

8.1、8.2、8.6 是"设计阶段标了问号，现在有了确定答案"；8.3 是"一半做到了，另一半发现没做到"；8.4、8.5 是新识别出来的、明确决定先不解的限制，不是遗漏。

### 8.1 RelStorage 3.5.0 能否拿到活跃事务连接

~~待验证~~ **已解决**：能，见第 5 节。

### 8.2 Zope/OFS 容器归属的具体实现细节

~~待验证~~ **已实测，结论是走不通**，见第 4.5 节；不是"确认了细节然后照做"，是"确认了细节之后发现原计划不成立"。

### 8.3 类名到表名的映射

**部分解决**。`Namer`（`naming.py`）支持按 `(portal type)`/`(portal type, field)` 显式改名，两个字段撞到同一个列名、或字段名撞上 `oid`/`uid` 保留列，会直接抛 `NameConflict` 拒绝这次写入，不会静默覆盖——但**这个拒绝目前没有被外层接住**：`record()`（`mapper.py`）没有 try/except，`NameConflict` 会一路冒出去，让当次真实提交跟着失败，而不是只丢这一条关系投影（详见代码评审报告，最高优先级发现）。也就是"重名会被发现"这半句做到了，"发现之后不影响真实提交"这半句还没做到。

### 8.4 类型冲突

第 4.7 节提到的"放宽成 text"还是"jsonb 兜底列"——**仍未解决**，现在的实现两种都没做，同一列前后出现不兼容类型时的行为未定义（大概率是这一行在 `schema.py` 的按行 SAVEPOINT 里失败、被记日志跳过，没有验证过具体是什么报错）。

### 8.5 Dexterity 内容类的引用字段识别不到（新发现，决定先不修）

4.4 节的 schema 声明识别法用的是 `klass.schema.fields()`，这是 Archetypes 的约定；Dexterity 类（`SampleType`、`Worksheet`、`StockBatch` 等，senaite 往这个方向迁移的内容会越来越多）在类一级根本没有 `.schema` 属性，实测 `FieldInspector.fields(Worksheet)` 返回空。标量字段不受影响（`SampleType` 的 `min_volume`/`prefix` 等实测都正常进了列），只是引用字段（单值、多值都一样）完全不会被识别成外键或子表。已确认现象，未设计修法，决定先不修。

### 8.6 `object_reference` 表首次裁剪时的 `UndefinedTable`（新发现，已修复）

这张表第一次因为"这个字段这次刚好是空列表"而触发裁剪（prune）时，如果这张表之前从没写过，会报 `UndefinedTable`——已修复（判断表是否已建过，没建过就跳过裁剪），见 `CHANGES.rst`。
