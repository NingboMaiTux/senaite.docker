================
 Change History
================

unreleased
==========

Groundwork for the relational projection (see ``MaiZODB关系化方案.md``).
No projection happens yet; this is the plumbing it will hang off.

- Add ``ZODB.relational``, documenting the mapper protocol, and
  ``ZODB.relational.relstorage_support``, which borrows RelStorage's own
  open database connection so that projected rows join the storage's
  transaction instead of a second one. Confined to one module because it
  reaches through a private RelStorage attribute; verified against
  RelStorage 3.5.0.

- ``DB`` accepts a ``relational_mapper`` factory, also settable as the
  ``relational-mapper`` key of a ``zodb`` ZConfig section. Without one --
  the default -- none of this code runs and behaviour is unchanged.

- ``Connection`` drives the mapper across the commit: ``tpc_begin``,
  ``record`` per stored object, ``tpc_vote`` once the storage has voted
  and while its transaction is still open, then ``tpc_finish`` or
  ``tpc_abort``. The mapper is looked up lazily, so a connection already
  pooled by ``DB.__init__`` still picks one up.

- Add the mapping layer: ``naming`` decides what tables and columns are
  called, ``valuetypes`` gives each stored value the narrowest honest SQL
  type, ``projection`` turns an object into the row that represents it,
  and ``mapper.BufferingMapper`` collects a transaction's rows and hands
  them over once the storage has voted. Nothing composes SQL or touches a
  database yet.

  Content objects -- anything with a ``portal_type`` -- are spread across
  columns under business names in the usual lower-case underscored style.
  Everything else is kept whole in one row holding its pickle, which is
  what lets the projection be restored on its own. Rows for content
  objects keep the pickle too, since columns alone cannot rebuild a field
  that holds a sub-object; ``Projector(keep_state=False)`` trades that
  away to halve the storage.

- ``Mapper`` gains ``abort``, for a transaction abandoned before its
  commit began. A savepoint stores objects, so ``record`` can happen
  before ``tpc_begin`` and a mapper may be holding rows even though the
  storage was never told anything.

- ``ObjectWriter`` keeps the state of the object it most recently
  serialized, so the projection can reuse it rather than calling
  ``__getstate__()`` a second time. The pickle is byte for byte
  unchanged, which ``ZODB.tests.testrelational`` asserts.

- Give the mapping layer the three shapes senaite's own stored data
  turned out to have, confirmed by reading Products.Archetypes 1.16.6
  and NingboMaiTux/senaite.core (2.x branch), not assumed:

  - ``valuetypes`` gains ``timestamp with time zone``/``date`` rules.
    One column type for every moment regardless of whether the value
    carries a zone, so the column's type cannot change out from under
    a later, differently-shaped value. Zope's ``DateTime`` -- what
    Archetypes date fields actually hold -- converts through
    ``asdatetime()``; ZODB does not depend on Zope, so the rule is a
    no-op where ``DateTime`` is not installed.

  - ``ZODB.relational.fields`` reads a content class's Archetypes
    schema, once per class, to tell a reference field from a plain one.
    This has to come from the schema rather than being guessed from the
    value: a value looks identical whether the field holding it is a
    reference or plain text, and guessing per-value would make a
    column's meaning depend on what happened to be in it that time.
    ``Row.references`` names the columns this way found to hold another
    object's UID, which is where an index belongs -- PostgreSQL indexes
    only the referenced side of a foreign key, never the referencing
    side. A reference field senaite's schema does not expose the shape
    of is still stored as an ordinary text column, just unindexed.

  - ``ZODB.relational.derived`` computes companion columns from a
    field's value without replacing it: ``Result`` stays exactly the
    text it was stored as (senaite records ``<0.05`` and ``ND``
    alongside plain numbers) and gains ``_num``/``_operator`` columns
    where a number can be read out of it, which is what makes averages
    and trend queries possible. Which fields get this is configuration
    (``Derivations``), not something ZODB decides on its own.

  - ``projection`` folds an object's own identifier -- ``_at_uid``
    (Archetypes) or ``_plone.uuid`` (Dexterity) -- into one ``uid``
    column regardless of which attribute it came from, so every table
    offers the same join key without a query having to know which
    framework a content type happens to be built on. Confirmed by
    reading both: senaite's highest-value content types (AnalysisRequest,
    Analysis, Client, Batch) are still Archetypes; Dexterity so far
    covers mostly configuration types.

  Also confirmed, contradicting section 4.4 of ``MaiZODB关系化方案.md``:
  senaite references are UID strings (``UIDReferenceField`` ends up
  calling ``StringField.set``), never persistent object references, so
  "single reference becomes a foreign key" does not fire on real data --
  the foreign key has to be the UID column above.

- Add ``ZODB.relational.workflow``, decomposing CMFCore's
  ``workflow_history`` -- who did what to an object, and when, kept
  verbatim by every DCWorkflow-based application including senaite --
  into one row per transition in a shared ``workflow_transition`` table,
  across every workflow and content type, which is what a turnaround-time
  question ("how long from received to published") usually wants to
  query across. Confirmed against ``senaite_analysis_workflow``'s own
  definition, not assumed: entries carry ``action``/``actor``/
  ``comments``/``review_state``/``time``, and any workflow-specific
  variable becomes its own column the same way an unrecognised business
  field would.

  ``workflow_history`` never has to be reproduced here faithfully to
  keep the projection restorable: it is itself a persistent object
  (confirmed empirically -- ``ZODB.tests.testrelationalmapping``
  exercises a real commit, not just the shape on paper), so it already
  gets a whole-pickle row of its own through the existing path for
  objects with no ``portal_type``. The transitions are a queryable,
  best-effort *extra* alongside that, on by default and never load-
  bearing for restoring an object.

  This needed ``Row`` to grow a fourth kind of information beyond a
  table and its columns: ``children``, further rows a stored object
  produced that are not themselves stored objects (a transition has no
  ZODB oid of its own) and so travel with the row that produced them --
  dropping a stale copy of an object now drops what was derived from it,
  without ``BufferingMapper`` having to know how. ``Row`` moves to its
  own module, ``ZODB.relational.rows``, to stay reachable from
  ``workflow.py`` without a cycle.

- Add ``ZODB.tests.testrelational_relstorage``, the one thing every
  other test in this package cannot prove: that
  ``relstorage_support.store_cursor()`` returns a *real* live
  connection, on which SQL genuinely commits and rolls back together
  with RelStorage's own writes. Run against a real PostgreSQL 18 and
  RelStorage 3.5.0 (the versions senaite.docker actually pins), on an
  isolated throwaway database -- never against ``lims_db`` or any table
  this suite did not itself create. Confirms:

  - the store cursor is reachable and usable at ``tpc_vote``;
  - our rows are visible from a wholly independent connection once
    ``tpc_finish`` returns, alongside RelStorage's own ``object_state``
    rows from the same commit;
  - rows (and even the ``CREATE TABLE``/``ALTER TABLE`` DDL our test
    writer issues -- PostgreSQL DDL is transactional too) written
    during ``tpc_vote`` roll back together with RelStorage's own data
    when the transaction is aborted *after* voting, which is the actual
    claim behind sharing a connection, not merely "we never called
    commit".

  Skipped by default (``ZODB_RELSTORAGE_TEST_DSN`` unset); needs
  RelStorage and psycopg2, which are not otherwise a dependency of this
  package and were not installable on Windows/Python 2.7 here (RelStorage's
  C extension needs an old MSVC toolchain this machine does not have),
  so this was run inside a disposable Linux container instead.

- Decide the watermark and deletion story for downstream extraction (a
  data lake reading the projection), without writing any code yet --
  both belong to the SQL writer that does not exist until a later step,
  and are recorded here so the reasoning is not lost before then:

  - **Watermark**: a row's freshness will be a ``write_seq`` column
    filled by a PostgreSQL sequence's ``nextval()`` at INSERT time, not
    the ZODB transaction id. Confirmed by reading RelStorage's vote/
    finish state machine: by default (``RELSTORAGE_LOCK_EARLY`` unset,
    which is how senaite.docker runs it) the tid is not allocated until
    inside ``tpc_finish``, which is *after* ``commit_phase2`` -- the
    real PostgreSQL ``COMMIT`` -- has already run. Waiting for it would
    mean a second, separate write after our own transaction has closed,
    giving up exactly the atomicity the whole design exists for.
    ``nextval()`` has no such problem: it is evaluated as part of the
    same ``INSERT``, in the same transaction, so it commits or rolls
    back with everything else, same as any other column.

  - **Deletion**: not attempted here. Confirmed real rather than
    theoretical -- senaite deletes objects outright in ordinary
    operation (duplicate and reference analyses, attachments, a JSON
    API remove endpoint) -- but ZODB has no per-transaction signal for
    it: removing a child from a container only marks the *container*
    modified, and the child's own last state is simply never visited
    again, with nothing to distinguish "quietly unmodified" from
    "gone" until a pack. The one place ZODB does compute true
    reachability is inside ``pack()``, and RelStorage's own
    implementation of that turned out to be involved enough (a
    persistent, incrementally-updated ``object_ref`` table, not a
    plain one-shot graph walk) that claiming to hook it correctly
    without the same kind of real-PostgreSQL validation given to the
    connection-sharing claim above would be asserting more confidence
    than the code has earned -- and the failure direction that gets
    it wrong is the bad one: a live sample reported as deleted, not
    merely a deleted one reported late.

    Decided instead: MaiZODB makes no claim about deletion at all.
    Every row's ``write_seq`` is enough for a consumer to reconcile a
    full snapshot of currently-live keys against what it already has
    and infer what dropped out, on whatever cadence it chooses --
    which fits how the projection is meant to be read here: read-only,
    on a lake's own schedule, not a live system another write depends
    on. Revisit if a consumer ever needs deletion faster than that.

- Add ``ZODB.relational.schema``, the real SQL writer: ``PostgreSQLWriter``
  and the ``SchemaCache`` it needs to be usable in production, replacing
  the throwaway reflect-and-``ALTER``-every-row stand-in the integration
  test used through the previous few entries.

  - Table and column DDL is issued at most once per process, not once
    per commit: without this, an unconditional ``ALTER TABLE ... ADD
    COLUMN IF NOT EXISTS`` on every single write would mean an ACCESS
    EXCLUSIVE lock, however brief, on every single commit forever, not
    just the first one -- multiplied across every worker process. The
    ``IF NOT EXISTS``/duplicate-error handling still covers several
    processes racing to create the same thing for the first time, right
    after a deploy; nothing here coordinates between processes, since
    PostgreSQL itself already does.

  - ``write_seq`` (decided two entries up) is implemented: one global
    sequence shared by every table, each table's column defaulting to
    its ``nextval()`` on insert and set to a fresh one explicitly in
    every ``ON CONFLICT ... DO UPDATE``, since a column's ``DEFAULT``
    only applies to a fresh row, not one an upsert is merely touching
    again.

  - A row with no ``oid`` of its own -- currently only a workflow
    transition -- needs something else to upsert against, or its whole
    history re-projects as a duplicate every time its object is stored
    again. ``Row`` gained ``natural_key`` for this; ``workflow.py``
    sets it to ``(content_oid, workflow_id, sequence)``. The backing
    ``UNIQUE`` constraint is added the same racy, ``IF NOT EXISTS``-less
    way table-name collisions are for everything else in PostgreSQL:
    caught by SQLSTATE rather than coordinated. Confirmed against a
    real server rather than assumed, because guessing wrong here would
    have meant silently not catching the race at all -- PostgreSQL
    raises ``duplicate_table`` (``42P07``) for this, not the more
    general-sounding ``duplicate_object`` (``42710``) that seemed the
    obvious guess: ``ADD CONSTRAINT ... UNIQUE`` backs the constraint
    with an index of the same name, and it is that name collision
    actually speaking.

  - Every row is written under its own savepoint: a failure in the
    projection must never be the reason a real commit fails, which
    ``BufferingMapper.tpc_vote`` now also backstops by catching
    whatever a writer raises regardless. Building this surfaced a
    subtler version of the same requirement: a row's DDL is only
    recorded into ``SchemaCache`` once that row's *entire* attempt
    (table, columns, constraint, and the upsert itself) succeeds --
    not eagerly as each piece is issued -- because a later failure in
    the same row rolls back everything since its savepoint, including
    DDL from earlier in that same row, and a cache entry surviving that
    rollback would desync from what PostgreSQL actually has for the
    rest of the process's life. Caught by extending the integration
    test with a deliberately-impossible row alongside a good one in the
    same commit, not by inspection.

  Validated against real PostgreSQL and RelStorage, extending
  ``ZODB.tests.testrelational_relstorage``: re-storing an object with
  existing transitions does not duplicate them; ``write_seq`` advances
  on update as well as insert; a bad row does not fail the commit its
  good neighbor is part of; and, in a new
  ``ConcurrentConstraintCreationTests``, two separate sessions racing
  to create the same constraint -- the scenario the SQLSTATE guess
  above turned out to matter for -- both succeed with exactly one
  constraint between them.

- Add ``ZODB.relational.senaite``: the one place senaite-specific
  policy is allowed to live, everything else under ``ZODB.relational``
  having stayed deliberately generic (any ``portal_type``, any
  Archetypes-shaped schema, any CMFCore ``workflow_history``). Two
  small things needed deciding here, not mechanism: which fields get
  the numeric derivation (``Analysis.Result``, the one confirmed so
  far -- see the entry that added ``derived.py``), and that one
  :class:`~ZODB.relational.schema.PostgreSQLWriter` should be shared
  by every connection in the process rather than a fresh one each
  time, since its schema cache is only worth having if it outlives a
  single commit.

  This is also, deliberately, the first piece of this whole effort
  meant to be *pointed at* rather than only tested against: a real
  ``zope.conf`` sets ``relational-mapper`` (added in an earlier entry)
  to ``ZODB.relational.senaite.mapper_factory`` and gets the whole
  pipeline built in this branch so far, wired up, with no senaite code
  and no new PostgreSQL connection configuration -- ``PostgreSQLWriter``
  never opens a connection of its own, only ever borrows RelStorage's,
  so it writes to whatever ``rel-storage`` in buildout.cfg already
  points at, by construction. The docstring has the exact config
  snippet.

  Validated against real PostgreSQL and RelStorage, in a new
  ``SenaiteWiringIntegrationTests``: ``mapper_factory`` used exactly as
  a real ``zope.conf`` would name it, not the hand-assembled
  ``Projector``/``Derivations`` the other integration tests build for
  themselves, produces a real derived ``result_num``/``result_operator``
  in the database.

  Not yet done: actually packaging this into senaite.docker's vendored
  build and turning ``relational-mapper`` on there. That is a
  materially bigger step than anything above -- it means this code
  running against real production data in the real ``maitux-lims``
  containers, not an isolated throwaway database -- and is being left
  for an explicit decision rather than folded into this commit.


5.8.1.post1 (2026-09-23)
=========================

MaiZODB-only changes, on top of upstream 5.8.0. Not an official ZODB
release.

- Fix ``Connection`` sometimes using the wrong ``classFactory``: frameworks
  such as Zope patch ``DB.classFactory`` *after* ``DB.__init__()`` has
  already opened and pooled an initial connection. That connection's
  ``ObjectReader`` had captured the pre-patch default class factory (which
  only catches ``ImportError``) instead of the framework's patched one
  (which catches broader exceptions and degrades gracefully to a
  ``Broken`` object), so whichever request happened to reuse that pooled
  connection could get an unhandled exception instead of a ``Broken``
  object when a class failed to load. ``Connection`` now looks up
  ``classFactory`` on the database lazily instead of snapshotting it at
  construction time, so it always sees the current value.

  This is the same underlying problem as upstream `issue #420
  <https://github.com/zopefoundation/ZODB/issues/420>`_, which upstream
  fixed differently in 6.3 (Python 3 only, requires the embedding
  framework to pass ``class_factory=`` into ``DB()``) -- not usable here
  since we stay on Python 2.7 and don't fork Zope.

- Backport two upstream 5.8.1 fixes (both Python-2.7-compatible, no
  functional changes beyond the originals):

  - Fix ``Connection.__repr__`` relying on a home-grown ``positive_id()``
    helper that could itself raise and turn error messages (e.g. for
    ``InvalidObjectReference``) into an unhelpful ``<unprintable ...>``.
    ``repr(connection)`` changes from ``<Connection at 0x...>`` to the
    default ``<ZODB.Connection.Connection object at 0x...>``. See
    upstream `PR #384 <https://github.com/zopefoundation/ZODB/pull/384>`_.
  - Fix ``--with-verify`` argument to the ``repozo --recover`` script; it
    was silently not recognized because the option was only registered as
    ``--with-verification``. See upstream `PR #381
    <https://github.com/zopefoundation/ZODB/pull/381>`_.


5.8.0 (2022-11-09)
==================

- Add support for Python 3.11.

- Expand and refactor tests for race conditions.


5.7.0 (2022-03-17)
==================

- Fix ``TypeError: can't concat str to bytes`` when running fsoids.py script
  with Python 3.
  See `issue 350 <https://github.com/zopefoundation/ZODB/issues/350>`_.

- Readd transaction size information to ``fsdump`` output;
  adapt `fsstats` to ``fsdump``'s exchanged order for ``size`` and ``class``
  information in data records;
  (fixes `#354 <https://github.com/zopefoundation/ZODB/issues/354>_).
  Make ``fsdump`` callable via Python's ``-m`` command line option.

- Fix UnboundLocalError when running fsoids.py script.
  See `issue 285 <https://github.com/zopefoundation/ZODB/issues/285>`_.

- Rework ``fsrefs`` script to work significantly faster by optimizing how it
  does IO. See `PR 340 <https://github.com/zopefoundation/ZODB/pull/340>`_.

- Require Python 3 to build the documentation.

- Fix deprecation warnings occurring on Python 3.10.

- Add support for Python 3.9 and 3.10.


5.6.0 (2020-06-11)
==================

- Fix race with invalidations when starting a new transaction. The bug
  affected Storage implementations that rely on mvccadapter, and could result
  in data corruption (oid loaded at wrong serial after a concurrent commit).
  See `issue 290 <https://github.com/zopefoundation/ZODB/issues/290>`_.
  As mentionned in pull request #307, interfaces are clarified about the fact
  that storage implementations must update at a precise moment the value that
  is returned by lastTransaction(): just after invalidate() or
  tpc_finish callback.

- Improve volatile attribute ``_v_`` documentation.

- Make repozo's recover mode atomic by recovering the backup in a
  temporary file which is then moved to the expected output file.

- Add a new option to repozo in recover mode which allows to verify
  backups integrity on the fly.

- Drop support for Python 3.4.

- Add support for Python 3.8.

- Fix ``DB.undo()`` and ``DB.undoMultiple()`` to close the storage
  they open behind the scenes when the transaction is committed or
  rolled back. See `issue 268
  <https://github.com/zopefoundation/ZODB/issues/268>`_.

- Make TransactionMetaData in charge of (de)serializing extension data.
  A new ``extension_bytes`` attribute converts automatically from
  ``extension``, or vice-versa. During storage iteration, ``extension_bytes``
  holds bytes as they are stored (i.e. no deserialization happens).
  See `issue 207 <https://github.com/zopefoundation/ZODB/pull/207>`_.

- Make a connection's savepoint storage implement its own
  (approximate) ``getSize`` method instead of relying on the original
  storage. Previously, this produced confusing DEBUG logging. See
  `issue 282 <https://github.com/zopefoundation/ZODB/issues/282>`_.

- Fix tests with transaction 3.0.

- Fix inconsistent resolution order with zope.interface v5.

- Remove ``ConnectionPool.map()``. Instead, ``ConnectionPool`` is now
  iterable. See `PR 280
  <https://github.com/zopefoundation/ZODB/pull/280>`_.

5.5.1 (2018-10-25)
==================

- Fix KeyError on releasing resources of a Connection when closing the DB.
  This requires at least version 2.4 of the ``transaction`` package.
  See `issue 208 <https://github.com/zopefoundation/ZODB/issues/208>`_.

5.5.0 (2018-10-13)
==================

- Add support for Python 3.7.

- Bump the dependency on zodbpickle to at least 1.0.1. This is
  required to avoid a memory leak on Python 2.7. See `issue 203
  <https://github.com/zopefoundation/ZODB/issues/203>`_.

- Bump the dependency on persistent to at least 4.4.0.

- Make the internal support functions for dealing with OIDs (``p64``
  and ``u64``) somewhat faster and raise more informative
  exceptions on certain types of bad input. See `issue 216
  <https://github.com/zopefoundation/ZODB/issues/216>`_.

- Remove support for ``python setup.py test``. It hadn't been working
  for some time. See `issue #218
  <https://github.com/zopefoundation/ZODB/issues/218>`_.

- Make the tests run faster by avoiding calls to ``time.sleep()``.

5.4.0 (2018-03-26)
==================

- ZODB now uses pickle protocol 3 for both Python 2 and Python 3.

  (Previously, protocol 2 was used for Python 2.)

  The zodbpickle package provides a `zodbpickle.binary` string type
  that should be used in Python 2 to cause binary strings to be saved
  in a pickle binary format, so they can be loaded correctly in
  Python 3.  Pickle protocol 3 is needed for this to work correctly.

- Object identifiers in persistent references are saved as
  `zodbpickle.binary` strings in Python 2, so that they are loaded
  correctly in Python 3.

- If an object is missing from the index while packing a ``FileStorage``,
  report its full ``oid``.

- Storage imports are a bit faster.

- Storages can be important from non-seekable sources, like
  file-wrapped pipes.

5.3.0 (2017-08-30)
==================

- Add support for Python 3.6.

- Drop support for Python 3.3.

- Ensure that the ``HistoricalStorageAdapter`` forwards the ``release`` method to
  its base instance. See `issue 78 <https://github.com/zopefoundation/ZODB/issues/788>`_.

- Use a higher pickle protocol (2) for serializing objects on Python
  2; previously protocol 1 was used. This is *much* more efficient for
  new-style classes (all persistent objects are new-style), at the
  cost of being very slightly less efficient for old-style classes.

  .. note:: On Python 2, this will now allow open ``file`` objects
            (but **not** open blobs or sockets) to be pickled (loading
            the object will result in a closed file); previously this
            would result in a ``TypeError``. Doing so is not
            recommended as they cannot be loaded in Python 3.

  See `issue 179 <https://github.com/zopefoundation/ZODB/pull/179>`_.

5.2.4 (2017-05-17)
==================

- ``DB.close`` now explicitly frees internal resources.  This is
  helpful to avoid false positives in tests that check for leaks.

- Optimize getting the path to a blob file. See
  `issue 161 <https://github.com/zopefoundation/ZODB/pull/161>`_.

- All classes are new-style classes on Python 2 (they were already
  new-style on Python 3). This improves performance on PyPy. See
  `issue 160 <https://github.com/zopefoundation/ZODB/pull/160>`_.

5.2.3 (2017-04-11)
==================

- Fix an import error. See `issue 158 <https://github.com/zopefoundation/ZODB/issues/158>`_.

5.2.2 (2017-04-11)
==================

- Fixed: A blob misfeature set blob permissions so that blobs and blob
  directories were only readable by the database process owner, rather
  than honoring user-controlled permissions (e.g. ``umask``).
  See `issue 155 <https://github.com/zopefoundation/ZODB/issues/155>`_.

5.2.1 (2017-04-08)
==================

- Fixed: When opening FileStorages in read-only mode, non-existent
  files were silently created.  Creating a read-only file-storage
  against a non-existent file errors.

5.2.0 (2017-02-09)
==================

- Call new afterCompletion API on storages to allow them to free
  resources after transaction complete.
  See `issue 147 <https://github.com/zodb/relstorage/issues/147>`__.
- Take advantage of the new transaction-manager explicit mode to avoid
  starting transactions unnecessarily when transactions end.

- ``Connection.new_oid`` delegates to its storage, not the DB. This is
  helpful for improving concurrency in MVCC storages like RelStorage.
  See `issue 139 <https://github.com/zopefoundation/ZODB/issues/139>`_.

- ``persistent`` is no longer required at setup time.
  See `issue 119 <https://github.com/zopefoundation/ZODB/issues/119>`_.

- ``Connection.close`` and ``Connection.open`` no longer race on
  ``self.transaction_manager``, which could lead to
  ``AttributeError``. This was a bug introduced in 5.0.1. See `issue
  142 <https://github.com/zopefoundation/ZODB/pull/143>`_.


5.1.1 (2016-11-18)
==================

- Fixed: ``ZODB.Connection.TransactionMetaData`` didn't support custom data
  storage that some storages rely on.

5.1.0 (2016-11-17)
==================

- ZODB now translates transaction meta data, ``user`` and
  ``description`` from text to bytes before passing them to storages,
  and converts them back to text when retrieving them from storages in
  the ``history``, ``undoLog`` and ``undoInfo`` methods.

  The ``IDatabase`` interface was updated to reflect that ``history``,
  ``undoLog`` and ``undoInfo`` are available on database objects.
  (They were always available, but not documented in the interface.)

5.0.1 (2016-11-17)
==================

- Fix an AttributeError that DemoStorage could raise if it was asked
  to store a blob into a temporary changes before reading a blob. See
  `issue 103 <https://github.com/zopefoundation/ZODB/issues/103>`_.

- Call _p_resolveConflict() even if a conflicting change doesn't change the
  state. This reverts to the behaviour of 3.10.3 and older.

- Closing a Connection now reverts its ``transaction_manager`` to
  None. This helps prevent errors and release resources when the
  ``transaction_manager`` was the (default) thread-local manager. See
  `issue 114 <https://github.com/zopefoundation/ZODB/issues/114>`_.

- Many docstrings have been improved.

5.0.0 (2016-09-06)
==================

Major internal improvements and cleanups plus:

- Added a connection ``prefetch`` method that can be used to request
  that a storage prefetch data an application will need::

    conn.prefetch(obj, ...)

  Where arguments can be objects, object ids, or iterables of objects
  or object ids.

  Added optional ``prefetch`` methods to the storage APIs. If a
  storage doesn't support prefetch, then the connection prefetch
  method is a noop.

- fstail: print the txn offset and header size, instead of only the data offset.
  fstail can now be used to truncate a DB at the right offset.

- Drop support for old commit protocol.  All of the build-in storages
  implement the new protocol.  This new protocol allows storages to
  provide better write performance by allowing multiple commits to
  execute in parallel.

5.0.0b1 (2016-08-04)
====================

- fstail: print the txn offset and header size, instead of only the data offset.
  fstail can now be used to truncate a DB at the right offset.

Numerous internal cleanups, including:

- Changed the way the root object was created.  Now the root object is
  created using a database connection, rather than by making low-level
  storage calls.

- Drop support for the old commit protocol.

- Internal FileStorage-undo fixes that should allow undo in some cases
  where it didn't work before.

- Drop the ``version`` argument to some methods where it was the last
  argument and optional.

5.0.0a6 (2016-07-21)
====================

- Added a connection ``prefetch`` method that can be used to request
  that a storage prefect data an application will need::

    conn.prefetch(obj, ...)

  Where arguments can be objects, object ids, or iterables of objects
  or object ids.

  Added optional ``prefetch`` methods to the storage APIs. If a
  storage doesn't support prefetch, then the connection prefetch
  method is a noop.

5.0.0a5 (2016-07-06)
====================

Drop support for old commit protocol.  All of the build-in storages
implement the new protocol.  This new protocol allows storages to
provide better write performance by allowing multiple commits to
execute in parallel.

5.0.0a4 (2016-07-05)
====================

See 4.4.2.

5.0.0a3 (2016-07-01)
====================

See 4.4.1.

5.0.0a2 (2016-07-01)
====================

See 4.4.0.

5.0.0a1 (2016-06-20)
====================

Major **internal** implementation changes to the Multi Version
Concurrency Control (MVCC) implementation:

- For storages that implement IMVCCStorage (RelStorage), no longer
  implement MVCC in ZODB.

- For other storages, MVCC is implemented using an additional storage
  layer. This underlying layer works by calling ``loadBefore``. The
  low-level storage ``load`` method isn't used any more.

  This change allows server-based storages like ZEO and NEO to be
  implemented more simply and cleanly.

4.4.3 (2016-08-04)
==================

- Internal FileStorage-undo fixes that should allow undo in some cases
  where it didn't work before.

- fstail: print the txn offset and header size, instead of only the data offset.
  fstail can now be used to truncate a DB at the right offset.

4.4.2 (2016-07-08)
==================

Better support of the new commit protocol. This fixes issues with blobs and
undo. See pull requests #77, #80, #83

4.4.1 (2016-07-01)
==================

Added IMultiCommitStorage to directly represent the changes in the 4.4.0
release and to make complient storages introspectable.

4.4.0 (2016-06-30)
==================

This release begins evolution to a more effcient commit protocol that
allows storage implementations, like `NEO <http://www.neoppod.org/>`_,
to support multiple transactions committing at the same time, for
greater write parallelism.

This release updates IStorage:

- The committed transaction's ID is returned by ``tpc_finish``, rather
  than being returned in response store and tpc_vote results.

- ``tpc_vote`` is now expected to return ``None`` or a list of object
  ids for objects for which conflicts were resolved.

This release works with storages that implemented the older version of
the storage interface, but also supports storages that implement the
updated interface.

4.3.1 (2016-06-06)
==================

- Fixed: FileStorage loadBefore didn't handle deleted/undone data correctly.

4.3.0 (2016-05-31)
==================

- Drop support for Python 2.6 and 3.2.

- Make the ``zodbpickle`` dependency required and not conditional.
  This fixes various packaging issues involving pip and its wheel
  cache. zodbpickle was only optional under Python 2.6 so this change
  only impacts users of that version.  See
  https://github.com/zopefoundation/ZODB/pull/42.

- Add support for Python 3.5.

- Avoid failure during cleanup of nested databases that provide MVCC
  on storage level (Relstorage).
  https://github.com/zopefoundation/ZODB/issues/45

- Remove useless dependency to `zdaemon` in setup.py. Remove ZEO documentation.
  Both were leftovers from the time where ZEO was part of this repository.

- Fix possible data corruption after FileStorage is truncated to roll back a
  transaction.
  https://github.com/zopefoundation/ZODB/pull/52

- DemoStorage: add support for conflict resolution and fix history()
  https://github.com/zopefoundation/ZODB/pull/58

- Fixed a test that depended on implementation-specific behavior in tpc_finish

4.2.0 (2015-06-02)
==================

- Declare conditional dependencies using PEP-426 environment markers
  (fixing interation between pip 7's wheel cache and tox).  See
  https://github.com/zopefoundation/ZODB/issues/36.

4.2.0b1 (2015-05-22)
====================

- Log failed conflict resolution attempts at ``DEBUG`` level.  See:
  https://github.com/zopefoundation/ZODB/pull/29.

- Fix command-line parsing of ``--verbose`` and ``--verify`` arguments.
  (The short versions, ``-v`` and ``-V``, were parsed correctly.)

- Add support for PyPy.

- Fix the methods in ``ZODB.serialize`` that find object references
  under Python 2.7 (used in scripts like ``referrers``, ``netspace``,
  and ``fsrecover`` among others). This requires the addition of the
  ``zodbpickle`` dependency.

- FileStorage: fix an edge case when disk space runs out while packing,
  do not leave the ``.pack`` file around. That would block any write to the
  to-be-packed ``Data.fs``, because the disk would stay at 0 bytes free.
  See https://github.com/zopefoundation/ZODB/pull/21.

4.1.0 (2015-01-11)
==================

- Fix registration of custom logging level names ("BLATHER", "TRACE").

  We have been registering them in the wrong order since 2004.  Before
  Python 3.4, the stdlib ``logging`` module masked the error by registering
  them in *both* directions.

- Add support for Python 3.4.

4.0.1 (2014-07-13)
==================

- Fix ``POSKeyError`` during ``transaction.commit`` when after
  ``savepoint.rollback``.  See
  https://github.com/zopefoundation/ZODB/issues/16

- Ensure that the pickler used in PyPy always has a ``persistent_id``
  attribute (``inst_persistent_id`` is not present on the pure-Python
  pickler). (PR #17)

- Provide better error reporting when trying to load an object on a
  closed connection.

4.0.0 (2013-08-18)
==================

Finally released.

4.0.0b3 (2013-06-11)
====================

- Switch to using non-backward-compatible pickles (protocol 3, without
  storing bytes as strings) under Python 3.  Updated the magic number
  for file-storage files under Python3 to indicate the incompatibility.

- Fixed: A ``UnicodeDecodeError`` could happen for non-ASCII OIDs
  when using bushy blob layout.

4.0.0b2 (2013-05-14)
====================

- Extended the filename renormalizer used for blob doctests to support
  the filenames used by ZEO in non-shared mode.

- Added ``url`` parameter to ``setup()`` (PyPI says it is required).

4.0.0b1 (2013-05-10)
=====================

- Skipped non-unit tests in ``setup.py test``.  Use the buildout to run tests
  requiring "layer" support.

- Included the filename in the exception message to support debugging in case
  ``loadBlob`` does not find the file.

- Added support for Python 3.2 / 3.3.

.. note::

   ZODB 4.0.x is supported on Python 3.x for *new* applications only.
   Due to changes in the standard library's pickle support, the Python3
   support does **not** provide forward- or backward-compatibility
   at the data level with Python2.  A future version of ZODB may add
   such support.

   Applications which need migrate data from Python2 to Python3 should
   plan to script this migration using separte databases, e.g. via a
   "dump-and-reload" approach, or by providing explicit fix-ups of the
   pickled values as transactions are copied between storages.


4.0.0a4 (2012-12-17)
=====================

- Enforced usage of bytes for ``_p_serial`` of persistent objects (fixes
  compatibility with recent persistent releases).

4.0.0a3 (2012-12-01)
=====================

- Fixed: An elaborate test for trvial logic corrupted module state in a
        way that made other tests fail spuriously.

4.0.0a2 (2012-11-13)
=====================

Bugs Fixed
----------

- An unneeded left-over setting in setup.py caused installation with
  pip to fail.

4.0.0a1 (2012-11-07)
=====================

New Features
------------

- The ``persistent`` and ``BTrees`` packages are now released as separate
  distributions, on which ZODB now depends.

- ZODB no longer depends on zope.event.  It now uses ZODB.event, which
  uses zope.event if it is installed.  You can override
  ZODB.event.notify to provide your own event handling, although
  zope.event is recommended.

- BTrees allowed object keys with insane comparison. (Comparison
  inherited from object, which compares based on in-process address.)
  Now BTrees raise TypeError if an attempt is made to save a key with
  comparison inherited from object. (This doesn't apply to old-style
  class instances.)

Bugs Fixed
----------

- Ensured that the export file and index file created by ``repozo`` share
  the same timestamp.

  https://bugs.launchpad.net/zodb/+bug/993350

- Pinned the ``transaction`` and ``manuel`` dependencies to Python 2.5-
  compatible versions when installing under Python 2.5.


.. note::
   Please see https://github.com/zopefoundation/ZODB/blob/master/HISTORY.rst
   for older versions of ZODB.
